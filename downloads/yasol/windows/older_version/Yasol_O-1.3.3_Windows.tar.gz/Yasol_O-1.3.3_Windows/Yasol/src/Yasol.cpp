/*
*
* Yasol: Yasol.cpp -- Copyright (c) 2012-2017 Ulf Lorenz
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
* LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
* OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef NO_MPI
#include <mpi.h>
#else
#include "nomp.h"
void MPI_Init(int*, char***) {}

void MPI_Buffer_attach(void*,int) {}
void MPI_Comm_rank(int x, int*y) {*y = 0;}
void MPI_Comm_size(int x, int*y) {*y = 1;}
void MPI_Wait(MPI_Request *, MPI_Status*) {}
void MPI_Barrier(int) {}
void MPI_Finalize(void) {}
void MPI_Ibsend(void *, int, int , int, int, int, MPI_Request *) {}
void MPI_Isend(void *, int, int, int,int , int, MPI_Request *){}
void MPI_Irecv(void *, int , int , int , int , int, MPI_Request*) {}
void MPI_Iprobe(int a, int b, int c, int* d, MPI_Status* e) {*d = 0;}
void MPI_Test(MPI_Request* a, int *b, MPI_Status *c) {*b = 1;}
void MPI_Recv(void *buf, int count, int datatype, int source, int tag, int* comm, MPI_Status *status) {}
void MPI_Send(const void *buf, int count, int datatype, int dest, int tag, int* comm) {}
void MPI_Get_count(MPI_Status*c, int m, int*size) {}

#endif
#include <iostream>
using namespace std;
#include "yInterface.h"

/*
 *
k_grz_p-6.qdimacs
k_d4_p-5.qdimacs
cnt10.qdimacs
cnt11.qdimacs
3qbf-5cnf-20var-640cl.1.qdimacs
3qbf-5cnf-20var-640cl.2.qdimacs

 */

int main(int argc, char** argv) {

	int myrank=0;
	MPI_Status status;

	if( !(argc-1) ){
#ifndef SVN_REV
#define SVN_REV "unknown"
#endif
		std::cout << SVN_REV << std::endl;
		return 0;
	}
	MPI_Init(&argc,&argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);

	//cerr << myrank << ": enter Yasol main." << endl;
	//utils::Logger::newLogger(&std::cout, utils::levelString(CONSOLE_LOG_LEVEL), "COUT");
	yInterface yasol;
	coef_t result;
	time_t ini_time;
	if (myrank == 0) cerr << "Yasol" << endl; // prints Yasol

	std::string in = std::string(argv[1]);
	//std::string in = std::string("C:\\Users\\michaelhartisch\\Programme\\Yasol_Windows\\Data\\p0033.qip");
	if (myrank == 0) cerr << in << endl;
    if (argc > 2) {
    	yasol.setInfoLevel(atoi(argv[2]));
    }
    //yasol.setInfoLevel(5);
	yasol.yInit(in);
	yasol.ySetProcessNo(myrank);

	if (myrank % 2 == 1) {
		ini_time = time(NULL);
    	result = yasol.ySolve(ini_time);
		MPI_Finalize();
		return 0;
	}

    const int DEPfirst=0;
	if (DEPfirst) {
		cout << "Solving DEP..." << endl;
		algorithm::Algorithm::QlpSolution sol = yasol.solveDEP();

		cout << "DEP Solution: " << sol.getSolutionStatusString() << endl;
		cout << "DEP Objective Value: " << sol.getObjFunctionValue() << endl;
		cout << "DEP Vars: "
				<< data::QpNum::vecToString(sol.getSolutionVector()) << endl;
		std::vector<data::QpNum> solu = sol.getSolutionVector();
		yasol.saveDepSolution(solu);
	}

	ini_time = time(NULL);
    if (argc > 3) {
    	yasol.setTimeout(time(NULL) + atoi(argv[3]));
    }
    if (argc > 3 && yasol.getTimeout() <= time(NULL)) {
        std::cout << "RESULT: " << "timeout" << " : " << in << std::endl;
        std::cout << "TIME: " << time(NULL)-ini_time << std::endl;
    } else if (yasol.getInfoLevel() > -10) {
    	cerr << "Objective Shift = " << yasol.offset_shift << endl;
    	result = yasol.ySolve(ini_time);
  		if (yasol.getInfoLevel() > 0) {
  			if (yasol.getInfoLevel() >= 2) std::cout << "Und LOS #rows=" << yasol.getmRows() << " #cols=" << yasol.getnVars() << std::endl;
  			if (yasol.getInfoLevel() >= 2) std::cout << "Objective Shift = " << yasol.offset_shift << endl;
	        if (yasol.objInverted) std::cout << "RESULT: " << -result << " : " << in << std::endl;
	        else std::cout << "RESULT: " << result << " : " << in << std::endl;
	        std::cout << "NODES: " << yasol.getNumberOfDecisions()+yasol.getNumberOfPropagationSteps() << ", #RELAXATIONS:"<< yasol.getNumberOfQlpCalls();
	        std::cout << ", LEARNED: " << yasol.getNumberOfLearntConstraints() << std::endl;
	        std::cout << "TIME: " << time(NULL)-ini_time << std::endl;
		} else {
		   if (yasol.getNinf() == result || yasol.getNinf() == -result) cout << "0" << endl;
		   else {
			   cout << "1" << endl << endl;
			   cout << result << endl << endl;
			   cout << "0" << endl;
		   }
		}
    }

	if (yasol.getInfoLevel() > 5 || yasol.getInfoLevel() < -5) {
		ini_time = time(NULL);
		cerr << "Solving DEP..." << endl;
		if (yasol.getInfoLevel() > -1000) {
			if (yasol.getInfoLevel() > -50) {
				algorithm::Algorithm::QlpSolution sol = yasol.solveDEP();
				cout << "DEP Solution: " << sol.getSolutionStatusString() << endl;
				cout << "DEP Objective Value: " << sol.getObjFunctionValue() << endl;
				cout << "DEP Vars: " << data::QpNum::vecToString(sol.getSolutionVector()) << endl;
				std::cout << "RESULT: " << sol.getObjFunctionValue().asDouble() << " : " << in << std::endl;
				std::cout << "TIME: " << time(NULL) - ini_time << std::endl;
			} else {
				algorithm::Algorithm::QlpSolution sol = yasol.solveDEP();
				if (sol.getSolutionStatusString().compare("Feasible")) {
					   cout << "1" << endl << endl;
					   cout << sol.getObjFunctionValue() << endl << endl;
					   cout << "0" << endl;
				} else {
					cout << "0" << endl;
				}
			}
		} else {
			yasol.dummyDEP();
            std::cout << "RESULT: " << " no result" << " : " << in << std::endl;
		    std::cout << "TIME: " << time(NULL) - ini_time << std::endl;
		}
	}
	MPI_Finalize();
	return 0;
}

