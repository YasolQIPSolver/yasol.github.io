/*
*
* Yasol: yInterface.h -- Copyright (c) 2012-2017 Ulf Lorenz
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
* LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
* OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef YINTERFACE_H_
#define YINTERFACE_H_

#include <queue>
#include <vector>
#include <set>

#include "QBPSolver.h"

#define EXIST 0
#define UNIV  1

const int maxUnivVars = 8;

struct node {
        int index;
        int i;
        bool onStack;
        int lowlink;
};

class IntInfo {
public:
   int index;
   int pt2leader;
   data::QpNum org_lb;
   data::QpNum org_ub;
   int org_ind;
   int bitcnt;
   std::string name;
   double tmp_x;
};

class Component {
	std::vector< std::vector<int> > &varsOfComponents;
	int n;
	int m;
	std::vector< std::vector<int> > &conVec;
	std::vector<const data::Constraint *> &rows;
	int8_t *assigns;
	std::vector<bool> rowInd;
	std::vector<int> col;
	std::vector<int> d;
	std::vector<int> l;
	std::vector<int> f;
	std::vector<int> Pi;
	std::vector<int> Q;
	std::vector<int> stack;
	std::vector<data::IndexedElement> lhs;
	int TIME;
	const int WHITE = 0;
	const int GREY  = 1;
	const int BLACK = 2;
public:
	Component(int nn, int rs,std::vector< std::vector<int> > &vOfCs, std::vector< std::vector<int> > &cV, std::vector<const data::Constraint *> &rws, int8_t *as) :
	          n(nn), m(rs), varsOfComponents(vOfCs), conVec(cV), rows(rws), assigns(as) {
		rowInd.resize(nn);
		for (int i = 0; i < nn;i++) rowInd[i] = false;
		col.resize(nn);
		for (int i = 0; i < nn;i++) col[i] = WHITE;
		d.resize(nn);
		for (int i = 0; i < nn;i++) d[i] = -1;
		l.resize(nn);
		for (int i = 0; i < nn;i++) l[i] = -1;
		f.resize(nn);
		for (int i = 0; i < nn;i++) f[i] = -1;
		Pi.resize(nn);
		for (int i = 0; i < nn;i++) Pi[i] = -1;
		TIME = 0;
	}
	bool isBiConnected(int c) {  // under construction
		int v = varsOfComponents[c][0];
		for (int i = 0; i < n;i++) col[i] = WHITE;
		for (int i = 0; i < n;i++) Pi[i] = -1;
		TIME = 0;
		cerr << "Component " << c << " deals with the following Variables: ";
		for (int i = 0; i < varsOfComponents[c].size();i++) {
			cerr << varsOfComponents[c][i] << " ";
		}
		cerr << endl;
		MDFS_visit_iterativ(v);
		for (int i = 0; i < varsOfComponents[c].size();i++) {
			if (i == 0) {
				int rootCnt=0;
				for (int j = 0; j < varsOfComponents[c].size();j++)
					if (Pi[varsOfComponents[c][i]] == v) rootCnt++;
				if (rootCnt > 1) cerr << "y" << varsOfComponents[c][i] << " ist AP" << endl;
			} else {
				if (l[varsOfComponents[c][i]] < d[varsOfComponents[c][i]]) ;
				else cerr << "x" << varsOfComponents[c][i] << " ist AP" << endl;
			}
		}
		return true;
	}
	void MDFS_visit_iterativ(int u) {
		stack.clear();
		stack.push_back(u);
		TIME++;
	    d[u] = TIME;
	    l[u] = TIME;
		TIME++;
		cerr << "start with x" << u << " at TIME=" << TIME << endl;
		while (stack.size()>0) {
			int var = stack.back();
			//stack.pop_back();
			if (col[var] == WHITE) {
				col[var] = GREY;
				for (int j = 0; j < conVec[var].size();j++) {
					lhs.clear();
					if (rowInd[conVec[var][j]] == true) continue;
					lhs = rows[conVec[var][j]]->getElements();//conVec[j]->getElements();
					rowInd[conVec[var][j]] = true;
					for (int jj = 0; jj < lhs.size();jj++) {
						if (assigns[lhs[jj].index] != 2) continue;
						if (col[lhs[jj].index] == WHITE) {
							if (jj == 0) Pi[lhs[jj].index] = var;
							else Pi[lhs[jj].index] = lhs[jj-1].index;
							d[lhs[jj].index] = TIME;
							stack.push_back(lhs[jj].index);
							TIME++;
							if (lhs.size()>2) l[lhs[jj].index] = l[var];
							else l[lhs[jj].index] = d[lhs[jj].index];
						} else if (col[lhs[jj].index] == GREY && Pi[var] != lhs[jj].index) {
							l[var] = (l[var]<d[lhs[jj].index] ? l[var] : d[lhs[jj].index]);
						}
					}
				}
			} else if (col[var] == GREY) {
				col[var] = BLACK;
				TIME++;
				f[var] = TIME;
				if (l[Pi[var]] > l[var]) l[Pi[var]] = l[var];
				stack.pop_back();
			} else if (col[var] == BLACK) {
				if (l[Pi[var]] > l[var]) l[Pi[var]] = l[var];
				stack.pop_back();
			}
		}
	}

	void MDFS_visit2(int u) {
		col[u] = GREY;
		d[u] = TIME;
		l[u] = d[u];
		TIME = TIME + 1;
		for (int j = 0; j < conVec[u].size();j++) {
			lhs.clear();
			lhs = rows[conVec[u][j]]->getElements();
			for (int jj = 0; jj < lhs.size();jj++) {
				if (assigns[lhs[jj].index] != 2) continue;
				if (col[lhs[jj].index] == WHITE) {
					Pi[lhs[jj].index] = u;
					MDFS_visit2(lhs[jj].index);
					l[u] = (l[u] < l[lhs[jj].index] ? l[u] : l[lhs[jj].index]);
				}
				if (col[lhs[jj].index] == GREY && Pi[u] != lhs[jj].index) {
					l[u] = (l[u]<d[lhs[jj].index] ? l[u] : d[lhs[jj].index]);
				}
			}
		}
		col[u] = BLACK;
		f[u] = TIME;
		TIME = TIME + 1;
	}
	void NDFS_visit(int u, int c) {
		col[u] = GREY;
		for (int j = 0; j < conVec[u].size();j++) {
			lhs.clear();
			lhs = rows[conVec[u][j]]->getElements();
			for (int jj = 0; jj < lhs.size();jj++) {
				if (assigns[lhs[jj].index] != 2) continue;
				if (col[lhs[jj].index] == WHITE) {
					Q.push_back(lhs[jj].index);
					NDFS_visit(lhs[jj].index,c);
					if (l[lhs[jj].index] >= d[u]) { // u ist Artikulationspunkt
						cerr << "x" << u << " ist ein AP der Komponente " << c << endl;
						//solange Knoten von Q entfernen und ausgeben, bis v ausgegeben.
						//Knoten u auch mit ausgeben.
					}
				}
			}
		}
		col[u] = BLACK;
	}
};

class yInterface {
public:
	struct set_compare {
	    bool operator() (const std::pair<int,int>& l, const std::pair<int,int>& r) const{
	        return l.first < r.first;
	    }
	};
private:
	int yParamMaxHashSize;

	int processNo;
	int info_level;
   	//data::Qlp qlp,dep,qlptmp;
	utils::QlpStageSolver *QlpStSolve;
	QBPSolver *qbp;
    coef_t result;
    time_t timeout;
    std::vector<data::QpNum> reducedCost;
    extSol::QpExternSolver::QpExtSolBase basis;
    const coef_t n_infinity = -1;
    const coef_t p_infinity = 1;
    std::vector<bool> alive;
    std::vector<int> sortcols;
    std::vector< std::pair< std::vector< std::pair<int,double> >,int > > SOSconstraints;
    std::set<std::pair<int,int>, set_compare > SOSvars;
    std::set<int> SOStabus;
    double LPoffset;
    std::vector<node> stack_S;

    void yReadIniFile();
	void yReadInput(int) ;

public:
   	data::Qlp qlp,dep,qlptmp, totalRecallQlp;
    bool objInverted;
	const int GMI = 1;
	const int Cover = 2;
	const int LuP = 4;
	const int UserCut = 8;
    void ySetProcessNo(int pno) { processNo = pno; qbp->ySetProcessNo(pno); }
    int64_t getNumberOfDecisions() { return qbp->getNumberOfDecisions(); }
    int64_t getNumberOfPropagationSteps() { return qbp->getNumberOfPropagationSteps(); }
    int64_t getNumberOfQlpCalls() { return qbp->getNumberOfQlpCalls(); }
    int64_t getNumberOfLearntConstraints() { return qbp->getNumberOfLearntConstraints(); }
    int getmRows() { return qbp->mRows(); }
    int getnVars() { return qbp->nVars(); }
    time_t getTimeout() { return timeout; }
    coef_t getNinf() { return qbp->getNegativeInfinity(); }

	int confl_var;
	unsigned int confl, confl_partner;

	std::vector< IntInfo > integers;
	std::vector< int > integers_lim;
	double offset_shift=0.0;

	double ipow2(int x) {
		assert(x >= 0);
		double r=1.0;
		if (x <= 0) return 1.0;
		for (int i = 0; i < x;i++) r = r*2.0;
		return r;
	}

	int XcompY(std::vector<data::IndexedElement > &X, std::vector<data::IndexedElement > &Y, data::IndexedElement x, data::IndexedElement y)
	{
		if (X.size() == 0 && Y.size() == 0) {
			//cerr << "X." << X.size() << "<=" << "Y." << Y.size() << endl;
			return 0;
		}
		if (X.size() == 0) {
			//cerr << "X." << X.size() << "<=" << "Y" << Y.size() << endl;
			return 1;
		}
		if (Y.size() == 0) {
			//cerr << "X" << X.size() << "<=" << "Y." << Y.size() << endl;
			return -1;
		}
		int i = 0; int j = 0;
		while (i < X.size() && j < Y.size()) {
			if (X[i].index < Y[j].index) { if (X[i].value.asDouble() < 0.0) return 1; else return -1; }
			if (X[i].index > Y[j].index) { if (Y[i].value.asDouble() < 0.0) return -1; else return 1; }
			if (X[i].index == Y[j].index) {
				if (X[i].value.asDouble() < Y[j].value.asDouble() - 1e-12) {
					return 1;
				}
				else if (X[i].value.asDouble() > Y[j].value.asDouble() + 1e-12) {
					return -1;
				}
				i++; j++;
			}
		}
		if (Y.size() < X.size()) return -1;
		if (Y.size() > X.size()) return 1;
		if (x.value.asDouble() > y.value.asDouble()) return -1;
		if (x.value.asDouble() < y.value.asDouble()) return 1;
		return 0;//x.value.asDouble() > y.value.asDouble();//false;//x.index < y.index;
	}

	bool XltY(std::vector<data::IndexedElement > &X, std::vector<data::IndexedElement > &Y, data::IndexedElement x, data::IndexedElement y)
	{
		if (XcompY(X,Y,x,y) == -1) return true;
		return false;
	}

	bool XgtY(std::vector<data::IndexedElement > &X, std::vector<data::IndexedElement > &Y, data::IndexedElement x, data::IndexedElement y)
	{
		if (XcompY(X,Y,x,y) == 1) return true;
		return false;
	}

	void yIselectionSort_Cols(int *colsort, int size, int maxLPstage)
	{
	    int     i, j, best_i;
	    int     tmp;
		extSol::QpExternSolver& eS = QlpStSolve->getExternSolver(maxLPstage);

	    for (i = 0; i < size-1; i++){
	        best_i = i;
	        for (j = i+1; j < size; j++){
	        	if ( XltY(*(eS.getCol_snapshot(colsort[j])), *(eS.getCol_snapshot(colsort[best_i])),
	        			  eS.getObj_snapshot(colsort[j]), eS.getObj_snapshot(colsort[best_i])) )
	                best_i = j;
	        }
	        tmp = colsort[i]; colsort[i] = colsort[best_i]; colsort[best_i] = tmp;
	    }
	}

	void yIsort(int* colsort, int size, int maxLPstage)
	{
		extSol::QpExternSolver& eS = QlpStSolve->getExternSolver(maxLPstage);
	    if (size <= 15)
	        yIselectionSort_Cols(colsort, size, maxLPstage);

	    else{
	        int         pivot_ix = size / 2;
	        int         pivot_col = colsort[pivot_ix];
	        int         tmp;
	        int         i = -1;
	        int         j = size;

	        for(;;){
	            do i++; while( XltY(*(eS.getCol_snapshot(colsort[i])), *(eS.getCol_snapshot(pivot_col)),
	            			        eS.getObj_snapshot(colsort[i]), eS.getObj_snapshot(pivot_col)) );
	            //do j--; while( XgtY(*(eS.getCol_snapshot(colsort[j/*pivot_ix*/])), *(eS.getCol_snapshot(pivot_col)),
    			//                    eS.getObj_snapshot(colsort[/*pivot_ix*/j]), eS.getObj_snapshot(pivot_col)) );
	            do j--; while( XltY(*(eS.getCol_snapshot(pivot_col)), *(eS.getCol_snapshot(colsort[j/*pivot_ix*/])),
    			                    eS.getObj_snapshot(pivot_col), eS.getObj_snapshot(colsort[j/*pivot_ix*/])) );

	            if (i >= j) break;

	            tmp = colsort[i]; colsort[i] = colsort[j]; colsort[j] = tmp;
	        }

	        yIsort(colsort    , i     , maxLPstage);
	        yIsort(&colsort[i], size-i, maxLPstage);
	    }
	}

	void sortCols(int maxLPstage) {
		int n = getnVars();
		sortcols.resize(n);
		for (int i = 0; i < n; i++) sortcols[i] = i;
		yIsort( sortcols.data(), sortcols.size(), maxLPstage);
        std::vector<int> tmp(sortcols.size());
        if(0)for (int i = 0; i < sortcols.size();i++) {
        	int x = sortcols[i];
        	tmp[i] = x;//.push_back(x);
        }
        if(0)for (int i = 0; i < tmp.size();i++)
        	sortcols[tmp[i]] = i;
	}

	/*
	int XdomY(extSol::QpExternSolver& externSolver, std::vector<data::IndexedElement > *X, std::vector<data::IndexedElement > *Y, data::IndexedElement x, data::IndexedElement y, bool useObj, std::vector<data::QpRhs> *RHSs)
	{
		// X and Y must be sorted with ascending index
		// was ist mit <=,>=,== ? ---> sense must be <= or == and obj minimize
		bool XdomY=true;
		bool YdomX=true;
		int n = getnVars();

		if (useObj) {
			if (x.index < n && y.index < n) {
				if (x.value.asDouble() < y.value.asDouble() - 1e-12) XdomY = false;
				else if (x.value.asDouble() > y.value.asDouble() + 1e-12) YdomX = false;
			} else if (x.index < n) {
				YdomX = false;
			} else if (y.index < n) {
				XdomY = false;
			} else useObj = false;
		}

		int i = 0; int j = 0;
		while (i < (*X).size() && j < (*Y).size()) {
			while (i < (*X).size() && j < (*Y).size() && (*X)[i].index < (*Y)[j].index ) { i++; YdomX = false; }
			if (i >= (*X).size() && j < (*Y).size()) XdomY = false;
			while (i < (*X).size() && j < (*Y).size() && (*X)[i].index > (*Y)[j].index ) { j++; XdomY = false; }
			if (i < (*X).size() && j >= (*Y).size()) YdomX = false;
			if (i >= (*X).size() || j >= (*Y).size()) {
				;
			} else if ((*X)[i].index == (*Y)[j].index) {
				assert((*RHSs)[(*X)[i].index].getRatioSign() != data::QpRhs::RatioSign::greaterThanOrEqual);
				if ((*X)[i].value.asDouble() < (*Y)[j].value.asDouble() - 1e-12) {
					XdomY = false;
					if ((*RHSs)[(*X)[i].index].getRatioSign() == data::QpRhs::RatioSign::equal) return 3;
				}
				else if ((*X)[i].value.asDouble() > (*Y)[j].value.asDouble() + 1e-12) {
					YdomX = false;
					if ((*RHSs)[(*X)[i].index].getRatioSign() == data::QpRhs::RatioSign::equal) return 3;
				}
				i++; j++;
				if (i >= (*X).size() && j < (*Y).size()) XdomY = false;
				if (i < (*X).size() && j >= (*Y).size()) YdomX = false;
			}
			if (!XdomY && !YdomX) break;
		}
		if (XdomY && YdomX) return 0;
		if (XdomY) return 1;
		if (YdomX) return -1;
		return 2;
	}
	*/

	int XdomY(extSol::QpExternSolver& externSolver, std::vector<data::IndexedElement > *X, std::vector<data::IndexedElement > *Y, data::IndexedElement x,
			data::IndexedElement y, bool useObj, std::vector<data::QpRhs> *RHSs, int colx, int coly)
	{
		// X and Y must be sorted with ascending index
		// was ist mit <=,>=,== ? ---> sense must be <= or == and obj minimize
		bool XdomY=true;
		bool YdomX=true;
		int n = getnVars();
		double xVal, yVal;
		int xInd, yInd;

		if (0&&colx == 90 && coly == 91) {
			cerr << "Rows with x91:";
			for (int i = 0; i < (*X).size();i++)
				cerr << (*X)[i].value.asDouble() << "u" << (*X)[i].index << " ";
			cerr << endl;
			cerr << "Rows with x92:";
			for (int i = 0; i < (*Y).size();i++)
				cerr << (*Y)[i].value.asDouble() << "u" << (*Y)[i].index << " ";
			cerr << endl;
		}
		if (0&&colx == 91 && coly == 90) {
			cerr << "Rows with x92:";
			for (int i = 0; i < (*X).size();i++)
				cerr << (*X)[i].value.asDouble() << "u" << (*X)[i].index << " ";
			cerr << endl;
			cerr << "Rows with x91:";
			for (int i = 0; i < (*Y).size();i++)
				cerr << (*Y)[i].value.asDouble() << "u" << (*Y)[i].index << " ";
			cerr << endl;
		}

		if (useObj) {
			xInd = x.index; yInd = y.index;
			if (x.index < n && y.index < n) {
				xVal = x.value.asDouble(); yVal = y.value.asDouble();
				if (xVal < yVal) XdomY = false;
				else if (xVal > yVal) YdomX = false;
			} else if (x.index < n) {
				xVal = x.value.asDouble(); yVal = 0.0;
				if (xVal < yVal) XdomY = false;
				else if (xVal > yVal) YdomX = false;
			} else if (y.index < n) {
				xVal = 0.0; yVal = y.value.asDouble();
				if (xVal < yVal) XdomY = false;
				else if (xVal > yVal) YdomX = false;
			} else useObj = false;
		}

		int i = 0; int j = 0;
		bool eqOc = false;
		while (i < (*X).size() || j < (*Y).size()) {
			if (i < (*X).size() && (*RHSs)[(*X)[i].index].getRatioSign() == data::QpRhs::RatioSign::equal) eqOc = true;
			if (j < (*Y).size() && (*RHSs)[(*Y)[j].index].getRatioSign() == data::QpRhs::RatioSign::equal) eqOc = true;
			if (i < (*X).size() && j < (*Y).size()) {
				if ((*X)[i].index < (*Y)[j].index) {
					xVal = (*X)[i].value.asDouble();
					yVal = 0.0;
					if (xVal < yVal) XdomY = false;
					else if (xVal > yVal) YdomX = false;
					i++;
				} else if ((*X)[i].index > (*Y)[j].index) {
					xVal = 0.0;
					yVal = (*Y)[j].value.asDouble();
					if (xVal < yVal) XdomY = false;
					else if (xVal > yVal) YdomX = false;
					j++;
				} else if ((*X)[i].index == (*Y)[j].index) {
					if (0&&colx == 90 && coly == 91) {
						cerr << (*X)[i].value.asDouble() << "x90 und " << (*Y)[j].value.asDouble() << "x91" << endl;
					}
					if (0&&colx == 91 && coly == 90) {
						cerr << (*X)[i].value.asDouble() << "x91 und " << (*Y)[j].value.asDouble() << "x90" << endl;
					}
					assert((*RHSs)[(*X)[i].index].getRatioSign() != data::QpRhs::RatioSign::greaterThanOrEqual);
					if ((*X)[i].value.asDouble() < (*Y)[j].value.asDouble() ) {
						XdomY = false;
					}
					else if ((*X)[i].value.asDouble() > (*Y)[j].value.asDouble() ) {
						YdomX = false;
					}
					i++; j++;
				}
			} else if (i < (*X).size()) {
				xVal = (*X)[i].value.asDouble();
				yVal = 0.0;
				if (xVal < yVal) XdomY = false;
				else if (xVal > yVal) YdomX = false;
				i++;
			} else if (j < (*Y).size()) {
				xVal = 0.0;
				yVal = (*Y)[j].value.asDouble();
				if (xVal < yVal) XdomY = false;
				else if (xVal > yVal) YdomX = false;
				j++;
			}
			if (!XdomY && !YdomX) break;
		}

		if (XdomY && YdomX) return 0;
		if (eqOc) return 3;
		if (XdomY) return 1;
		if (YdomX) return -1;
		return 2;
	}

	void findSymmetries(utils::QlpStageSolver& QlpStSolve, int maxLPstage, bool useObj, std::vector< std::pair<int,int> > &clist, int *types, int *block, int8_t * assigns) {
#ifndef FIND_BUG
		clist.clear();
    	//return;
#endif //#ifdef FIND_BUG
		sortCols(maxLPstage);
    	clist.clear();
    	//for (int i = 0; i < sortcols.size();i++) cerr << " " << sortcols[i];
    	//cerr << endl;
    	int n = getnVars();
    	int minBlock = n+10;
    	for (int i = 0; i < n;i++)
    		if (block[i] < minBlock) minBlock = block[i];
    	time_t start = time(NULL);
    	time_t ini_time = qbp->getInitilizationTime();
    	CliqueManager *pCM = qbp->getClipueManager();

    	for (int k = 1; k < 10 || (k < n && time(NULL) - start < (time(NULL) - ini_time) * 0.2 + 5);k++) {
			for (int i = 0; i < n-k;i++) {
				if (QlpStSolve.getExternSolver(maxLPstage).getCol_snapshot(sortcols[i])->size() == 0) continue;
				if (QlpStSolve.getExternSolver(maxLPstage).getCol_snapshot(sortcols[i+k])->size() == 0) continue;
				//if (block[sortcols[i]] != minBlock || block[sortcols[i+k]] != minBlock) continue;
				if (block[sortcols[i]] != block[sortcols[i+k]]) continue;
				if (types[sortcols[i]] == UNIV || types[sortcols[i+k]] == UNIV) continue;
				//if (assigns[sortcols[i]] != 2 || assigns[sortcols[i+k]] != 2) continue;
				//if (QlpStSolve.getExternSolver(maxLPstage).getCol_snapshot(sortcols[i])->size() > n-2) continue;
				int xdy = XdomY( QlpStSolve.getExternSolver(maxLPstage),
					  QlpStSolve.getExternSolver(maxLPstage).getCol_snapshot(sortcols[i]),QlpStSolve.getExternSolver(maxLPstage).getCol_snapshot(sortcols[i+k]),
					  QlpStSolve.getExternSolver(maxLPstage).getObj_snapshot(sortcols[i]),QlpStSolve.getExternSolver(maxLPstage).getObj_snapshot(sortcols[i+k]),
					  useObj, QlpStSolve.getExternSolver(maxLPstage).getRowRhs_snapshot(), sortcols[i], sortcols[i+k]);
				if (k == 1 && xdy==0) {
					if (info_level > 5) cerr << "SYMMETRIE FOUND!! " << i << "," << i+1 << " | " << sortcols[i] << ", " << sortcols[i+1] << endl;
					int j;
					bool foundFixing = false;
					j = pCM->FirstAdjacentInConflictGraph(2*sortcols[i]); // Fall x_i <= x_j
					if (j >= 0) {
						//cerr << "j=" << j << endl;
						int kk = pCM->NextAdjacentInConflictGraph(j);
						while (kk >= 0) {
							//cerr << "j=" << j << " kk=" << kk << " a(j)=" << CM.getAdjacent(j) << " a(kk)=" << CM.getAdjacent(kk) << endl;
							int v1 = sortcols[i];
							int v2 = pCM->getAdjacent(kk);
							v2 /= 2;
							assert(types[v2] != /*CONTINUOUS*/5000);
							if (v2 == sortcols[i+1] && block[sortcols[i]] == minBlock && block[sortcols[i+k]] == minBlock) {
								//cerr << "found " << v1 << " <-> " << v2 << " -- " << solution[v1].asDouble() << "," << solution[v2].asDouble() << endl;
								//cerr << "Bilde: (1-x" << v1 << ") + ";
								if (pCM->getAdjacent(kk) & 1) {
									//cerr << "x" << v2 << " >=1 " << endl;
									//cerr << "Clause schon vorhanden 1" << endl;
								} else {
									//cerr << "(1-x" << v2 << ") >= 1" << endl;
									//cerr << "Fall 1b set x" << sortcols[i] << " auf 0" << endl;
									clist.push_back(make_pair(-sortcols[i]-1,0));
									foundFixing = true;
								}
							}
							kk = pCM->NextAdjacentInConflictGraph(kk);
						}
					}
					j = pCM->FirstAdjacentInConflictGraph(2*sortcols[i]+1);  // Fall x_i <= x_j
					if (j >= 0) {
						int kk = pCM->NextAdjacentInConflictGraph(j);
						while (kk >= 0) {
							int v1 = sortcols[i];
							int v2 = pCM->getAdjacent(kk);
							v2 /= 2;
							assert(types[v2] != 5000/*CONTINUOUS*/);
							if (v2 == sortcols[i+k]  && block[sortcols[i]] == minBlock && block[sortcols[i+k]] == minBlock) {
								//cerr << "found " << v1 << " <-> " << v2 << " -- " << solution[v1].asDouble() << "," << solution[v2].asDouble() << endl;
								//cerr << "Bilde: x" << v1 << " + ";
								if (pCM->getAdjacent(kk) & 1) {
									//cerr << "x" << v2 << " >=1 " << endl;
									//cerr << "set x" << sortcols[i+k] << " auf 1" << endl;
									clist.push_back(make_pair(-sortcols[i+k]-1,1));
									foundFixing = true;
								} else {
									//cerr << "(1-x" << v2 << ") >= 1" << endl;
									//cerr << "Fall2b set x" << sortcols[i] << " = x" << sortcols[i+k] << endl;
									clist.push_back(make_pair(sortcols[i],-sortcols[i+k]-1));
									foundFixing = true;
								}
							}
							kk = pCM->NextAdjacentInConflictGraph(kk);
						}
					}
					if (foundFixing==true) {
						//clist.push_back(make_pair(sortcols[i],sortcols[i+1]));
					} else {
						foundFixing = false;
						j = pCM->FirstAdjacentInConflictGraph(2*sortcols[i+k]); // Fall x_i >= x_j
						if (j >= 0) {
							//cerr << "j=" << j << endl;
							int kk = pCM->NextAdjacentInConflictGraph(j);
							while (kk >= 0) {
								//cerr << "j=" << j << " kk=" << kk << " a(j)=" << CM.getAdjacent(j) << " a(kk)=" << CM.getAdjacent(kk) << endl;
								int v1 = sortcols[i+k];
								int v2 = pCM->getAdjacent(kk);
								v2 /= 2;
								assert(types[v2] != /*CONTINUOUS*/5000);
								if (v2 == sortcols[i]  && block[sortcols[i+k]] == minBlock && block[sortcols[i]] == minBlock) {
									//cerr << "found " << v1 << " <-> " << v2 << " -- " << solution[v1].asDouble() << "," << solution[v2].asDouble() << endl;
									//cerr << "Bilde: (1-x" << v1 << ") + ";
									if (pCM->getAdjacent(kk) & 1) {
										//cerr << "x" << v2 << " >=1 " << endl;
										//cerr << "Fall3a set x" << sortcols[i] << " = x" << sortcols[i+k] << endl;
										clist.push_back(make_pair(sortcols[i],-sortcols[i+k]-1));
										foundFixing = true;
									} else { //f�hrt zu keiner neuen Erkenntnis
										//cerr << "(1-x" << v2 << ") >= 1" << endl;
										//cerr << "Fall3b set x" << sortcols[i+k] << " auf 0" << endl;
										//cerr << "weil: SYMMETRIE FOUND!! i=" << i << ",k=" << k << " | x" << sortcols[i] << " <= x" << sortcols[i+k] << endl;
										foundFixing = true;
										clist.push_back(make_pair(-sortcols[i+k]-1,0));
									}
								}
								kk = pCM->NextAdjacentInConflictGraph(kk);
							}
						}
						j = pCM->FirstAdjacentInConflictGraph(2*sortcols[i+1]+1);// Fall x_i >= x_j
						if (j >= 0) {
							int kk = pCM->NextAdjacentInConflictGraph(j);
							while (kk >= 0) {
								int v1 = sortcols[i+1];
								int v2 = pCM->getAdjacent(kk);
								v2 /= 2;
								assert(types[v2] != 5000/*CONTINUOUS*/);
								if (v2 == sortcols[i]  && block[sortcols[i+k]] == minBlock && block[sortcols[i]] == minBlock) {
									//cerr << "found " << v1 << " <-> " << v2 << " -- " << solution[v1].asDouble() << "," << solution[v2].asDouble() << endl;
									//cerr << "Bilde: x" << v1 << " + ";
									if (pCM->getAdjacent(kk) & 1) {
										//cerr << "x" << v2 << " >=1 " << endl;
										//cerr << "set x" << sortcols[i] << " auf 1" << endl;
										clist.push_back(make_pair(-sortcols[i]-1,1));
										foundFixing = true;
									} else {
										//cerr << "(1-x" << v2 << ") >= 1" << endl;
										//cerr << "Clause schon vorhanden 4" << endl;
									}
								}
								kk = pCM->NextAdjacentInConflictGraph(kk);
							}
						}
						if (!foundFixing)
						    clist.push_back(make_pair(sortcols[i],sortcols[i+k]));
					}
				}
				int sokoI=-10;
				int sokoIK=-10;
				if (xdy==-1) {
					//cerr << "SYMMERR" << endl;
					//if (info_level > 5) cerr << "DOMINANCE TYPE 1!! " << i << "," << i+k << " | " << sortcols[i] << ", " << sortcols[i+k] << endl;
					//clist.push_back(make_pair(sortcols[i+k],sortcols[i]));
					sokoI = sortcols[i+k];
					sokoIK = sortcols[i];
				}
				if (xdy==1) {
					sokoI = sortcols[i];
					sokoIK = sortcols[i+k];
				}
				if (xdy==1 || xdy==-1) {
					if (info_level > 5) cerr << "DOMINANCE TYPE " << k << "!! " << i << "," << i+k << " | " << sokoI << ", " << sokoIK << endl;
					//clist.push_back(make_pair(sokoI,sokoIK));
					int j;
					bool foundFixing=false;
					j = pCM->FirstAdjacentInConflictGraph(2*sokoI); // Fall x_i <= x_j
					if (j >= 0) {
						//cerr << "j=" << j << endl;
						int kk = pCM->NextAdjacentInConflictGraph(j);
						while (kk >= 0) {
							//cerr << "j=" << j << " kk=" << kk << " a(j)=" << CM.getAdjacent(j) << " a(kk)=" << CM.getAdjacent(kk) << endl;
							int v1 = sokoI;
							int v2 = pCM->getAdjacent(kk);
							v2 /= 2;
							assert(types[v2] != /*CONTINUOUS*/5000);
							if (v2 == sokoIK  && block[sokoI] == minBlock && block[sokoIK] == minBlock) {
								//cerr << "found " << v1 << " <-> " << v2 << " -- " << solution[v1].asDouble() << "," << solution[v2].asDouble() << endl;
								//cerr << "Bilde: (1-x" << v1 << ") + ";
								if (pCM->getAdjacent(kk) & 1) {
									//cerr << "x" << v2 << " >=1 " << endl;
									//cerr << "Clause schon vorhanden 1" << endl;
								} else {
									//cerr << "(1-x" << v2 << ") >= 1" << endl;
									//cerr << "Fall 5b set x" << sokoI << " auf 0" << endl;
									//cerr << "weil: DOMINANCE FOUND!! i=" << i << ",k=" << k << " | x" << sokoI << " <= x" << sokoIK << endl;
									clist.push_back(make_pair(-sokoI-1,0));
									foundFixing = true;
								}
							}
							kk = pCM->NextAdjacentInConflictGraph(kk);
						}
					}
					j = pCM->FirstAdjacentInConflictGraph(2*sokoI+1);  // Fall x_i <= x_j
					if (j >= 0) {
						int kk = pCM->NextAdjacentInConflictGraph(j);
						while (kk >= 0) {
							int v1 = sokoI;
							int v2 = pCM->getAdjacent(kk);
							v2 /= 2;
							assert(types[v2] != 5000/*CONTINUOUS*/);
							if (v2 == sokoIK && block[sokoI] == minBlock && block[sokoIK] == minBlock) {
								//cerr << "found " << v1 << " <-> " << v2 << " -- " << solution[v1].asDouble() << "," << solution[v2].asDouble() << endl;
								//cerr << "Bilde: x" << v1 << " + ";
								if (pCM->getAdjacent(kk) & 1) {
									//cerr << "x" << v2 << " >=1 " << endl;
									//cerr << "set x" << sokoIK << " auf 1" << endl;
									clist.push_back(make_pair(-sokoIK-1,1));
									foundFixing = true;
								} else {
									//cerr << "(1-x" << v2 << ") >= 1" << endl;
									//cerr << "set x" << sokoI << " = x" << sokoIK << endl;
									clist.push_back(make_pair(sokoI,-sokoIK-1));
									foundFixing = true;
								}
							}
							kk = pCM->NextAdjacentInConflictGraph(kk);
						}
					}
					static int cntcl=0;
					if (foundFixing == false /*&& block[sokoI] == minBlock && block[sokoIK] == minBlock*/) {
					    clist.push_back(make_pair(sokoI,sokoIK));
					    /*
					    std::vector<data::IndexedElement > *X = QlpStSolve.getExternSolver(maxLPstage).getCol_snapshot(sortcols[i]);
					    std::vector<data::IndexedElement > *Y = QlpStSolve.getExternSolver(maxLPstage).getCol_snapshot(sortcols[i+k]);
					    cout << "?x" << sortcols[i]+1 << " <= x" << sortcols[i+k]+1 << endl;
					    cerr << "x" << sortcols[i] << " <= x" << sortcols[i+k] << "; " << i << "," << i+k << endl;
						cerr << "Rows with xi:";
						for (int i = 0; i < (*X).size();i++)
							cerr << (*X)[i].value.asDouble() << "u" << (*X)[i].index << " ";
						cerr << endl;
						cerr << "Rows with xi+k:";
						for (int i = 0; i < (*Y).size();i++)
							cerr << (*Y)[i].value.asDouble() << "u" << (*Y)[i].index << " ";
						cerr << endl;
						*/
					    cntcl++;
					}
				}
			}
    	}
        if (info_level >= 2) cerr << "Minblock=" << minBlock << endl;
    }

	double getLPoffset() {
		return LPoffset;
	}
	bool getIsInSOSvars(int x_i) {
		if (SOSvars.count(std::pair<int,int>(x_i,0)) > 0) return true;
		return false;
	}
	void adaptSolution(std::vector<data::QpNum>& solution, int *types, extbool* assigns) {
		std::vector<int> SOSvarsSparse;
		for (int z = 0; z < solution.size();z++) {
			if (types[z]==0 /*BINARY*/) {
				if (SOSvars.count(std::pair<int,int>(z,0)) > 0) {
					if (assigns[z]!=2 && fabs((double)assigns[z]-solution[z].asDouble()) > 0.5) cerr << "SOSvar: " << (int)assigns[z] << "," << solution[z].asDouble() << endl;
					//std::cerr << "x" << x_i << " already in SOSvars." << std::endl;
					solution[z] = -10.0;
					SOSvarsSparse.push_back(z);
				} else if (assigns[z]!=2) {
					if (fabs((double)assigns[z]-solution[z].asDouble()) > 0.5) cerr << "NOTSOSvar: " << (int)assigns[z] << "," << solution[z].asDouble() << endl;
					solution[z] = (double)assigns[z];
				}
			}
		}
		bool uneval_exists=false;
		int round=0;
		int success = 0;
		do {
			round++;
			uneval_exists=false;
			for (int i = 0; i < SOSvarsSparse.size();i++) {
				assert(types[SOSvarsSparse[i]]==0 /*BINARY*/);
				if (solution[SOSvarsSparse[i]] < -0.5) {
					//suche zeile L in SOSconstraints

				    // binary search
					int v = SOSvarsSparse[i];
					if (round > solution.size()) cerr << "einzusetzende Variable ist x" << v << endl;
					int jj=SOSconstraints.size()-1,ii=0;
					int match=-1;
					while (jj >= ii) {
						int m = (ii + jj)>>1;
						//if (v==24) cerr << ii <<"," << jj <<  "," << m << "," << SOSconstraints[m].second<< endl;
						int w = fabs(SOSconstraints[m].second);
						if (w==v && SOSconstraints[m].second >= 0) {
							match = m;
							break;
						} else {
							if (ii==jj) break;
							if (v>w) {
								ii=m+1;
							} else if (v<w) {
								jj=m-1;
							}
						}
					}
					assert(match != -1);
					if (match!=-1) {
						//versuch x_SOSvarsSparse[i] aus L herauszurechnen.
						std::vector< std::pair<int,double> > &sosLHS = SOSconstraints[match].first;
						double result = 0.0;
						if (round > solution.size()) cerr << "Term und Werte: ";
						for (int ii = 0; ii < sosLHS.size();ii++) {
							if (sosLHS[ii].first > solution.size()) {
								if (round > solution.size()) cerr << sosLHS[ii].second << "x" << sosLHS[ii].first << "(.)" << " ";
								result = result + sosLHS[ii].second;
							} else if (solution[sosLHS[ii].first].asDouble() >= -1 ) {
								if (round > solution.size()) cerr << sosLHS[ii].second << "x" << sosLHS[ii].first << "(" << solution[sosLHS[ii].first].asDouble() << ")" << " ";
								result = result + solution[sosLHS[ii].first].asDouble()*sosLHS[ii].second;
							} else {
								uneval_exists = true;
								break;
							}
						}
						//wenn das geht: in solution eintragen
						//sonst: uneval_exists=true und next variable
						if (uneval_exists == false) {
							success++;
							if (-result < -1e-9 || -result > 1+1e-9) cerr << "RANGE: " << result << endl;
							assert(-result >= -1e-9 && -result <= 1+1e-9);
							solution[v] = -result;
							if (round > solution.size()) cerr << "MATCH!! solution[]=" << solution[match].asDouble() << endl;
						}
					}
				}
			}
			if (uneval_exists && round > solution.size()) {
				cerr << "Round " << round << " und success=" << success << endl;
				cerr << "#sos vars: " << SOSvarsSparse.size() << endl;


				char a;
				cin >> a;
			}
		} while (uneval_exists);
		//for (int ii=0;ii < solution.size();ii++) {
		//	cerr << "x" << ii << "=" << solution[ii].asDouble() << ", ";
		//}
		//cerr << endl;
	}

	int64_t ggt(int64_t a, int64_t b);
	bool exactAvail(std::vector<data::IndexedElement> &table_lhs, std::vector<data::IndexedElement> &lhs, data::QpRhs table_rhs, data::QpRhs rhs);
	void simplifyCoefficients_01(std::vector<data::IndexedElement> &lhs, std::vector<data::IndexedElement> &ilhs, data::QpRhs &rhs, data::QpRhs &org_rhs, int8_t *ba);
	void analyzeAndChangeIntRow(std::vector<data::IndexedElement> &lhs, std::vector<data::IndexedElement> &ilhs, data::QpRhs &rhs, data::QpRhs &org_rhs, int8_t *ba);
	bool extractSOS(std::vector<data::IndexedElement> &org_lhs, data::QpRhs &org_rhs, int c);
	void addNegativeOfSosC2ToSosC1(std::vector< std::pair<int,double> > &c1, std::vector< std::pair<int,double> > &c2, int x_i);
	bool checkStabilityOfMult(std::vector< std::pair<int,double> > &c1, std::vector< std::pair<int,double> > &c2, int x_i) ;
	void replaceSOSvars( int );
	void replaceSOSvars( std::vector< std::vector<data::IndexedElement> > &LHSs, std::vector<data::QpRhs> &RHSs, int c );
	void replaceSOSvarsInObj( std::vector<data::IndexedElement> &OBJ, data::QpRhs &OBJBND , int cntVars);
#ifndef FIND_BUG
	void updateConstraints(data::Qlp &qmip, utils::QlpStageSolver& QlpStSolve, int8_t *ba, coef_t rhsbnd, int *, int,
			std::vector<std::pair<int,double> > &cpropQ, coef_t *lowerBounds, coef_t *upperBounds,
			bool feasPhase, std::vector< std::pair<int,int> > &clist, int *block, int *eas);
#else
	void updateConstraints(data::Qlp &qmip, utils::QlpStageSolver& QlpStSolve, int8_t *ba, coef_t rhsbnd, int *, int);
#endif
	void updateContBounds(data::Qlp &qmip, utils::QlpStageSolver& QlpStSolve, int8_t *binary_assignments_,
			int *types, int maxLPstage, std::vector< std::vector<data::IndexedElement> > &LHSs, std::vector<data::QpRhs> &RHSs , int cntVars,
			coef_t *lowerBounds, coef_t *upperBounds, std::vector<std::pair<int,double> > &cpropQ);
	void findComponents(data::Qlp &qmip, int8_t *assigns, int *components, std::vector< std::vector<int> > &varsOfComponents);
	void strongConnect(CliqueManager &CM, std::vector<node> &V, int8_t *assigns, int *components, int *index, node v, int *c_identifier, int *types);
	void findStrongComponents(CliqueManager &CM, int8_t *assigns, int *components, int *c_identifier, int *types);
	void makeBinary(data::Qlp &qlp, data::Qlp &qbp);

	algorithm::Algorithm::QlpSolution solveDEP() {
		data::Qlp qlp2;
		if (getInfoLevel() == -21) {
			integers.clear();
			integers_lim.clear();
			offset_shift = 0.0;
			makeBinary(/*orgQlp, orgQlpBinarized*/qlp,qlp2);
		}
		algorithm::Qlp2Lp DEP(getInfoLevel() == -21 ? qlp2 : qlp);
		return DEP.solveQlp(algorithm::Algorithm::WORST_CASE);
    }
    algorithm::Algorithm::QlpSolution resolveDEP(int8_t *assigns) {
		data::Qlp qlp2;
		int cnt=0;
		if (getInfoLevel() == -21) {
				integers.clear();
				integers_lim.clear();
				offset_shift = 0.0;
				makeBinary(/*orgQlp, orgQlpBinarized*/qlp,qlp2);
		}
		for (int z=0; z < qbp->nVars();z++)
				if (assigns[z] != 2) {
						   cnt++;
						   qlp.getVariableVector().at(z)->setLowerBound((double)assigns[z]);
						   qlp.getVariableVector().at(z)->setUpperBound((double)assigns[z]);
				} else if (qbp->isFixed(z)) {
						   qlp.getVariableVector().at(z)->setLowerBound((double)qbp->getFixed(z));
						   qlp.getVariableVector().at(z)->setUpperBound((double)qbp->getFixed(z));
				} else {
						   qlp.getVariableVector().at(z)->setLowerBound(0.0);
						   qlp.getVariableVector().at(z)->setUpperBound(1.0);
				}
		cerr << "es wurden " << cnt << " Varablen gestzt" << endl;
		algorithm::Qlp2Lp DEP(qlp);
		return DEP.solveQlp(algorithm::Algorithm::WORST_CASE);
    }
    void dummyDEP() {
		algorithm::Qlp2Lp DEP(qlp);
    }
	void saveDepSolution(std::vector<data::QpNum>  &solu) {
		qbp->saveDepSolution(solu);
	}

	void setInfoLevel(int l) { info_level = l; }
	int getInfoLevel() { return info_level; }

	void setTimeout(time_t t) {
		timeout = t;
		qbp->setTimeout(t);
	}

    bool isOnTrack(ca_vec<int> &optSol, std::vector<data::IndexedElement>  &LHS, data::QpRhs &RHS) {
    	//if (USE_TRACKON == 0) return false;
    	return false;
    	cerr << ".";
    	double sum=0.0;
    	for (int i = 0;i < LHS.size();i++) {
    		int v = LHS[i].index;
    		double d = LHS[i].value.asDouble();
    		//if (d < -1e10 || d > 1e10 || optSol[v] > 2 || optSol[v] < 0) return true;
    		sum = sum + d * optSol[v];
    		if (d!=d) {
    			cerr << "d is NAN! Index=" << v << endl;
    			return true;
    		}
    		if (sum!=sum) {
    			cerr << "sum is NAN! Index=" << v << endl;
    			return true;
    		}
    	}
    	if (RHS.getRatioSign() == data::QpRhs::RatioSign::equal && (sum > RHS.getValue().asDouble()+LP_EPS || sum < RHS.getValue().asDouble()-LP_EPS)) {
    		cerr << "is " << sum << " == " << RHS.getValue().asDouble() << " ?" << endl;
    		return true;
    	} else if (RHS.getRatioSign() == data::QpRhs::RatioSign::smallerThanOrEqual && sum > RHS.getValue().asDouble()) {
    		cerr << "is " << sum << " <= " << RHS.getValue().asDouble() << " ?" << endl;
    		return true;
    	} else if (RHS.getRatioSign() == data::QpRhs::RatioSign::greaterThanOrEqual && sum < RHS.getValue().asDouble()){
    		cerr << "is " << sum << " >= " << RHS.getValue().asDouble() << " ?" << endl;
    		return true;
    	}
    	return false;
    }

    void yInit(data::Qlp& orgQlp) {

    	if( orgQlp.getObjective() == data::QpObjFunc::max ) {
    		orgQlp.reverseObjFunc();
    		objInverted = true;
     	} else objInverted = false;

		qlp = orgQlp;
		qlptmp = orgQlp;

		utils::QlpConverter::relaxQlpNumberSystem(qlptmp);

		std::vector<data::QpVar*> vars = qlptmp.getVariableVectorByQuantifier(data::QpVar::all);
		std::vector<int> l_cU;
		if (vars.size() > maxUnivVars) {
			for(unsigned int i = 0; i < vars.size() - maxUnivVars;i++){
					vars[i]->setQuantifier(data::QpVar::exists);
					l_cU.push_back(vars[i]->getIndex());
			}
		}

		//QlpStSolve = new utils::QlpStageSolver(qlptmp,true,false);
		qbp = new QBPSolver(qlptmp);
		qbp->determineFixedUniversalVars(l_cU); // not used, gives the possiblity to restrict the number of universal variables and leads to a relaxation
        yReadInput(yParamMaxHashSize);
        qbp->DepManagerInitGraph();
        cerr << "begin scan" << endl;
        qbp->DepManScanConstraints();
        cerr << "end scan" << endl;
        for (int z=0; z < qbp->nVars();z++) {
        	qbp->insertVar2PriorityQueue(z);
        }
        qbp->DepManInitFillRate();
	}

	void yInit(std::string inputfile){
		data::Qlp orgQlp;
		data::Qlp orgQlpBinarized;
		utils::Parser::createQlp(inputfile, orgQlp/*orgQlpBinarized*/);
		makeBinary(orgQlp, orgQlpBinarized);
		yInit( orgQlpBinarized );
	}

	bool nodeValueKnown(coef_t &r) {
		return false;
	}
	void preRec() {
		alive.push_back(true);
	}
	bool levelAlive() {
		bool x = alive[alive.size()-1];
		return x;
	}
	void postRec() {
		alive.pop_back();
	}
	bool deepImplicationAvailable() {
		return qbp->deepImplicationAvailable();
	}
	bool selectVariable(int &v) {
		for (int i = 0; i < getnVars();i++)
			if (qbp->getCurrentVariableAssignment(i) == extbool_Undef) {
				v = i;
				return true;
			}
		return false;
	}
	int choosePolarity() {
		return 0;
	}
	bool assignVariable(int pol, int var) {
		int oob = qbp->assign(var, pol, qbp->getTrailSize(),CRef_Undef, false);
		if (oob == ASSIGN_OK) return true;
		return false;
	}
	void killLevelsUntil(int &level, ValueConstraintPair &out_vcp) {
		QBPSolver::ValueConstraintPair VCP;
		//cerr << "go back to level " << level << " and imply " << out_vcp.v/2 << " to " << 1-(out_vcp.v&1) << endl;
		VCP.v = out_vcp.v;
		VCP.cr = out_vcp.cr;
		VCP.pos = out_vcp.pos;
		for (int i = /*qbp->decisionLevel();*/alive.size()-1; i > level-2;i--) {
			alive[i] = false;
			//cerr << "set dead" << i << endl;
		}
		qbp->addImplication(VCP);
	}
	bool propagate() {
		//if (qbp->propQ.size()==1) cerr << "eas=" << qbp->eas[qbp->propQ[0].v/2] << endl;
		bool r = qbp->propagate(confl, confl_var, confl_partner, false, false, 1000000);
		return r;
	}
	bool analyzeImplicationGraph(ValueConstraintPair& out_info, int &target_level) {
		QBPSolver::ValueConstraintPair out_vcp;
		int out_target_dec_level;
		ca_vec<CoeVar>   out_learnt;

		if (qbp->getQuantifier(confl_var) == EXIST) {
			//out_vcp.v = -1;
			out_vcp.pos = -1;
			//out_vcp.cr = -1;
			//cerr << "TL=" << out_target_dec_level;
			if (qbp->analyze(confl, confl_var, confl_partner, out_learnt, out_target_dec_level, out_vcp) && out_vcp.pos != -1) {
				target_level = out_target_dec_level;
				out_info.cr = out_vcp.cr;
				out_info.pos = out_vcp.pos;
				out_info.v = out_vcp.v;
				//if (qbp->propQlimiter[out_vcp.v] <= 0) {
				//   qbp->propQ.push(out_vcp);
				//   qbp->propQlimiter[out_vcp.v] = qbp->propQ.size();
				//} else qbp->propQ[qbp->propQlimiter[out_vcp.v]-1] = out_vcp;
				return true;
			} else return false;
		}  else {
			//out_vcp.v = -1;
			out_vcp.pos = -1;
			//out_vcp.cr = -1;
			if (qbp->analyze4All(confl, confl_var, out_learnt, out_target_dec_level, out_vcp) && out_vcp.pos != -1) {
				target_level = out_target_dec_level;
				out_info.cr = out_vcp.cr;
				out_info.pos = out_vcp.pos;
				out_info.v = out_vcp.v;
				//if (qbp->propQlimiter[out_vcp.v] <= 0) {
				//   qbp->propQ.push(out_vcp);
				//   qbp->propQlimiter[out_vcp.v] = qbp->propQ.size();
				//} else qbp->propQ[qbp->propQlimiter[out_vcp.v]-1] = out_vcp;
				return true;
			} else return false;
		}
	}

	void unassignVariablesUntil(int v) {
		int wv;
		if (qbp->getTrailSize()>0) wv = qbp->getTrailsLast();
		else wv = -1;
		//cerr << "Trail (" << v << "," << qbp->decisionLevel()-1 << "):";
		for (int z = 0; z < qbp->getTrailSize();z++) {
			//cerr << qbp->trail[z] << (qbp->vardata[qbp->trail[z]].reason!=CRef_Undef ?"i-" :"-") << qbp->vardata[qbp->trail[z]].level << " ";
		}
		//cerr << endl;
		while (wv > -1 && wv != v) {
			qbp->unassign(wv, false);
			if (qbp->getTrailSize()>0) wv = qbp->getTrailsLast();
			else wv = -1;
		}
		assert(wv == v);
		qbp->unassign(wv, false);
	}
	coef_t yMySolve() {
		coef_t score;
		coef_t value;
		coef_t r;
		int v;
		ValueConstraintPair VCP;
		int target_level;

		if (nodeValueKnown(r)) return r;
		if (!selectVariable(v)) return p_infinity;
		if (qbp->getQuantifier(v)==EXIST) score = n_infinity;
		else                              score = p_infinity;
//cerr << "select " << v << " in " << qbp->decisionLevel() << endl;
		int p = choosePolarity();
		for (int i = 0; i <= 1;i++) {
			if (!levelAlive()) {
				//cerr << "leave dead level " << qbp->decisionLevel() << endl;
				//for (int o=0;o<alive.size();o++) cerr << "o=" << o << "A=" << alive[o];
				//cerr << endl;
				return score;
			}
			qbp->increaseDecisionLevel();
			bool success = assignVariable(!p ? i : 1-i ,v);
			//cerr << "assign " << v << "=" << (!p ? i : 1-i) << endl;
 			if (!success) continue;
			do {
				//if (qbp->propQ.size()>0) cerr << "prop1" << endl;
				success = propagate();
				//if (qbp->propQ.size()>0) cerr << "prop2" << endl;
				//else cerr << "S=" << success << endl;
				//cerr << "Trail after P(" << v << "," << qbp->decisionLevel()-1 << "):";
				for (int z = 0; z < qbp->getTrailSize();z++) {
					//cerr << qbp->trail[z] << (qbp->vardata[qbp->trail[z]].reason!=CRef_Undef ?"i-" :"-") << qbp->vardata[qbp->trail[z]].level << " ";
				}
				//cerr << endl;

				if (!success) {
					if (analyzeImplicationGraph(VCP, target_level)) {
						killLevelsUntil(target_level, VCP);
						//(v);
						//qbp->decreaseDecisionLevel();
						//return score;
						break;
					}
				} else {
					preRec();
				    value = yMySolve();
				    postRec();
					if (qbp->getQuantifier(v) == EXIST) score = max(score, value);
					if (qbp->getQuantifier(v) == UNIV ) score = min(score, value);
				}
			} while (levelAlive() && deepImplicationAvailable());
			//cerr << "unassign " << v << endl;
			unassignVariablesUntil(v);
			qbp->decreaseDecisionLevel();
	  	}
		//cerr << "leave level " << qbp->decisionLevel() << " with var " << v << endl;
		//cerr << "Trail3 (" << v << "," << qbp->decisionLevel()-1 << "):";
		for (int z = 0; z < qbp->getTrailSize();z++) {
			//cerr << qbp->trail[z] << (qbp->vardata[qbp->trail[z]].reason!=CRef_Undef ?"i-" :"-") << qbp->vardata[qbp->trail[z]].level << " ";
		}
		//cerr << "---------->" << score << endl;
		if (!levelAlive()) {
			//cerr << "leave deadDD level " << qbp->decisionLevel() << endl;
			return score;
		}
		return score;
	}

	coef_t ySolve(time_t ini_time) {
#ifdef NEWSOLVE
		preRec();
	    qbp->increaseDecisionLevel();
	    if (yMySolve() > 0) cerr << "has solution" << endl;
	    else cerr << "has no solution" << endl;
	    postRec();
	    qbp->decreaseDecisionLevel();
	    return 0.0;
#endif
		coef_t r;
		HTable *HT = qbp->getHTable();
		std::vector<int> pt2leaders;
		std::vector<int> bitcnts;
		qbp->setInitilizationTime(ini_time);
	    qbp->increaseDecisionLevel();
	    r = qbp->search(0, (void*)this);
		for (int i = 0; i < qbp->nVars(); i++) {
			bitcnts.push_back(integers[i].bitcnt);
			pt2leaders.push_back(integers[i].pt2leader);
		}
	    if ((processNo & 1) == 0) {
	    	if (fabs(qbp->getGlobalScore()) < -qbp->getNegativeInfinity()) {
				double min_slack = qbp->finalSolutionCheck(bitcnts,pt2leaders,objInverted);
				for (int i = 0; i < qbp->nVars(); i++) {
					//cerr << "x" << i << "(" << qbp->getType(i) << "," << qbp->getBlock(i) << "," << integers[i].bitcnt << ") ";
					if (qbp->getType(i) == 5000 /*CONTINUOUS*/) {
						if (qbp->getLowerBound(i) == qbp->getUpperBound(i)) {
							cerr << qbp->getLowerBound(i) << " ";
						} else if (qbp->getBlock(i) == 1) cerr << qbp->getFirstStageSolutionValue(i) << " ";
							   else cerr << "c" <<  qbp->getBlock(i) << " ";
					} else if (qbp->getBlock(i) == 1){
						if (integers[i].bitcnt > 1) {
							//cerr << "Var " << i<< " hat " << integers[i].bitcnt << "bits. Leader:" << integers[i].pt2leader;
							if (integers[i].pt2leader == i) {
								int res = 0;
								for (int z = 0;z < integers[i].bitcnt;z++) {
									res = 2*res + qbp->getFirstStageSolutionValue(i+z);
									//cerr << " | " << qbp->getFirstStageSolutionValue(i+z) << " | ";
								}
								cerr << res << " ";
								i+=integers[i].bitcnt;
								i--;
							} else cerr << "Error: missing bit" << endl;
						} else
							cerr << qbp->getFirstStageSolutionValue(i) << " ";
					} else {
						cerr << "s" << qbp->getBlock(i) << " ";
					}
				}
				cerr << endl;
	    	}
	    }
	    while (qbp->getVarPriorityQueueSize() > 0) {
	    	qbp->extractVarPriorityQueueMinimum();
	    }
		HT->~HTable();
	    if (info_level >= 0) return r;
	    else return (r > (coef_t)0 ? (coef_t)1 : (coef_t)0);
	}
	yInterface() {
		yParamMaxHashSize = 10000000;
		timeout = time(NULL) + 1000000000;
		info_level = 1;
		qbp = 0;
	    result = (coef_t)0;
	    qbp = 0;
	    QlpStSolve = 0;
	    LPoffset = 0.0;
	    confl = CRef_Undef;
	    confl_partner = CRef_Undef;
	    offset_shift = 0.0;
	    confl_var = 0;
	}

	double computeCutRatio(vector< pair<unsigned int, double> >& cut);
	double finalSolutionCheck();

#ifndef FIND_BUG
	virtual int GenerateCutAndBranchCuts( extSol::QpExternSolver& externSolver, vector< vector< data::IndexedElement > > &listOfCutsLhs,
			       vector< data::QpNum > &listOfCutsRhs, vector<int> &listOfCutsVars,
			       int treedepth, int currentBlock, bool &global_valid, std::vector<unsigned int> &candidates, int cuttype, int* types, int8_t *assigns, unsigned int initime, int* solu, int *fixs, int *blcks);
#else
	virtual int GenerateCutAndBranchCuts( extSol::QpExternSolver& externSolver, vector< vector< data::IndexedElement > > &listOfCutsLhs,
			       vector< data::QpNum > &listOfCutsRhs,
			       int treedepth, int currentBlock, bool &global_valid, std::vector<unsigned int> &candidates, int cuttype, int* types, int8_t *assigns, unsigned int initime);
#endif
	virtual void getRCandB(extSol::QpExternSolver& externSolver);
	virtual int isReducedCostFixed( double z, double lpval, int ix, double solx, double &rc);
	virtual void setBranchingDecision(int &pick, int &left, int &right);
	virtual void moveUp(coef_t value, coef_t uBound, int status);
	virtual void moveDown(int toLevel, int pick, int val, int val_ix);

	std::vector<double> getFirstStageSolution();
	~yInterface() {
		//delete qbp;
		//delete QlpStSolve;
	}
};


#endif /* YINTERFACE_H_ */
