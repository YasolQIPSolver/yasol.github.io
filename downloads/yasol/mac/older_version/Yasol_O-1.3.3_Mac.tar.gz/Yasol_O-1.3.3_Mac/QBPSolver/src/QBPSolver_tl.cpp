/*
*
* Yasol: QBPSolver_tl.cpp -- Copyright (c) 2012-2017 Ulf Lorenz
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
* LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
* OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

using namespace std;

// TOR wurde entfernt!!!!!
// bei "H" Abbruch der Schleife eingef�gt

#include "QBPSolver.h"
#include "yInterface.h"
#include <cmath>
#include <iomanip>
//2007,2067,857
//#define USE_QLPSOLVE 0
#define LP_PENALTY 32
//1/*32*/

#define DERIVECBC2013
//#define ANABFC_2013
//#define FBA2013
#define CONV_BLOCK_RIGHT_SHIFT 2

#define RESOLVE_FIXED(a) { resolveFixed(a,true); }
#define RESOLVE_FIXED_NOCUTS(a) { resolveFixed(a,false); }

#define useFULLimpl 0
#define SWITCH_ON_CRITICAL 0 // TODO DIES IST DER WICHTIGESTE SWITCH UM ZUR FUNKTIONIERENDEN VERSION ZURUECK KOMMEN!!!!

static ca_vec<CoeVar> spezialconstraint;
//static yInterface yIF;

static int numLPs=0;
static int numbLPs=0;
static unsigned int its=0;
static unsigned int cnt=0;

static int computeLpIts() {
	if (cnt > 100) {
		int x = 2*its / cnt;
		if (x > 10) return x;
		else return 10;
	} else return -1;
}
static void adjustLpIts(int i) {
	cnt++;
	its += i;
}

void QBPSolver::moveDown(int d, int decvar, int decpol, int pick) {
  ((yInterface*)yIF)->moveDown(d, decvar, decpol, pick);
}

void QBPSolver::moveUp(coef_t v, coef_t b, int status) {
  ((yInterface*)yIF)->moveUp(v, b, status);
}


algorithm::Algorithm::QlpSolution QBPSolver::resolveDEP() {
	return ((yInterface*)yIF)->resolveDEP(assigns.getData());
}

data::Qlp* QBPSolver::BinQlp() {
	return &(((yInterface*)yIF)->qlp);
}

void QBPSolver::makeAsnapshot(std::vector< std::pair<int,int> > &clist) {
	QlpStSolve.getExternSolver(maxLPStage).clearLP_snapshot();

	for (int i = 1; i < constraints.size();i++) {
		Constraint &c = constraintallocator[constraints[i]];
		if (c.header.learnt) break;
		if (c.saveFeas(assigns)) continue;
		{
			std::vector<data::IndexedElement> lhs;
			data::QpRhs rhs;
			double r = -c.header.rhs;
			for (int j = 0; j < c.size();j++) {
				double coef;
				data::IndexedElement e;

				if (sign(c[j])) coef = -c[j].coef;
				else coef = c[j].coef;
				e.   index = var(c[j]);
				e.value = -coef;
				if (assigns[e.index] == 0)
					continue;
				else if (assigns[e.index] == 1) {
					r = r -coef;
					continue;
				}
				lhs.push_back(e);
			}
			rhs.set(data::QpRhs::RatioSign::smallerThanOrEqual, r);
			QlpStSolve.getExternSolver(maxLPStage).addLProw_snapshot(lhs,rhs);
		}
	}
	Constraint &c = constraintallocator[constraints[0]];
	{
		std::vector<data::IndexedElement> lhs;
		data::QpRhs rhs;
		double r = -c.header.rhs;
		for (int j = 0; j < c.size();j++) {
			double coef;
			data::IndexedElement e;
			if (sign(c[j])) coef = -c[j].coef;
			else coef = c[j].coef;
		    e.index = var(c[j]);
			e.value = -coef;
			if (assigns[e.index] == 0)
				continue;
			else if (assigns[e.index] == 1) {
				r = r -coef;
				continue;
			}
			lhs.push_back(e);
		}
		rhs.set(data::QpRhs::RatioSign::smallerThanOrEqual, r);
		QlpStSolve.getExternSolver(maxLPStage).addLPobj_snapshot(lhs, rhs);
	}
	QlpStSolve.getExternSolver(maxLPStage).reinitLPcols_snapshot();
	((yInterface*)yIF)->sortCols(maxLPStage);
	((yInterface*)yIF)->findSymmetries(QlpStSolve, maxLPStage, true, clist, type.getData(), block.getData(), assigns.getData());
}

void QBPSolver::QLPSTSOLVE_SOLVESTAGE(double alpha, unsigned int stage, algorithm::Algorithm::SolutionStatus& status, data::QpNum &lb,
		data::QpNum &ub, std::vector<data::QpNum>& solution,
		algorithm::Algorithm::SolutionCase SC, int maxSubProbToSolve, int maxSimplexIt) {
	//cerr << "SOLVED AN LP!" << endl;
	int baselevel=decisionLevel();
	if (downward==false /*&& !feasPhase*/) {
		do {
			baselevel--;
		} while (baselevel > 1 && rembase[baselevel].variables.size()==0);
		int m = QlpStSolve.getExternSolver( maxLPStage ).getRowCount();
		if (baselevel >= 1 && rembase[baselevel].constraints.size() < m && rembase[baselevel].variables.size()>0) {
			for (int i = rembase[baselevel].constraints.size(); i < m; i++)
			    rembase[baselevel].constraints.push_back(extSol::QpExternSolver::NotABasicStatus);
			QlpStSolve.getExternSolver( maxLPStage ).setBase(rembase[baselevel]);
		}
	}
	QlpStSolve.solveStage(stage, status, lb, ub, solution, SC, maxSubProbToSolve, maxSimplexIt);
	assert(rembase.size() > decisionLevel());
	if (status == algorithm::Algorithm::FEASIBLE || status == algorithm::Algorithm::INFEASIBLE) {
		rembase[decisionLevel()].variables.clear();
		rembase[decisionLevel()].constraints.clear();
		QlpStSolve.getExternSolver( maxLPStage ).getBase(rembase[decisionLevel()]);
	}
	downward = true;

	if (status == algorithm::Algorithm::FEASIBLE) {
		lb = lb.asDouble() + ((yInterface*)yIF)->getLPoffset();// - objOffset;
		ub = ub.asDouble() + ((yInterface*)yIF)->getLPoffset();// - objOffset;
		if (-lb.asDouble() >= alpha) {
			((yInterface*)yIF)->adaptSolution(solution, type.getData(), assigns.getData());
			double result = -objOffset+0.0;
			double rem_val = -lb.asDouble();
			Constraint &c = constraintallocator[constraints[0]];
			if (0) {
				for (int i = 0; i < c.size();i++) {
					if (1/*type[var(c[i])]==CONTINUOUS && assigns[var(c[i])] == extbool_Undef && !isFixed(var(c[i]))*/) {
						if (!sign(c[i])) result = result + c[i].coef * solution[var(c[i])].asDouble();
						else result = result - c[i].coef * solution[var(c[i])].asDouble();
						continue;
					}
					if (assigns[var(c[i])] != extbool_Undef || isFixed(var(c[i]))) {
						if (assigns[var(c[i])] != extbool_Undef) {
							if( abs((double)assigns[var(c[i])]-solution[var(c[i])].asDouble()) > 0.001 ) {
								if (type[var(c[i])]==BINARY) cerr << "Warning: numerical issues 3:" << (double)assigns[var(c[i])] << " " << solution[var(c[i])].asDouble() << " " << (int)((yInterface*)yIF)->getIsInSOSvars(var(c[i])) << endl;
							}
							if (sign(c[i])) result = result - c[i].coef * assigns[var(c[i])];
							else result = result + c[i].coef * assigns[var(c[i])];
						} else {
							if( abs((double)getFixed(var(c[i]))-solution[var(c[i])].asDouble()) > 0.001 ) {
								if (type[var(c[i])]==BINARY) cerr << "Warning: numerical issues 4" << endl;
							}
							if (sign(c[i])) result = result - c[i].coef * getFixed(var(c[i]));
							else result = result + c[i].coef * getFixed(var(c[i]));
						}
					} else {
						assert(solution[var(c[i])] >= -0.000001);
						if (solution[var(c[i])] > 0.5) {
							if (sign(c[i])) result = result - c[i].coef * 1.0;
							else result = result + c[i].coef * 1.0;
						}
					}
				}
			} else {
				result = rem_val;
			}

			if (abs(result-rem_val) > 1.0) {
				cerr << "!!!" << result << "," << rem_val << "," << result-rem_val << "!!" << endl;
				assert(0);
			}
		}
	}
}

void QBPSolver::QLPSTSOLVE_TIGHTEN_OBJ_FUNC_BOUND(unsigned int stage, const data::QpNum& newbound) {
	//cerr << "T: geforderter Bound=" << newbound.asDouble() << " angepasster Bound=" << newbound+((yInterface*)yIF)->getLPoffset() << endl;
	QlpStSolve.tightenObjFuncBound(stage, newbound+((yInterface*)yIF)->getLPoffset() );
}

void QBPSolver::QLPSTSOLVE_WEAKEN_OBJ_FUNC_BOUND(unsigned int stage, const data::QpNum& newbound) {
	//cerr << "W: geforderter Bound=" << newbound.asDouble() << " angepasster Bound=" << newbound+((yInterface*)yIF)->getLPoffset() << endl;
	QlpStSolve.weakenObjFuncBound(stage, newbound+((yInterface*)yIF)->getLPoffset() );
}

bool QBPSolver::checkSolution(double a, bool free_uni_av, bool blockvar_av, int best_cont_ix, int pick, double lpopt, int &lead, std::vector<data::QpNum> &solution) {
	algorithm::Algorithm::SolutionStatus statush7;
	std::vector<data::QpNum> solutionh7;
	data::QpNum lbh7;
	data::QpNum ubh7;
	lead = -1;
	// erster Check: numerical instability?
	//cerr << "STAT:" << QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus();
	if (QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus() != extSol::QpExternSolver::OPTIMAL) {
		if (info_level >= 2) cerr << "n" << QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus();
		return false;
	}
	//ohne check geht, wenn:
	//free_uni_av || (blockvar_av && best_cont_ix == -1 && block[pick] != maxBlock) || best_cont_ix != -1
	//freie Allvar. vorh ODER (Var im Block und ganzzahlige Lsg && nicht im letzten Block) ODER best_cont_ix != -1


    if (!(free_uni_av || (blockvar_av && best_cont_ix == -1 && block[pick] != maxBlock) || best_cont_ix != -1) && /*
    		-lpopt > (double)constraintallocator[constraints[0]].header.rhs*/ /*a*/ -lpopt > a) {
    	// zweiter check: objective
    	Constraint &c = constraintallocator[constraints[0]];
    	coef_t obj=-objOffset;
    	//cerr << "objOffset=" << objOffset << endl;
    	coef_t v;
    	for (int z=0; z < c.size();z++) {
    		//if (type[var(c[z])] == BINARY) v = (solution[var(c[z])].asDouble() > 0.5 ? 1.0 : 0.0);
    		if (assigns[var(c[z])] != extbool_Undef) {
    			v = (double)assigns[var(c[z])];
    		} else if (0&&isFixed(var(c[z]))) {
    			v = getFixed(var(c[z]));
    		} else if (type[var(c[z])] == BINARY) {
    			v = (solution[var(c[z])].asDouble() > 0.5 ? 1.0 : 0.0);
    		} else v = solution[var(c[z])].asDouble();
    		if (sign(c[z])) {
    			obj = obj - c[z].coef * v;
    		} else {
    			obj = obj + c[z].coef * v;
    		}
    	}
    	if (/*-lpopt*/obj <= a) { //(double)constraintallocator[constraints[0]].header.rhs) {
    		//cerr << "no improvement ";
    		return false;
    	} else {
    		 bool reals_avail = false;
    		 //cerr << "checking ";
			 for (int z = 0; z < nVars();z++) {
				if (type[z] != BINARY && assigns[z] == extbool_Undef) reals_avail = true;
				if (type[z] == BINARY && assigns[z] == extbool_Undef && (!isFixed(z)||fixdata[z].reason==CRef_Undef) && eas[z] == EXIST) {
					int bitcnt = ((yInterface*)yIF)->integers[z].bitcnt;
					int index = ((yInterface*)yIF)->integers[z].index;
					int leader = ((yInterface*)yIF)->integers[z].pt2leader;
					int leader_index = ((yInterface*)yIF)->integers[leader].index;
					assert(leader == leader_index);

					if(0)if (bitcnt > 10 && z - leader < bitcnt - 10) {
						while (assigns[leader] != extbool_Undef) {
							leader++;
						}
						lead = leader;
						//cerr << "Leader found:" << leader << endl;
						return false;
					}
				}
			}
			if (1||reals_avail) {
				//cerr << "c";
				for (int i = 1; i < constraints.size();i++) {
					if (constraintallocator[constraints[i]].header.learnt) break;
					Constraint &c = constraintallocator[constraints[i]];
					coef_t lhs=0.0;
					for (int j = 0; j < c.size();j++) {
						if (assigns[var(c[j])]!=extbool_Undef && type[var(c[j])] == BINARY) {
							if (fabs(solution[var(c[j])].asDouble() - assigns[var(c[j])]) > 0.01) {
								cerr << "WRONG BIN:" << fabs(solution[var(c[j])].asDouble() - (int)assigns[var(c[j])]) << "," << (int)((yInterface*)yIF)->getIsInSOSvars(var(c[j])) << endl;
								cerr << vardata[var(c[j])].reason << " und " << vardata[var(c[j])].level << "," << decisionLevel() << endl;
							}
							solution[var(c[j])] = assigns[var(c[j])];
							coef_t x_j = (solution[var(c[j])].asDouble() > 0.5 ? 1.0 : 0.0);
							if (sign(c[j])) lhs = lhs - c[j].coef*x_j;
							else lhs = lhs + c[j].coef*x_j;
						} else if (0&&isFixed(var(c[j])) && type[var(c[j])] == BINARY) {
							if (fabs(solution[var(c[j])].asDouble() - getFixed(var(c[j]))) > 0.01) cerr << "f";// "WRONG BIN2:" << fabs(solution[var(c[j])].asDouble() - getFixed(var(c[j]))) << endl;
							solution[var(c[j])] = getFixed(var(c[j]));
							coef_t x_j = (solution[var(c[j])].asDouble() > 0.5 ? 1.0 : 0.0);
							if (sign(c[j])) lhs = lhs - c[j].coef*x_j;
							else lhs = lhs + c[j].coef*x_j;
						} else if (type[var(c[j])] == BINARY) {
							coef_t x_j = (solution[var(c[j])].asDouble() > 0.5 ? 1.0 : 0.0); // ROUNDING!
							if (sign(c[j])) lhs = lhs - c[j].coef*x_j;//solution[var(c[j])].asDouble();
							else lhs = lhs + c[j].coef*x_j;//solution[var(c[j])].asDouble();
						} else {
							if (sign(c[j])) lhs = lhs - c[j].coef*solution[var(c[j])].asDouble();
							else lhs = lhs + c[j].coef*solution[var(c[j])].asDouble();
						}
					}
					if (lhs < c.header.rhs - fabs(c.header.rhs)*1e-12 - 5*1e-12 ) {
						//cerr << "lhs=" << lhs << ", >=? " << c.header.rhs << endl;
						std::vector<data::QpNum> ubs;
						std::vector<data::QpNum> lbs;
						QlpStSolve.getExternSolver( maxLPStage ).getLB(lbs);
						QlpStSolve.getExternSolver( maxLPStage ).getUB(ubs);
						/*for (int j = 0; j < c.size();j++) {
							if (sign(c[j])) cerr << "-" << c[j].coef << "x" << var(c[j]) << "=" <<  solution[var(c[j])].asDouble() << "," <<  lbs[var(c[j])].asDouble() << "," << ubs[var(c[j])].asDouble() << " | ";
							else            cerr << "+"<< c[j].coef  << "x" << var(c[j]) << "=" <<  solution[var(c[j])].asDouble() << "," <<  lbs[var(c[j])].asDouble() << "," << ubs[var(c[j])].asDouble() << " | ";
						}
						cerr << endl;
						*/
						//assert(0);
						if (info_level >= 5) cerr << "F";
						/*for (int hh = 0; hh < nVars();hh++) {
		      	      		if (getFixed(hh) == extbool_Undef && assigns[hh] == extbool_Undef) {
		      	         	    QlpStSolve.setVariableLB(hh,0,type.getData());
		      	         	    QlpStSolve.setVariableUB(hh,1,type.getData());
		      	      		} else if (assigns[hh] != extbool_Undef) {
		      	      		    QlpStSolve.setVariableFixation(hh,(double)assigns[hh],type.getData());
		      				} else {
		      					QlpStSolve.setVariableFixation(hh,(double)getFixed(hh),type.getData());
		      				}

							updateStageSolver(maxLPStage,hh,hh);
						}
						while (dirtyLPvars.size() > 0) dirtyLPvars.pop();
						QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, statush7, lbh7, ubh7, solutionh7,algorithm::Algorithm::WORST_CASE,-1,-1);
						cerr << "lhs=" << lhs << ", >=? " << c.header.rhs << " NEWRHS=" << lbh7.asDouble() << endl;
						*/
						return false;
					}
				}
			}
			if (0&&reals_avail) {
				std::vector<int> Controls;
				for (int z = 0; z < nVars();z++) {
					if (type[z] == BINARY && assigns[z] == extbool_Undef && (!isFixed(z)||fixdata[z].reason==CRef_Undef) && eas[z] == EXIST) {
						data::QpNum re = (solution[z].asDouble() >= 0.5 ? 1.0 : 0.0);
						QlpStSolve.setVariableFixation(z,re,type.getData());
						if (!isDirty[z]) {
							dirtyLPvars.push(z);
							isDirty[z] = true;
						}
						Controls.push_back(z);
					}
				}
				for (int hh = 0; hh < dirtyLPvars.size();hh++) {
      	      		if (getFixed(dirtyLPvars[hh]) == extbool_Undef && assigns[dirtyLPvars[hh]] == extbool_Undef ) {
						if (type[dirtyLPvars[hh]] == BINARY && eas[dirtyLPvars[hh]] == EXIST) {
							QlpStSolve.setVariableLB(dirtyLPvars[hh],0,type.getData());
							QlpStSolve.setVariableUB(dirtyLPvars[hh],1,type.getData());
						}
      	      		} else if (assigns[dirtyLPvars[hh]] != extbool_Undef) {
      	      		    if (USE_ASSIGNVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)assigns[dirtyLPvars[hh]],type.getData());
      				} else {
      					if (USE_EARLYVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)getFixed(dirtyLPvars[hh]),type.getData());
      				}
      	  		    MPI_Send(recvBuf, 1, MPI_CHAR, processNo+1,UPD_CONSTRAINTS,MPI_COMM_WORLD);
					updateStageSolver(converted_block[pick] >> CONV_BLOCK_RIGHT_SHIFT,dirtyLPvars[hh],dirtyLPvars[hh]);
					isDirty[dirtyLPvars[hh]] = false;
				}
				while (dirtyLPvars.size() > 0) dirtyLPvars.pop();
				QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, statush7, lbh7, ubh7, solutionh7,algorithm::Algorithm::WORST_CASE,-1,-1);
				if (statush7 == algorithm::Algorithm::INFEASIBLE) {
					while (Controls.size()>0) {
						QlpStSolve.setVariableLB(Controls[Controls.size()-1],0,type.getData());
						QlpStSolve.setVariableUB(Controls[Controls.size()-1],1,type.getData());
						if (!isDirty[Controls[Controls.size()-1]]) {
							dirtyLPvars.push(Controls[Controls.size()-1]);
							isDirty[Controls[Controls.size()-1]] = true;
						}
						Controls.pop_back();
					}
					lead = pick;
					return false;
					//cerr << "ps";
				}
				while (Controls.size()>0) {
					QlpStSolve.setVariableLB(Controls[Controls.size()-1],0,type.getData());
					QlpStSolve.setVariableUB(Controls[Controls.size()-1],1,type.getData());
					if (!isDirty[Controls[Controls.size()-1]]) {
						dirtyLPvars.push(Controls[Controls.size()-1]);
						isDirty[Controls[Controls.size()-1]] = true;
					}
					Controls.pop_back();
				}
			}

    	}
    }
    return true;
}

bool QBPSolver::checkRounding(double a, int pick, std::vector<data::QpNum> &solution, double lpopt, double &nlpopt) {
	//algorithm::Algorithm::SolutionStatus statush7;
	//std::vector<data::QpNum> solutionh7;
	//data::QpNum lbh7;
	//data::QpNum ubh7;
	//lead = -1;
	// erster Check: numerical instability?
	//cerr << "STAT:" << QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus();
#ifndef FIND_BUG
	return false; // unklar seit wann
#endif
	if (QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus() != extSol::QpExternSolver::OPTIMAL) {
		//cerr << "n" << QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus();
		return false;
	}
    if (-lpopt > a) {
    	// zweiter check: objective
    	Constraint &c = constraintallocator[constraints[0]];
    	coef_t obj=-objOffset;
    	//cerr << "objOffset=" << objOffset << endl;
    	coef_t v;
    	for (int z=0; z < c.size();z++) {
    		//if (type[var(c[z])] == BINARY) v = (solution[var(c[z])].asDouble() > 0.5 ? 1.0 : 0.0);
    		if (assigns[var(c[z])] != extbool_Undef) {
    			v = (double)assigns[var(c[z])];
    		} else if (0&&isFixed(var(c[z]))) {
    			v = getFixed(var(c[z]));
    		} else if (type[var(c[z])] == BINARY) {
    			v = (solution[var(c[z])].asDouble() > 0.5 ? 1.0 : 0.0);
    		} else v = solution[var(c[z])].asDouble();
    		if (sign(c[z])) {
    			obj = obj - c[z].coef * v;
    		} else {
    			obj = obj + c[z].coef * v;
    		}
    	}
    	if (/*-lpopt*/obj <= a) { //(double)constraintallocator[constraints[0]].header.rhs) {
    		//cerr << "no improvement ";
    		return false;
    	} else {
    		 bool reals_avail = false;
    		 nlpopt = obj;
    		 //cerr << "checking ";
			 for (int z = 0; z < nVars();z++) {
				if (type[z] != BINARY && assigns[z] == extbool_Undef) reals_avail = true;
			}
			if (1) {
				//cerr << "c";
				for (int i = 1; i < constraints.size();i++) {
					if (constraintallocator[constraints[i]].header.learnt) break;
					Constraint &c = constraintallocator[constraints[i]];
					coef_t lhs=0.0;
					for (int j = 0; j < c.size();j++) {
						if (assigns[var(c[j])]!=extbool_Undef && type[var(c[j])] == BINARY) {
							if (fabs(solution[var(c[j])].asDouble() - assigns[var(c[j])]) > 0.01) {
								cerr << "WRONG BIN:" << fabs(solution[var(c[j])].asDouble() - (int)assigns[var(c[j])]) << "," << (int)((yInterface*)yIF)->getIsInSOSvars(var(c[j])) << endl;
								cerr << vardata[var(c[j])].reason << " und " << vardata[var(c[j])].level << "," << decisionLevel() << endl;
							}
							solution[var(c[j])] = assigns[var(c[j])];
							coef_t x_j = (solution[var(c[j])].asDouble() > 0.5 ? 1.0 : 0.0);
							if (sign(c[j])) lhs = lhs - c[j].coef*x_j;
							else lhs = lhs + c[j].coef*x_j;
						} else if (0&&isFixed(var(c[j])) && type[var(c[j])] == BINARY) {
							if (fabs(solution[var(c[j])].asDouble() - getFixed(var(c[j]))) > 0.01) cerr << "f";// "WRONG BIN2:" << fabs(solution[var(c[j])].asDouble() - getFixed(var(c[j]))) << endl;
							solution[var(c[j])] = getFixed(var(c[j]));
							coef_t x_j = (solution[var(c[j])].asDouble() > 0.5 ? 1.0 : 0.0);
							if (sign(c[j])) lhs = lhs - c[j].coef*x_j;
							else lhs = lhs + c[j].coef*x_j;
						} else if (type[var(c[j])] == BINARY) {
							coef_t x_j = (solution[var(c[j])].asDouble() > 0.5 ? 1.0 : 0.0); // ROUNDING!
							if (sign(c[j])) lhs = lhs - c[j].coef*x_j;//solution[var(c[j])].asDouble();
							else lhs = lhs + c[j].coef*x_j;//solution[var(c[j])].asDouble();
						} else {
							if (sign(c[j])) lhs = lhs - c[j].coef*solution[var(c[j])].asDouble();
							else lhs = lhs + c[j].coef*solution[var(c[j])].asDouble();
						}
					}
					if (lhs < c.header.rhs - fabs(c.header.rhs)*1e-5 - 5*1e-5 ) {
						//cerr << "lhs=" << lhs << ", >=? " << c.header.rhs << endl;
						std::vector<data::QpNum> ubs;
						std::vector<data::QpNum> lbs;
						//QlpStSolve.getExternSolver( maxLPStage ).getLB(lbs);
						//QlpStSolve.getExternSolver( maxLPStage ).getUB(ubs);
						/*for (int j = 0; j < c.size();j++) {
							if (sign(c[j])) cerr << "-" << c[j].coef << "x" << var(c[j]) << "=" <<  solution[var(c[j])].asDouble() << "," <<  lbs[var(c[j])].asDouble() << "," << ubs[var(c[j])].asDouble() << " | ";
							else            cerr << "+"<< c[j].coef  << "x" << var(c[j]) << "=" <<  solution[var(c[j])].asDouble() << "," <<  lbs[var(c[j])].asDouble() << "," << ubs[var(c[j])].asDouble() << " | ";
						}
						cerr << endl;
						*/
						//assert(0);
						//cerr << "F2";
						/*for (int hh = 0; hh < nVars();hh++) {
		      	      		if (getFixed(hh) == extbool_Undef && assigns[hh] == extbool_Undef) {
		      	         	    QlpStSolve.setVariableLB(hh,0,type.getData());
		      	         	    QlpStSolve.setVariableUB(hh,1,type.getData());
		      	      		} else if (assigns[hh] != extbool_Undef) {
		      	      		    QlpStSolve.setVariableFixation(hh,(double)assigns[hh],type.getData());
		      				} else {
		      					QlpStSolve.setVariableFixation(hh,(double)getFixed(hh),type.getData());
		      				}

							updateStageSolver(maxLPStage,hh,hh);
						}
						while (dirtyLPvars.size() > 0) dirtyLPvars.pop();
						QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, statush7, lbh7, ubh7, solutionh7,algorithm::Algorithm::WORST_CASE,-1,-1);
						cerr << "lhs=" << lhs << ", >=? " << c.header.rhs << " NEWRHS=" << lbh7.asDouble() << endl;
						*/
						return false;
					} else {
						//cerr << "R";
					}
				}
			}
    	}
    	return true;
    }
    return false;
}

#ifndef FIND_BUG  //REKV
SearchResult QBPSolver::alphabeta_loop(int t, int lsd, coef_t a, coef_t b, bool onlyone, coef_t nodeLPval, int decvar, bool decpol, bool allowQex, bool allowStrengthen, int father_ix, int sfather_ix, bool LimHorSrch) {
	int s = START;
	int mode=processNo % 2;
	int testd = 8;

	if (mode==0) {
  	    moveDown(t+1, -1, -1, -1);
		search_stack.down(n_infinity, t, lsd, a, b, onlyone, nodeLPval, decvar, decpol, allowQex, allowStrengthen, father_ix, sfather_ix, LimHorSrch);
	} else {
  	    moveDown(t+1, -1, -1, -1);
		search_stack.down(n_infinity, t, lsd+10/*testd + 10*/, a, b, onlyone, nodeLPval, decvar, decpol, allowQex, allowStrengthen, father_ix, sfather_ix, true);
	}
	int it_start_time=time(0);
	do {
		s = search_stack.getStatus();
		s = alphabeta_step(*this, search_stack, s, search_stack.result);
		//cerr << "status=" << s << " to level " << search_stack.stack_pt << endl;;
		if (s == FINISHED) {
			search_stack.result = search_stack.getResult();
			//cerr << "transported result=" << search_stack.result.value << "," << search_stack.result.u_bound << " from " << search_stack.stack_pt << " to " <<  search_stack.stack_pt-1 << endl;;
			search_stack.up();
		}
	} while (!search_stack.empty());
	if (info_level & 2) cerr << "maximum used stack size: " << search_stack.stack.capacity() * sizeof(stack_container) << endl;
	return search_stack.result;
}

//SearchResult QBPSolver::alphabeta(int t, int lsd, coef_t a, coef_t b, bool only_one, coef_t fatherval, int decvar, bool decpol, bool qex, bool alwstren, int father_ix, int sfather_ix, bool LimHorSrch) {
int QBPSolver::alphabeta_step(QBPSolver &qmip, Sstack &search_stack, int jump_status, SearchResult &result) {
    stack_container &STACK = search_stack.stack[search_stack.stack_pt];

	int &t                   = STACK.t;
	int &lsd                 = STACK.lsd;
	coef_t &a                = STACK.a;
	coef_t &b                = STACK.b;
	bool &only_one           = STACK.only_one;
	coef_t &fatherval        = STACK.fatherval;
	int &decvar				 = STACK.decvar;;
	bool &decpol             = STACK.decpol;
	bool &qex                = STACK.qex;
	bool &alwstren           = STACK.alwstren;
	int &father_ix           = STACK.father_ix;
	int &sfather_ix          = STACK.sfather_ix;
	bool &LimHorSrch         = STACK.LimHorSrch;

	int &pick                = STACK.pick;
	int &Lpick                = STACK.Lpick;
	bool &restart            = STACK.restart;
	int &oob                 = STACK.oob;
	uBndMmg &uBnds           = STACK.uBnds;
	coef_t &local_ub         = STACK.local_ub;
	int &best_val            = STACK.best_val;
	coef_t &v				 = STACK.v;
	bool &wot                = STACK.wot;


	/*
	int oob;
	int pick=-1;
	coef_t v;
	coef_t local_ub=-n_infinity;
	coef_t ubs[2];
	int best_val;
	bool restart=false;
	static uint64_t LPtim=0;
    static unsigned int LPcnt=0;
    bool wot=false;
	noMoreRestarts=false;
    */

	SearchResult V;

	HTentry *hte;
	int confl_var=-1;
	ValueConstraintPair out_vcp;
	CRef confl=CRef_Undef;
	CRef confl_partner=CRef_Undef;
	int remPick;
	int left;
	int right;

	coef_t &score = stack_score[t+1/*decisionLevel()*/];
	int8_t *val;
	val = &stack_val[/*decisionLevel()*/(t+1)<<1];
	int8_t &val_ix = stack_val_ix[/*decisionLevel()*/t+1];

	switch(jump_status) {
		case START    : goto LREK_START;
		case REK_EXIST: /*assert(val[0]>=0 && val[0]<=1 && val[1]>=0 && val[1]<=1);*/goto LREK_EXIST;
		case REK_UNIV : goto LREK_UNIV;
	    defaut        : assert(0);
	}
	LREK_START:;

	{
		while (rembase.size() <= decisionLevel()+1) {
			extSol::QpExternSolver::QpExtSolBase base;
			rembase.push_back( base );
		}
		stack_a[decisionLevel()] = a;
		stack_b[decisionLevel()] = b;

		int favour_pol;
		bool noprobe = false;
		bool ac = true;
		/*int*/ Lpick=-1;
		bool LPvariableFound = false;
		bool LP_solved = false;
		int cnt_df = 0;
		int ismono = 0;
		bool DepotAvail = false;
		bool revImplQexists = (revImplQ.size()>0?true:false);
		int revImplQpick = (revImplQexists?(revImplQ[revImplQ.size()-1].v>>1):-1);
		int revImplQpol = (revImplQexists?(revImplQ[revImplQ.size()-1].v&1):-1);
		isRevImpl[t+1] = (revImplQexists?(revImplQ[revImplQ.size()-1].pos==FORCED):false);
		if (revImplQexists) revImplQ.pop();

		num_decs++;
		level_finished[t+1] = false;
		BackJumpInfo[t+1].bj_level[0] = BackJumpInfo[t+1].bj_level[1] = -1;
		listOfCuts_lim[t+1] = listOfEnteredCuts.size();
		listOfGoms_lim[t+1] = listOfGoms.size();
		uBnds.initUBds();
		lb = n_infinity;
		ub = -n_infinity;

		assert(propQ.size() == 0);

			//if (decisionLevel() <= 2) cerr << "RESTART? " << stack_restart_ready[decisionLevel()] << " on Level " << decisionLevel() << endl;
		if (stack_restart_ready[decisionLevel()]) {
			if (info_level >= 2) cerr << "enter Restart on Level " << decisionLevel() << " pick=" << stack_pick[decisionLevel()] << " A(pick):" << (int)assigns[stack_pick[decisionLevel()]] << endl;
			if (assigns[stack_pick[decisionLevel()]] == extbool_Undef) {
			   pick = stack_pick[decisionLevel()];
			   stack_restart_ready[decisionLevel()] = false;
			   stack_val_ix[decisionLevel()] = stack_save_val_ix[decisionLevel()];
			   stack_a[decisionLevel()] = stack_save_a[decisionLevel()];
			   stack_b[decisionLevel()] = stack_save_b[decisionLevel()];
			   stack_score[decisionLevel()] = stack_save_score[decisionLevel()];
			   int8_t *hval, *hsval;
			   hval = &stack_val[decisionLevel()<<1];
			   hsval = &stack_save_val[decisionLevel()<<1];
			   hval[0] = hsval[0];
			   hval[1] = hsval[1];
			   restart = true;
			   //if (stack_val_ix[decisionLevel()] == 2) stack_val_ix[decisionLevel()] = 1;
			   if (info_level >= 2) cerr << (int)stack_val_ix[decisionLevel()] << ".";
			   //assert(0);//
			   Lpick = pick;
			   goto Lrestart;
			} else {
			   stack_restart_ready[decisionLevel()] = false;
			   stack_restart_ready[decisionLevel()+1] = false;
			}
		} else stack_restart_ready[decisionLevel()+1] = false;

		if (decisionLevel() != t+1) cerr << "Error: dl=" << decisionLevel() << " t+1=" << t+1 << endl;
		assert(decisionLevel() == t+1);
Lstart:;
        //checkHeap(pick);
        if (info_level == 6) {
			cerr << endl;
			for (int i = 0; i < 5/*scenario.size()*/; i++)
				if (i < scenario.size()) cerr << (int)assigns[scenario[i]];
				else cerr << " ";
			for (int i = 1; i < trail_lim.size();i++)
				if (eas[trail[trail_lim[i]-1]]==EXIST) cerr << (int)assigns[trail[trail_lim[i]-1]];
				else cerr << (int)assigns[trail[trail_lim[i]-1]]+2;
			cerr << endl;
		}
		//cerr << endl;
		/*if (order_heap.empty())
			  for (int rr=0; rr < nVars();rr++)
				if (assigns[rr] == extbool_Undef) {
					cerr << "fill order heap " << rr << endl;
					insertVarOrder(rr);
				}*/
		//cerr << "(" << decisionLevel() << ")";
		if (/*trail.size() == nVars()*/order_heap.empty()) {
			// helper_check_contraints();
			//massert(trail.size() == 294);
			num_leaves[decisionLevel()]++;
			if (USE_TRACKER) cerr << "l";
			for (int uu=0; uu < trail.size();uu++) if (eas[trail[uu]] == EXIST) killer[trail[uu]] = assigns[trail[uu]];
			crossUs(feasPhase);
			if (isOnTrack()) cerr << "optSolution!" << endl;
			RESOLVE_FIXED(decisionLevel());
			if (hasObjective) {
				return _StepResult(STACK,constraintallocator[constraints[0]].header.btch1.best-objOffset,constraintallocator[constraints[0]].header.btch1.best-objOffset);
			} else return _StepResult(STACK,p_infinity,p_infinity);
		}


		if (t > max_sd) {
			if (isOnTrack()) cerr << "lost solution xyv18" << endl;
			RESOLVE_FIXED(decisionLevel());
			return _StepResult(STACK,dont_know,p_infinity);
		}
		if (LimHorSrch==false && lsd < 0) {
			if (isOnTrack()) cerr << "lost solution xyw18" << endl;
			RESOLVE_FIXED(decisionLevel());
			return _StepResult(STACK,dont_know,p_infinity);
		}
		if (break_from_outside) {
			if (isOnTrack()) cerr << "lost solution xy18" << endl;
			RESOLVE_FIXED(decisionLevel());
			return _StepResult(STACK,dont_know,p_infinity);
		}
		if (time(NULL) > timeout) {
			cout << "TIMEOUT" << endl;
			exit(0);
		}

		static int Sinc=500;//250;
		//if (Sinc < num_basic) Sinc = (21*num_basic)/20;//(21*num_basic)/20;
		if (LimHorSrch==false && (discoveredNews>=2000/*(int)(10*sqrt((double)nVars()))*/ || num_learnts > 3*(/*num_orgs+*/Sinc)) && !useRestarts && /*num_learnts > 2*(num_orgs+Sinc) &&*/ num_learnts > 1*(/*num_basic+*/Sinc) &&  stack_restart_ready[decisionLevel()] == false) {
			//	if ((discoveredNews || num_learnts > 8*(num_orgs+Sinc)) && !useRestarts && /*num_learnts > 2*(num_orgs+Sinc) &&*/ num_learnts > 1*(/*num_basic+*/Sinc) &&  stack_restart_ready[decisionLevel()] == false) {
			if (info_level >= 2) cerr << "initiiere restart! num_learnts:" << num_learnts << " > 4*(num_orgs+Sinc):" << 4*(num_orgs+Sinc) << " 2*num_basic:" << 2*num_basic << " DL:" << decisionLevel() << " stack_restart_ready[decisionLevel()]:" << stack_restart_ready[decisionLevel()] << endl;
			break_from_outside = true;
			discoveredNews = 0;
			stack_restart_ready[0] = true;
			for (int l=1;l<decisionLevel();l++) {
				stack_restart_ready[l] = false;//true;
				stack_save_val_ix[l] = stack_val_ix[l];
				stack_save_a[l] = stack_a[l];
				stack_save_b[l] = stack_b[l];
				stack_save_score[l] = stack_score[l];
				int8_t *hval, *hsval;
				hval = &stack_val[l<<1];
				hsval = &stack_save_val[l<<1];
				hsval[0] = hval[0];
				hsval[1] = hval[1];
				assert(l <= trail_lim.size()-1);
				//cerr << "DL:" << l << " ready=" << stack_restart_ready[l] << " va_ix=" << (int)stack_save_val_ix[l] << " pick=" << trail[trail_lim[l]-1] << endl;
			}
			if (Sinc < num_basic * 2 / 3) Sinc *= 2;
			else Sinc = Sinc + Sinc / 3;
			useWarmRestart = true;
			/*for (int zz=0; zz < trail.size();zz++)
					  if (vardata[trail[zz]].reason != CRef_Undef)
						  constraintRescue.push(vardata[trail[zz]].reason);*/
			if (isOnTrack()) cerr << "lost solution xy19" << endl;
			RESOLVE_FIXED(decisionLevel());
			if(ana_stack.size() > 0) {
				cerr << "Warning: ana_stack size > 0" << endl;
				while(ana_seen_stack.size() > 0) {
					seen[ana_seen_stack.last()] = 0;
					ana_seen_stack.pop();
				}
				ana_stack.clear();
			}
			return _StepResult(STACK,n_infinity,p_infinity);
		}

		if (((num_props+num_decs) & 0x3fffff) == 0) {
			int num_unassigned=0;
			int64_t cntconstraints=0;
			for (int i=0; i < nVars();i++) {
				if (assigns[i] == extbool_Undef) {
					num_unassigned++;
					cntconstraints += VarsInConstraints[i].size();
				}
			}
			if (info_level & 4) {
				int j = 0;
				for (int i = 0; i < trail.size();i++) {
					if (vardata[trail[i]].level < 1) continue;
					cout << (int)(assigns[trail[i]]);
					if (j++ > 100) { cout << " ... " ; break; }
				}
				cout << " " << num_props << " "  << num_decs << " " << num_learnts << " " << (cntconstraints / (num_unassigned+1))<< " " << num_coevars << endl;
				j = 0;
				cout << "conflicts: ";
				for (int i = 0; i < nVars();i++) {
					cout << (int)(num_conflicts_per_level[i]) << " ";
					if (j++ > 100) { cout << " ... " ; break; }
				}
				cout << decisionLevel() << endl;
				j = 0;
				cout << "leaves: ";
				for (int i = 0; i < nVars();i++) {
					cout << (int)(num_leaves[i]) << " ";
					if (j++ > 100) { cout << " ... " ; break; }
				}
				cout << endl;
				j=0;
				cout << "scenario: ";
				for (int i = 0; i < scenario.size();i++) {
					cout << (int)(assigns[scenario[i]]);
					if (j++ > 100) { cout << " ... " ; break; }
				}
				cout << endl;
			}
		}

		val[0] = 0; val[1] = 1;

		assert(pick == -1 || ((yInterface*)yIF)->getIsInSOSvars(pick)==0);

		varbuf.clear();
		if (pick==-1) {
			do {
				if (order_heap.empty()) {
					if (trail.size()!=nVars()) {
						cerr << "Error: folgende Var fehlen: ";
						std::vector<int> ar;
						for (int u=0;u<nVars();u++)
							ar.push_back(0);
						for (int u=0;u<trail.size();u++)
							ar[trail[u]]=1;
						for (int u=0;u<nVars();u++)
							if(ar[u]==0) cerr << u << "," << (int)assigns[u] << "," << isFixed(u) << " ";
						cerr << endl;
					}
					assert(varbuf.size()==0);
					while (varbuf.size() > 0) {
						insertVarOrder(varbuf.last());
						varBumpActivity(varbuf.last(), -1.0, 0);
						varBumpActivity(varbuf.last(), -1.0, 1);
						varbuf.pop();
					}
					num_leaves[decisionLevel()]++;
					if (USE_TRACKER) cerr << "L";
					for (int uu=0; uu < trail.size();uu++) if (eas[trail[uu]] == EXIST) killer[trail[uu]] = assigns[trail[uu]];
					crossUs(feasPhase);
					if (isOnTrack()) cerr << "optSolution 2!" << endl;
					RESOLVE_FIXED(decisionLevel());
					if (hasObjective) {
						//if (constraintallocator[constraints[0]].header.btch1.best > -7600) cout << "OBJECTIVE:" << constraintallocator[constraints[0]].header.btch1.best << "a=" << a << " und b=" << b << endl;
						return _StepResult(STACK,constraintallocator[constraints[0]].header.wtch2.worst-objOffset,constraintallocator[constraints[0]].header.wtch2.worst-objOffset);
					} else return _StepResult(STACK,p_infinity,p_infinity);
				}
				pick = extractPick();
				if (((yInterface*)yIF)->getIsInSOSvars(pick)) {
					pick = -1;
					continue;
				}
				//cerr << "pick=" << pick << " und a[x]=" << (int)assigns[pick] << endl;
				//if (VarsInConstraints[pick].size() <= 0) varbuf.push(pick);
			} while (assigns[pick] != extbool_Undef || pick < 0/*|| VarsInConstraints[pick].size() <= 0*/);
			assert(varbuf.size()==0);
			while (varbuf.size() > 0) {
				insertVarOrder(varbuf.last());
				varBumpActivity(varbuf.last(), -1.0, 0); //moeglicherweise wurden die nur wegen
				varBumpActivity(varbuf.last(), -1.0, 1); //2-watch nicht gefunden
				varbuf.pop();
			}
		}
		assert(((yInterface*)yIF)->getIsInSOSvars(pick)==0);

		static ca_vec<double> rootLPsol(nVars()+10);
		static bool rootLPsolEx = false;
		static bool never = true;
		static int oldPQ=0;
		static int dep=20;
		//cerr << "WANT BOUND COMPUTATION." << decisionLevel() << " " << useRestarts << " " << block[pick] << " " << feasPhase << " " << LimHorSrch << endl;

		if ((info_level & 4) && decisionLevel()<=2) cerr << "+++++++++ enter node of type " << (eas[pick]==UNIV ? "ALL" : "EXIST") << " on level " << decisionLevel() << ":z.B. x" << pick << " block(p)=" << block[pick] << " " << (int)assigns[pick]<< endl;

		if (getEA(pick) != EXIST) { //TODO diese Heuristik kritisch hinterfragen. Scheint unsinnig.
			if (p_activity[pick] > n_activity[pick]) { val[0] = 0; val[1] = 1;}
			else { val[0] = 1; val[1] = 0;}
		} else {
			if (p_activity[pick] > n_activity[pick]) { val[0] = 1; val[1] = 0;}
			else { val[0] = 0; val[1] = 1;}
		}
		//if (choosePolarity(pick) == 1) { //ist ein Relikt
		//	val[0] = 1; val[1] = 0;
		//}
		assert(((yInterface*)yIF)->getIsInSOSvars(pick)==0);

		if (eas[pick] == EXIST) score = n_infinity;
		else                    score = p_infinity;
		if (HT->getEntry(&hte, trail.size()) && hte->bound != CONSTRAINT && type[pick] == BINARY) {
			if (assigns[hte->getVar()] == extbool_Undef &&
					VarsInConstraints[hte->getVar()].size() > 0 &&
					block[pick] == block[hte->getVar()]) {
				insertVarOrder(pick);
				pick = hte->getVar();
				val[0] = hte->getPol();
				val[1] = 1 - hte->getPol();
				noprobe = true;
				assert(((yInterface*)yIF)->getIsInSOSvars(pick)==0);
			}
			if (objective_iterations <= hte->objective_iterations && hte->value < dont_know && (hte->bound == FIT || hte->bound == UB)) {
				insertVarOrder(pick);
				if (isOnTrack()) cerr << "lost solution 1" << endl;
				RESOLVE_FIXED(decisionLevel());
				return _StepResult(STACK,n_infinity,n_infinity);
			}
			if (objective_iterations <= hte->objective_iterations && hte->value > dont_know && (hte->bound == FIT || hte->bound == LB)) {
				if (hte->bound == FIT) {
					insertVarOrder(pick);
					//if (hte->value >= b) return b;
					//else if (hte->value <= a) return a;
					if (isOnTrack()) cerr << "opt hash accept" << endl;
					RESOLVE_FIXED(decisionLevel());
					return _StepResult(STACK,hte->value,hte->value);
				}
				if (eas[pick] == EXIST) {
					if (hte->value > score)
						score = hte->value;
					if (score >= b) {
						insertVarOrder(pick);
						if (isOnTrack()) cerr << "opt >= b" << endl;
						RESOLVE_FIXED(decisionLevel());
						return _StepResult(STACK,score,p_infinity); //b;
					}
				} else {
					if (hte->value < score)
						score = hte->value;
					if (score <= a) {
						insertVarOrder(pick);
						if (isOnTrack()) cerr << "lost opt <= a hash" << endl;
						RESOLVE_FIXED(decisionLevel());
						return _StepResult(STACK,score,a); //b;
					}
				}
			}
		}
		assert(((yInterface*)yIF)->getIsInSOSvars(pick)==0);

		//TODO schnell check ob ub < a oder lb > b

#ifndef FIND_BUG
		if (!LimHorSrch && /*decisionLevel() <= 1 &&*/ (!useDeep || (decisionLevel() <= 1 && feasPhase == false) ) && !noprobe && t < (useDeep ? max_sd / 100 : max_sd / 10 )) {
			int probe_pick=-1;
			if (info_level & 4) cerr << "P";
			int old_ts = trail.size();
			bool probe_output = probe(probe_pick, favour_pol, (feasPhase && decisionLevel() >= max(/*max_sd / 20*/1,1)) || (!feasPhase /*&& 7*num_orgs < 1*(nVars()-trail.size())*/) ? true : false);
			// TODO : darf die Zeile 'if ...' rein?? bringt es was?? //
			//if (probe_output == false) return _StepResult(STACK,n_infinity,n_infinity);
			if (trail.size() > old_ts + (nVars()-old_ts)/10 && probe_output && feasPhase == false) {
				if (decisionLevel() == 1) {
					if (info_level >= 2) cerr << "probing fixed variables: " << trail.size()-old_ts << endl;
					PurgeTrail(trail.size() - 1, decisionLevel() - 1);
					if (isOnTrack()) cerr << "lost solution xy20" << endl;
					RESOLVE_FIXED(decisionLevel());
					break_from_outside = true;
					insertVarOrder(pick);
					return _StepResult(STACK,global_score,b);
				}
			}
			if (assigns[pick] != extbool_Undef) {
				cerr << "Warning, branching variable has unexpectedly been fixed by probing! x" << pick << endl;
				pick = -1;
				goto Lstart;
			}
			//TODO: probe muss auch confl und confl_partner liefern, fuer analysis. if (!probe_output) return -1;
			if (probe_pick != -1 && !((yInterface*)yIF)->getIsInSOSvars(probe_pick)) {
				insertVarOrder(pick);
				if (favour_pol == 1 && ac) { val[0] = 1; val[1]=0; }
				pick = probe_pick;
			}
			if (probe_pick != -1) varBumpActivity(pick, val[0]);
		}
#else
		if ( /*decisionLevel() <= 1 &&*/ (!useDeep /*|| decisionLevel() <= 1*/) && !noprobe && t < (useDeep ? max_sd / 100 : max_sd / 10) ) {
		  int probe_pick=-1;
		  cerr << "P";
		  bool probe_output = probe(probe_pick, favour_pol, (feasPhase && decisionLevel() >= max(/*max_sd / 20*/1,1)) || (!feasPhase /*&& 7*num_orgs < 1*(nVars()-trail.size())*/) ? true : false);
		  // TODO : darf die Zeile 'if ...' rein?? bringt es was?? //
		  //if (probe_output == false) return _StepResult(STACK,n_infinity,n_infinity);
		  if (assigns[pick] != extbool_Undef) {
			  cerr << "Warning, branching variable has unexpectedly been fixed by probing! " << endl;
			  pick = -1;
			  goto Lstart;
		  }
		  //TODO: probe muss auch confl und confl_partner liefern, fuer analysis. if (!probe_output) return -1;
		  if (probe_pick != -1) {
			  insertVarOrder(pick);
			  if (favour_pol == 1 && ac) { val[0] = 1; val[1]=0; }
			  pick = probe_pick;
		  }
		  if (probe_pick != -1) varBumpActivity(pick, val[0]);
		}
#endif

		Lpick = pick;
		assert(((yInterface*)yIF)->getIsInSOSvars(pick)==0);
		if (type[pick] != BINARY || (LimHorSrch==true && lsd < 10)) {
			//for (int x = 0; x < nVars();x++)
			//	assert(type[x]==CONTINUOUS || assigns[x] != extbool_Undef);
			for (int hh = 0; hh < dirtyLPvars.size();hh++) {
				if (getFixed(dirtyLPvars[hh]) == extbool_Undef && assigns[dirtyLPvars[hh]] == extbool_Undef) {
					if (type[dirtyLPvars[hh]] == BINARY && eas[dirtyLPvars[hh]] == EXIST) {
						QlpStSolve.setVariableLB(dirtyLPvars[hh],0,type.getData());
						QlpStSolve.setVariableUB(dirtyLPvars[hh],1,type.getData());
					}
				} else if (assigns[dirtyLPvars[hh]] != extbool_Undef) {
					if (USE_ASSIGNVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)assigns[dirtyLPvars[hh]],type.getData());
				} else {
					if (USE_EARLYVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)getFixed(dirtyLPvars[hh]),type.getData());
				}

				updateStageSolver(converted_block[pick] >> CONV_BLOCK_RIGHT_SHIFT,dirtyLPvars[hh],dirtyLPvars[hh]);
				isDirty[dirtyLPvars[hh]] = false;
			}
			while (dirtyLPvars.size() > 0) dirtyLPvars.pop();
			QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE,-1,/*-1*/feasPhase?-1:/*3*/3-4 /*simplex iterationen*/);
			if (status == algorithm::Algorithm::INFEASIBLE ||
					QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus() == extSol::QpExternSolver::OPTIMAL_INFEAS ) {
				if (info_level >= 2) cerr << "LP inf" << endl;
				// TODO Bsp.:net12: benders kreieren ??
				if (useBendersBackJump && status == algorithm::Algorithm::INFEASIBLE) {
					if (0) {
						QlpStSolve.getBendersCut(maxLPStage, bd_lhs, bd_sign, bd_rhs, false, vardata.getData(), eas.getData());
						for (int i = 0; i < bd_lhs.size(); i++) {
							if (type[bd_lhs[i].index] == CONTINUOUS && assigns[bd_lhs[i].index] == extbool_Undef) {
								bd_lhs.clear();
								bd_rhs = 0.0;
								cerr << "lost last bendes" << endl;
								break;
							}
						}
						in_learnt.clear();
						out_learnt.clear();
						for (int ii=0; ii < bd_lhs.size(); ii++) {
							CoeVar q = mkCoeVar(bd_lhs[ii].index, (coef_t)(bd_lhs[ii].value.asDouble() >= 0.0?bd_lhs[ii].value.asDouble():-bd_lhs[ii].value.asDouble()), bd_lhs[ii].value.asDouble() >= 0.0?false:true);
							in_learnt.push(q);
						}
						if (simplify1(in_learnt, false)) {
							if (info_level > 0) cout << "simplify leads to tautology in lp-infeas" << endl;
						}
						fastBendersAnalysis(n_infinity, (coef_t)(bd_rhs.asDouble()), in_learnt, pick, out_learnt, out_target_dec_level, out_vcp, true);
					}
				}

				if (info_level >= 2) cerr << "N";
				PurgeTrail(trail.size() - 1, decisionLevel() - 1);
				if (isOnTrack()) cerr << "lost solution xy22" << endl;
				RESOLVE_FIXED(decisionLevel());
				insertVarOrder(pick);
				return _StepResult(STACK,n_infinity, n_infinity);
			} else {
				int leader = -1;
				if (1||checkSolution(a, false, false, -1, pick, lb.asDouble(), leader, solution)) {
					Constraint &c = constraintallocator[constraints[0]];
					coef_t lhs=0.0;
					for (int j = 0; j < c.size();j++) {
						if (0&&type[var(c[j])] == BINARY) {
							coef_t x_j = (solution[var(c[j])].asDouble() > 0.5 ? 1.0 : 0.0);
							if (sign(c[j])) lhs = lhs - c[j].coef*x_j;
							else lhs = lhs + c[j].coef*x_j;
						} else {
							if (sign(c[j])) lhs = lhs - c[j].coef*solution[var(c[j])].asDouble();
							else lhs = lhs + c[j].coef*solution[var(c[j])].asDouble();
						}
					}
					if (info_level >= 2) cerr << "LP feas:" << lhs << ", lb=" << -lb.asDouble() << ", dl=" << decisionLevel() << ", lsd=" << lsd << endl;
					if (lhs > global_score && block[pick] == 1) {
						for (int iii = 0; iii < nVars();iii++) {
							if (block[iii] == 1) {
								fstStSol[iii] = solution[iii].asDouble();
							}
						}
						global_score = -lb.asDouble();
						discoveredNews += 500;
						coef_t gap;
						gap = abs(100.0*(-global_dual_bound + (-lb.asDouble()) ) / (abs(-lb.asDouble())+1e-10) );
						if (!objInverted) {
							cerr << "\n+++++ " << decisionLevel() << " ++++m score: " << -global_score << " | time: " << time(NULL) - ini_time << " | "
								<< " dual: "<< -global_dual_bound << " gap=" << gap << "%";
							if (info_level >= 2) cerr
								<< ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
							cerr << endl;
							if (info_level >= 2) printBounds(10);
							if (gap < SOLGAP) break_from_outside = true;
						} else {
							cerr << "\n+++++ " << decisionLevel() << " ++++m score: " << global_score << " | time: " << time(NULL) - ini_time << " | "
								<< " dual: "<< global_dual_bound << " gap=" << gap << "%";
							if (info_level >= 2) cerr
								<< ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
							cerr << endl;
							if (info_level >= 2) printBounds(10);
							if (gap < SOLGAP) break_from_outside = true;
						}
					}
					PurgeTrail(trail.size() - 1, decisionLevel() - 1);
					if (isOnTrack()) cerr << "lost solution xy23" << endl;
					RESOLVE_FIXED(decisionLevel());
					insertVarOrder(pick);
					return _StepResult(STACK,lhs,lhs/*-lb.asDouble(), -lb.asDouble()*/);
				} else {
					if (info_level >= 2) cerr << "Error in LP feas" << endl;
					PurgeTrail(trail.size() - 1, decisionLevel() - 1);
					if (isOnTrack()) cerr << "lost solution xy24" << endl;
					RESOLVE_FIXED(decisionLevel());
					insertVarOrder(pick);
					return _StepResult(STACK,n_infinity, -lb.asDouble());
				}
			}
		} else if(0) {
			/*
				for (int ll=variableInfoStart; ; ll= variableInfo[ll].next) {
					if (variableInfo[ll].v < 0) break;
					if (assigns[variableInfo[ll].v] == extbool_Undef) {
						LPvariableFound = true;
						pick = variableInfo[ll].v;
						break;
					}
				}
				if (decisionLevel() % 10 == 1 || !LPvariableFound) {
					LPvariableFound = false;
				}
				if (LPvariableFound) {
					if (variableInfo[pick].eval0 > variableInfo[pick].eval1) {
						val[0] = 0;
						val[1] = 1;
					} else {
						val[0] = 1;
						val[1] = 0;
					}
				}
			 */
		}

		assert(((yInterface*)yIF)->getIsInSOSvars(pick)==0);
		if (eas[pick]== EXIST && feasPhase && rootLPsolEx && rootLPsol[pick] < 1+1e-9 && ((double)LPtim/(double)(1+LPcnt) > 0.2*(double)(time(NULL)-ini_time)/(double)(1+LPcnt) ) ) {
			//cerr << "av LPtim = " << (double)LPtim/(double)(1+LPcnt) << "; total=" << (double)(time(NULL)-ini_time)/(double)(1+LPcnt) << endl;
			if (rootLPsol[pick] > 1-1e-12) {
				val[0] = 1;
				val[1] = 0;
				//ac = false;
			} else if (rootLPsol[pick] < 1e-12) {
				val[0] = 0;
				val[1] = 1;
				//ac = false;
			}
		} else {
			bool useLP=true;
			if (useLP && eas[pick]== EXIST && !DepotAvail && /*decisionLevel() < (int)log2((double)nVars())*/ /*!useDeep ||*/ (!only_one && !LPvariableFound && /*eas[pick] == EXIST &&*/ /*isFixed[pick] == extbool_Undef &&*/ (!feasibilityOnly || useLimitedLP==false)  && (type[pick] == CONTINUOUS || ((!feasPhase ||(block[pick] == maxBlock && nVars()-trail.size()>9)) && !revImplQexists && hasObjective /*t < max_sd / 4 &&*/ && t > -1 && ((!feasPhase && t < lp_decider_depth) || (t < max_sd / 4/*4*//*0*/)) )))) {

				//	else if (/*!useDeep ||*/ (!only_one && !LPvariableFound && /*eas[pick] == EXIST &&*/ /*isFixed[pick] == extbool_Undef &&*/ (!feasibilityOnly || useLimitedLP==false)  && (type[pick] == CONTINUOUS || ((!feasPhase ||(block[pick] == maxBlock && nVars()-trail.size()>9)) && !revImplQexists && hasObjective /*t < max_sd / 4 &&*/ && t > -1 && ((!feasPhase && t < lp_decider_depth) || (t < max_sd / 4/*4*//*0*/)) )))) {
				//cerr << "W";
				bool general_valid = false;
				algorithm::Algorithm::SolutionStatus statush7;
				std::vector<data::QpNum> solutionh7;
				int cntCov=0;
				num_deps++;
		#ifdef USE_FULL_BENDERS
				bd_lhs.clear();

				int best_cont_ix=-1;
				int best_pol = -1;
				double best_activity = 0.0;
				bool free_uni_av = false;
				bool BoundsCut = false;
				int z1=0, z2=0;
				int totalcuts = 0;

				std::vector<int> saveUs;
				if (type[pick] == BINARY) {
					for (int jj = 0; jj < nVars();jj++) {
						if (assigns[jj] != extbool_Undef) {

						} else {
							if (eas[jj] == UNIV) {
								free_uni_av = true;
								if (killer[jj] != extbool_Undef)
									QlpStSolve.setVariableFixation(jj,killer[jj],type.getData());
								else QlpStSolve.setVariableFixation(jj,p_activity[jj]<n_activity[jj] ? 0 : 1,type.getData());
								if (!isDirty[jj]) {
									dirtyLPvars.push(jj);
									isDirty[jj] = true;
								}
								saveUs.push_back(jj);
							}
						}
					}
				}
				int nncuts=0;
				int pncuts=-1;
				int cnt_rat=0;
				double maxDev=0.0;

				// -------------------------------

				int T0 = time(NULL);
				bool Q = 0;
				bool tooManyLPlines = false;
				bool statusOK=false;
				int rounds=0;
				//int LPlines = QlpStSolve.getExternSolver(maxLPStage).getRowCount();
				//if (LPlines > orgLPlines * (int)log2(1.0+(double) nVars())) tooManyLPlines = true;
				if (1) {
					//cerr << "C";
					int cntLps=0;
					double oldLpv, newLpv=n_infinity;
					do {
						for (int hh = 0; hh < dirtyLPvars.size();hh++) {
							//isDirty[dirtyLPvars[hh]] = false;
							//}
							//for (int hh=0;hh<nVars();hh++) {
							//cerr << "set x" << dirtyLPvars[hh] << " to " << (int)assigns[dirtyLPvars[hh]] << endl;
							if (assigns[dirtyLPvars[hh]] != extbool_Undef && type[dirtyLPvars[hh]] != BINARY) continue;
							if (getFixed(dirtyLPvars[hh]) == extbool_Undef && assigns[dirtyLPvars[hh]] == extbool_Undef) {
								if (type[dirtyLPvars[hh]] == BINARY && eas[dirtyLPvars[hh]] == EXIST) {
									QlpStSolve.setVariableLB(dirtyLPvars[hh],0,type.getData());
									QlpStSolve.setVariableUB(dirtyLPvars[hh],1,type.getData());
								}
							} else if (assigns[dirtyLPvars[hh]] != extbool_Undef) {
								if (USE_ASSIGNVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)assigns[dirtyLPvars[hh]],type.getData());
							} else {
								if (USE_EARLYVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)getFixed(dirtyLPvars[hh]),type.getData());
							}
							//if ((converted_block[pick] >> CONV_BLOCK_RIGHT_SHIFT) != maxLPStage) cerr << "CB=" << (converted_block[pick] >> CONV_BLOCK_RIGHT_SHIFT) << " mLPS=" <<  maxLPStage << endl;
							//assert((converted_block[pick] >> CONV_BLOCK_RIGHT_SHIFT) == maxLPStage);
							updateStageSolver(converted_block[pick] >> CONV_BLOCK_RIGHT_SHIFT,dirtyLPvars[hh],dirtyLPvars[hh]);
							isDirty[dirtyLPvars[hh]] = false;
						}
						while (dirtyLPvars.size() > 0) dirtyLPvars.pop();

						BoundsCut = false;
						//cerr << "c";
						unsigned int lpt=time(NULL);
						QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE,-1,/*-1*/feasPhase?-1:-1/*computeLpIts()*/);
						LPtim += time(NULL)-lpt;
						LPcnt++;
						//cerr << "lb=" << lb.asDouble() << ", stat="<< status<<endl;
						statusOK=true;
						adjustLpIts(QlpStSolve.nbdAlgs[maxLPStage]->getIterations());
						//if (feasPhase) break;
						listOfCutsLhs1.clear();
						listOfCutsRhs1.clear();
						listOfCutsLhs2.clear();
						listOfCutsRhs2.clear();
						listOfCutsLhs3.clear();
						listOfCutsRhs3.clear();
						listOfCutsVars.clear();
						if (status == algorithm::Algorithm::INFEASIBLE) {
							//cerr << "cki";
							break;
						}
						if (status == algorithm::Algorithm::IT_LIMIT /*extSol::QpExternSolver::ABORT_IT_LIM && status != extSol::QpExternSolver::ABORT_TIME_LIM*/) {
							//if (status != extSol::QpExternSolver::OPTIMAL && status != extSol::QpExternSolver::INFEASIBLE) {
							cerr << "Warning: cutting planes controlled trouble" << endl;
							break;
						}
						numbLPs++;
						if ( a >= -lb.asDouble() ) break;
						if (LimHorSrch && lsd < 0 && !useRestarts && status == algorithm::Algorithm::FEASIBLE) {
							if (isOnTrack()) cerr << "lost solution xy25" << endl;
							RESOLVE_FIXED(decisionLevel());
							for (int zz=0;zz < saveUs.size();zz++) {
								QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
								QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
								if (!isDirty[saveUs[zz]]) {
									dirtyLPvars.push(saveUs[zz]);
									isDirty[saveUs[zz]] = true;
								}
							}
							saveUs.clear();
							return _StepResult(STACK,-lb.asDouble(), -lb.asDouble());
						}

						assert(Lpick >= 0);
						double newlb;
						if (solution.size()>0 && checkRounding(constraintallocator[constraints[0]].header.rhs, Lpick, solution, lb.asDouble(), newlb)) {
							if (fabs(lb.asDouble()-newlb) < 0.0001) {
								cerr << "Error: STOP";
								char c;cin >> c;
								lb = newlb;
								for (int z=0;z<solution.size();z++) {
									if(type[z] == BINARY) {
										if (solution[z].asDouble() > 0.5) solution[z] = 1.0;
										else solution[z] = 0.0;
									}
								}
							}
						}
						bool be=false;
						cnt_rat = 0;
						maxDev=0.5;
						for (int mm=0;mm<solution.size();mm++)
							if (type[mm] == BINARY && solution[mm].asDouble() > LP_EPS && solution[mm].asDouble() < 1.0-LP_EPS) {
								be = true;
								cnt_rat++;
								if (feasPhase) {
									varBumpActivity(mm, 10, 0);
									varBumpActivity(mm, 10, 1);
								}
							}

						if (!be && solution.size() > 0) {
							double result = 0.0;
							Constraint &c = constraintallocator[constraints[0]];
							if (-lb.asDouble() > c.header.rhs && -lb.asDouble() > a) {
								for (int i = 0; i < c.size();i++) {
									if (type[var(c[i])]==CONTINUOUS && assigns[var(c[i])] == extbool_Undef && !isFixed(var(c[i]))) {
										if (!sign(c[i])) result = result + c[i].coef * solution[var(c[i])].asDouble();
										else result = result - c[i].coef * solution[var(c[i])].asDouble();
										continue;
									}
									if (type[var(c[i])]==CONTINUOUS && assigns[var(c[i])] != extbool_Undef) continue;
									if (assigns[var(c[i])] != extbool_Undef || isFixed(var(c[i]))) {
										if (assigns[var(c[i])] != extbool_Undef) {
											if (sign(c[i])) result = result - c[i].coef * assigns[var(c[i])];
											else result = result + c[i].coef * assigns[var(c[i])];
										} else {
											if (sign(c[i])) result = result - c[i].coef * getFixed(var(c[i]));
											else result = result + c[i].coef * getFixed(var(c[i]));
										}
									} else {
										if (solution[var(c[i])].asDouble() < 0.0) {
											if (info_level >= 2) cerr << "Error: 0 > x_c_i:" << solution[var(c[i])].asDouble() << endl;
											solution[var(c[i])] = 0.0;
										}
										//assert(solution[var(c[i])] >= 0.0);
										if (solution[var(c[i])] > 0.5) {
											if (sign(c[i])) result = result - c[i].coef * 1.0;
											else result = result + c[i].coef * 1.0;
										}
									}
								}
								result = result - objOffset;
							} else {
								result = -lb.asDouble();
							}
							lb = -result;
							//if (abs(result+lb.asDouble()) > 1.0) cerr << "!+" << result << "," << -lb.asDouble() << "!!" << endl;
							if (local_ub > result) local_ub = result;
							if (decisionLevel() <= 2 && info_level >= 2) cerr << "ganzzahlig in level" << decisionLevel() << endl;
							break;
						}
						if (Q) cerr << "T1:" << time(NULL)-T0 << ":" << decisionLevel() << ":" << trail.size();
						oldLpv = newLpv;
						newLpv = -lb.asDouble();
						//if (cntLps > 0 && oldLpv <= newLpv) break;
						cntLps++;

						/*if (t > 55 && !useRestarts && status == algorithm::Algorithm::FEASIBLE) {
								RESOLVE_FIXED(decisionLevel());
								for (int zz=0;zz < saveUs.size();zz++) {
									QlpStSolve.setVariableLB(saveUs[zz],0);
									QlpStSolve.setVariableUB(saveUs[zz],1);
									if (!isDirty[saveUs[zz]]) {
										dirtyLPvars.push(saveUs[zz]);
										isDirty[saveUs[zz]] = true;
									}
								}
								saveUs.clear();
								return _StepResult(STACK,-lb.asDouble(), -lb.asDouble());
							}*/

						/*
						 *
						 *      for (int i = 0; i < 1;i++) {
									   QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE,-1,1000*(1<<i));
									   if (status == algorithm::Algorithm::FEASIBLE || status == algorithm::Algorithm::INFEASIBLE) break;
									   cerr << "Warning: LP is slow" << endl;
									}
									if (status != algorithm::Algorithm::FEASIBLE && status != algorithm::Algorithm::INFEASIBLE) {
										cerr << "Warning: LP takes too much time" << endl;
										for (int zz=0;zz < saveUs.size();zz++) {
											QlpStSolve.setVariableLB(saveUs[zz],0);
											QlpStSolve.setVariableUB(saveUs[zz],1);
											if (!isDirty[saveUs[zz]]) {
												dirtyLPvars.push(saveUs[zz]);
												isDirty[saveUs[zz]] = true;
											}
										}
										saveUs.clear();
										if (eas[pick] == EXIST) score = n_infinity;
										else                    score = p_infinity;
										best_val = dont_know;
										stack_pick[decisionLevel()] = pick;
										goto Lrestart;
									}

						 */
						//if (decisionLevel()==1) cerr << "COV0" << endl;
						if (feasPhase) break;
						//if (decisionLevel()==1) cerr << "COV0a" << endl;
						if ((time(NULL)-ini_time) / 10 < time(NULL)-T0 && decisionLevel() > (int)log2(1+log2((double)nVars()))) break;
						//if (decisionLevel()==1) cerr << "COV0b" << endl;
						//if (cntLps > 1 && (double)time(NULL)-(double)/*lpt*/T0 > 0.05*(double)(time(NULL)-ini_time) ) break;
						z1++;

						if (Q) cerr << "T2:" << time(NULL)-T0;


						// ---------------- next: add cuts
						static int64_t cntS=0;
						static int64_t cntC=0;
						//#define COVERCUTS
						//#ifdef COVERCUTS
						static int scaler2 = 1;
						//if (useCover && decisionLevel() <= 1 /*maxBaCLevel*/ && block[pick]==maxBlock && !useRestarts && status == algorithm::Algorithm::FEASIBLE && ( (irand(random_seed,scaler2) == 0 && /*decisionLevel() > 10 &&*/ num_props < 200*num_decs && a > n_infinity && a > -lb.asDouble() - 0.01*abs(-lb.asDouble()) && father_ix == 1)
						//    || (decisionLevel() < 4 && num_props < 2*num_decs/*|| father_ix == 1*/) || (father_ix == 1 && sfather_ix > 6) /*|| decisionLevel() < 10*/ || (eas[pick]==EXIST && thereIsAUnivInLastLevels(decisionLevel(), 10) )/*(int)sqrt((double)nVars())*/) ) {
						//if (useCover && !useRestarts && num_props < 200*num_decs && ((status == algorithm::Algorithm::FEASIBLE && decisionLevel() <= max(10,2*(int)sqrt((double)nVars()))) || (father_ix == 1 && sfather_ix > 6 /*&& a > -lb.asDouble() - 0.1*abs(-lb.asDouble())*/))) {
						//if (useCover && !useRestarts) {
						//if (decisionLevel()==1) cerr << "COV1" << endl;
						if ((decisionLevel() <= (int)log2((double)nVars()) || isPow2(decisionLevel() || trail_lim[trail_lim.size()-1] - trail_lim[trail_lim.size()-2] > 10/*|| trail.size()>5*decisionLevel()*/) /* % 10 ==0*/) && !tooManyLPlines && useCover && /*!feasPhase &&*/ decisionLevel() < (int)/*log*//*log2((double)nVars())**/sqrt((double)nVars()) && decisionLevel() < maxBaCLevel && /*block[pick]==1 &&*/ !useRestarts && status == algorithm::Algorithm::FEASIBLE && ( (irand(random_seed,scaler2) == 0 && /*decisionLevel() > 10 &&*/ num_props < 200*num_decs && a > n_infinity && 0&&a > -lb.asDouble() - 0.01*abs(-lb.asDouble()) && father_ix == 1)
	      				        || (decisionLevel() < 2*(int)/*log*/(/*log2((double)nVars())**/sqrt((double)nVars()) * (1||(num_props < 200*num_decs) ? 1.0 : /*sqrt*/((double)200*num_decs / (double)num_props))) /*&& num_props < 200*num_decs*//*|| father_ix == 1*/) || (0&&father_ix == 1 && sfather_ix > 6 && irand(random_seed,scaler2) == 0) /*|| decisionLevel() == 1*/)  ) {

						  //						if ((decisionLevel() <= (int)log2((double)nVars()) || isPow2(decisionLevel() /*|| trail.size()>5*decisionLevel()*/) /* % 10 ==0*/) && !tooManyLPlines && useCover && /*!feasPhase &&*/ decisionLevel() < (int)/*log*//*log2((double)nVars())**/sqrt((double)nVars()) && decisionLevel() < maxBaCLevel && /*block[pick]==maxBlock &&*/ !useRestarts && status == algorithm::Algorithm::FEASIBLE && ( (irand(random_seed,scaler2) == 0 && /*decisionLevel() > 10 &&*/ num_props < 200*num_decs && a > n_infinity && 0&&a > -lb.asDouble() - 0.01*abs(-lb.asDouble()) && father_ix == 1)
						  //																																												       || (decisionLevel() < 2*(int)/*log*/(/*log2((double)nVars())**/sqrt((double)nVars()) * (num_props < 200*num_decs ? 1.0 : /*sqrt*/((double)200*num_decs / (double)num_props))) /*&& num_props < 200*num_decs*//*|| father_ix == 1*/) || (0&&father_ix == 1 && sfather_ix > 6 && irand(random_seed,scaler2) == 0) /*|| decisionLevel() == 1*/)  ) {
							//if (!tooManyLPlines && useCover && /*!feasPhase &&*/ decisionLevel() < (int)/*log*//*log2((double)nVars())**/sqrt((double)nVars()) && decisionLevel() < maxBaCLevel && /*block[pick]==maxBlock &&*/ !useRestarts && status == algorithm::Algorithm::FEASIBLE && ( (irand(random_seed,scaler2) == 0 && /*decisionLevel() > 10 &&*/ num_props < 200*num_decs && a > n_infinity && 0&&a > -lb.asDouble() - 0.01*abs(-lb.asDouble()) && father_ix == 1)
							//|| (decisionLevel() < 2*(int)/*log*/(/*log2((double)nVars())**/sqrt((double)nVars()) * (num_props < 200*num_decs ? 1.0 : /*sqrt*/((double)200*num_decs / (double)num_props))) /*&& num_props < 200*num_decs*//*|| father_ix == 1*/) || (0&&father_ix == 1 && sfather_ix > 6 && irand(random_seed,scaler2) == 0) /*|| decisionLevel() == 1*/)  ) {
							//cerr << "A";
							//int nncuts=0;
							//int pncuts=-1;
							//for (int nctCov=0; cntCov < max(1000,1 + /*5*/(int)sqrt((double)nVars())-decisionLevel());cntCov++) {
							//if (decisionLevel()==1) cerr << "COV2" << endl;
							if (cntCov < max(1,1 + /*5*/(int)sqrt((double)nVars())-decisionLevel()) ) {
								//if (decisionLevel()==1) cerr << "COV3" << endl;

								if ((time(NULL) - ini_time)/10 < time(NULL) - T0 && decisionLevel() > (int)log2(1+log2((double)nVars()))) break;
								//cerr << "a";
								//if (decisionLevel()==1) cerr << "COV4" << endl;

								//cerr << uu << ": Bound:" << local_ub << " #frac = " << cnt_broken;
								std::vector<unsigned int> candis;
								statusOK=false;
								int ncuts=((yInterface*)yIF)->GenerateCutAndBranchCuts(QlpStSolve.getExternSolver( maxLPStage ), listOfCutsLhs2, listOfCutsRhs2, listOfCutsVars, decisionLevel(), block[pick] , general_valid, candis, ((yInterface*)yIF)->Cover, type.getData(), assigns.getData(), ini_time, optSol.getData(), VIsFixed.getData(), block.getData());
								//int ncuts=((yInterface*)yIF)->GenerateCutAndBranchCuts(QlpStSolve.getExternSolver( maxLPStage ), listOfCutsLhs2, listOfCutsRhs2, decisionLevel(), block[pick] , general_valid, candis, ((yInterface*)yIF)->Cover, type.getData(), assigns.getData(), ini_time);
								//cerr << ncuts << "w";
								for (int ll = 0; ll < ncuts;ll++) {

									//listOfEnteredCuts.push( QlpStSolve.addUserCut(maxLPStage, listOfCutsLhs[ll],
									//								data::QpRhs::greaterThanOrEqual, listOfCutsRhs[ll]) );
									////cnt_goms[ll]++;
									////listOfGoms.push(ll);
									nncuts++;
									//if (decisionLevel() >= 4 && nncuts > 50) break;
									//if (decisionLevel() < 4 && nncuts > 500) break;
									if (0&&decisionLevel() >= 1 && nncuts > num_orgs / 10) {
										//cerr << "nnc=" << nncuts << " no=" << num_orgs << endl;
										break;
									}
								}

								//if (decisionLevel() >= 4 && nncuts > 50) break;
								//if (decisionLevel() < 4 && nncuts > 500) break;
								if (0&&decisionLevel() >= 1 && nncuts > num_orgs / 10) {
									//cerr << "2: nnc=" << nncuts << " no=" << num_orgs << endl;
									break;
								}

								//if (pncuts == -1 || pncuts > ncuts) cntCov--;
								//if (decisionLevel()<=1) cerr << "COV5-" << decisionLevel() << LimHorSrch << endl;

								if (decisionLevel() <= 1 && LimHorSrch == false && info_level >= 2) cerr << "   ---  #cover candidates = " << ncuts << "(" << pncuts << ")" << "in level " << decisionLevel() << endl;
								if (pncuts >= ncuts /*&& ncuts < 5 && cntCov > 50*/) break;
                                                                //if (pncuts > ncuts && ncuts < 5 && cntCov > 50) break;
								pncuts = ncuts;
								//if (ncuts==0) break;
								//lbh7 = b;
								scaler2++;
								if (scaler2 > 100) scaler2 = 100;
								if (/*ncuts > 0*/listOfCutsRhs2.size() > 0) { // es wurden cuts hinzugefuegt
									scaler2 = 1;
								}
								cntCov++;
							}
						}
						/////
						HTCutentry *HTCe;
						pair<coef_t, uint64_t> hash;
						ca_vec<pair<double, uint32_t> > cutsorter;
						pairSortLt psl;
						for (uint32_t ll = 0; ll < listOfCutsRhs1.size();ll++) {
							if (listOfCutsLhs1[ll].size() < 1) {
								assert(listOfCutsRhs1[ll] == 0.0);
								if (info_level >= 2) cerr << "L=" << listOfCutsLhs1[ll].size() << " ";
								continue;
							}
							cutsorter.push(pair<double,uint32_t>((double)-computeEfficacy(listOfCutsLhs1[ll], listOfCutsRhs1[ll], solution),ll) );
						}
						sort(cutsorter,psl);
						double sum_eff=0.0;
						for (int ll=0;ll<cutsorter.size();ll++) {
							//cerr << "Ef:[" << cutsorter[i].second << "]=" <<  cutsorter[i].first << endl;
							hash = HTC->computeHash(listOfCutsLhs1[ll], listOfCutsRhs1[ll].asDouble());
							if (!HTC->getEntry(&HTCe,hash.second, hash.first)) {
								listOfEnteredCuts.push( QlpStSolve.addUserCut(maxLPStage, listOfCutsLhs1[cutsorter[ll].second],
										data::QpRhs::greaterThanOrEqual, listOfCutsRhs1[cutsorter[ll].second]) );
								listOfEnteredCutHashs.push(hash);
								HTC->setEntry(hash.first, hash.second);
								totalcuts++;
								BoundsCut = true;
							}
							if (decisionLevel() >= 4 && totalcuts > 10) break;
							if (decisionLevel() < 4 &&  totalcuts > 100) break;
							sum_eff += (-cutsorter[ll].first);
							if (-cutsorter[ll].first < 0.33333*(sum_eff / ((double)(ll+1)))) break;
						}
						/*for (int ll = 0; ll < listOfCutsRhs1.size();ll++) {
								hash = HTC->computeHash(listOfCutsLhs1[ll], listOfCutsRhs1[ll].asDouble());
								if (!HTC->getEntry(&HTCe,hash.second, hash.first)) {
									BoundsCut = true;
									totalcuts++;
									listOfEnteredCuts.push( QlpStSolve.addUserCut(maxLPStage, listOfCutsLhs1[ll],
											data::QpRhs::greaterThanOrEqual, listOfCutsRhs1[ll]) );
									listOfEnteredCutHashs.push(hash);
									HTC->setEntry(hash.first, hash.second);
								}
								if (decisionLevel() >= 4 && totalcuts > 100) break;
								if (decisionLevel() < 4 &&  totalcuts > 1000) break;
							}*/

						//ca_vec<pair<double, uint32_t> > cutsorter;
						//pairSortLt psl;
						cutsorter.clear();
						for (uint32_t ll = 0; ll < listOfCutsRhs2.size();ll++) {
							if (listOfCutsLhs2[ll].size() < 1) {
								assert(listOfCutsRhs2[ll] == 0.0);
								if (info_level >= 2) cerr << "L=" << listOfCutsLhs2[ll].size() << " ";
								continue;
							}
							cutsorter.push(pair<double,uint32_t>((double)-computeEfficacy(listOfCutsLhs2[ll], listOfCutsRhs2[ll], solution),ll) );
						}
						sort(cutsorter,psl);
						sum_eff=0.0;
						//double sum_eff=0.0;
						for (int ll=0;ll<cutsorter.size();ll++) {
							//cerr << "Ef:[" << cutsorter[i].second << "]=" <<  cutsorter[i].first << endl;
							hash = HTC->computeHash(listOfCutsLhs2[ll], listOfCutsRhs2[ll].asDouble());
							if (!HTC->getEntry(&HTCe,hash.second, hash.first)) {
							  if (0)for (int kk = 0; kk < listOfCutsLhs2[cutsorter[ll].second].size();kk++) {
									cerr << listOfCutsLhs2[cutsorter[ll].second][kk].value.asDouble() << "x" << listOfCutsLhs2[cutsorter[ll].second][kk].index << " + ";
								}
									//cerr << "0 >= " << listOfCutsRhs2[cutsorter[ll].second].asDouble() << endl;
								listOfEnteredCuts.push( QlpStSolve.addUserCut(maxLPStage, listOfCutsLhs2[cutsorter[ll].second],
										data::QpRhs::greaterThanOrEqual, listOfCutsRhs2[cutsorter[ll].second]) );
								listOfEnteredCutHashs.push(hash);
								HTC->setEntry(hash.first, hash.second);
								totalcuts++;
								BoundsCut = true;
							}
							if (decisionLevel() >= 4 && totalcuts > 10) break;
							if (decisionLevel() < 4 &&  totalcuts > 100) break;
							sum_eff += (-cutsorter[ll].first);
							if (-cutsorter[ll].first < 0.13333*(sum_eff / ((double)(ll+1)))) break;
						}
						if (Q) cerr << "T3:" << BoundsCut << "." << time(NULL)-T0;
						rounds++;
					} while (BoundsCut && decisionLevel() < 3 && rounds < 5);
					//HT->anchorLP(status == algorithm::Algorithm::FEASIBLE ? lb.asDouble() : -n_infinity, trail.size(), decisionLevel());
					//cerr << "Hashvalue=" << HT->hash << endl;
				}

				if (Q) cerr << "T4:" << time(NULL)-T0;

				//#else
				if (QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus() == extSol::QpExternSolver::UNSOLVED) {
					unsigned int lpt=time(NULL);
					QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE,-1,/*-1*/feasPhase?-1:/*3*/3-4 /*simplex iterationen*/);
					if (status == algorithm::Algorithm::IT_LIMIT /*extSol::QpExternSolver::ABORT_IT_LIM && status != extSol::QpExternSolver::ABORT_TIME_LIM*/) {
						//if (status != extSol::QpExternSolver::OPTIMAL && status != extSol::QpExternSolver::INFEASIBLE) {
						cerr << "Warning: after Cover controlled trouble" << endl;
					}
					LPtim += time(NULL)-lpt;
					LPcnt++;
					statusOK=true;
				}

				static int scaler = 1;
		#ifdef OLD_GMI
				//coef_t ggap;
				//ggap = abs(100.0*(-global_dual_bound + global_score) / (abs(global_score)+1e-10) );
				if (/*ggap < 0.5 &&*/ num_props < 900*num_decs && decisionLevel() <= 1 && !tooManyLPlines && /*!feasPhase &&*/ /*(double)LPtim/(double)LPcnt < 0.02*(double)(time(NULL)-ini_time) &&*/ decisionLevel()<=1/*log2((double)nVars())*//*&&num_props < 200*num_decs*/&&/*listOfCutsLhs2.size()==0&&*/useGMI && /*!feasPhase &&*/ decisionLevel() < (int)/*log*/log2((double)nVars())*sqrt((double)nVars()) && decisionLevel() < maxBaCLevel && /*block[pick]==maxBlock &&*/ !useRestarts && status == algorithm::Algorithm::FEASIBLE && ( (irand(random_seed,scaler) == 0 && /*decisionLevel() > 10 &&*/ num_props < 200*num_decs && a > n_infinity && 0&&a > -lb.asDouble() - 0.01*abs(-lb.asDouble()) && father_ix == 1)
						|| (decisionLevel() < 2*(int)/*log*/(log2((double)nVars())*sqrt((double)nVars()) * (num_props < 200*num_decs ? 1.0 : /*sqrt*/((double)200*num_decs / (double)num_props))) /*&& num_props < 200*num_decs*//*|| father_ix == 1*/) || (0&&father_ix == 1 && sfather_ix > 6 && irand(random_seed,scaler) == 0) /*|| decisionLevel() == 1*/)  ) {
				//if ((processNo & 1) == 1 && decisionLevel() <= 1 && !feasPhase && useGMI &&  !useRestarts && status == algorithm::Algorithm::FEASIBLE
				//		) {
					//if (!tooManyLPlines && !feasPhase && /*(double)LPtim/(double)LPcnt < 0.02*(double)(time(NULL)-ini_time) &&*/ decisionLevel()<=1/*log2((double)nVars())*//*&&num_props < 200*num_decs*/&&/*listOfCutsLhs2.size()==0&&*/useGMI && /*!feasPhase &&*/ decisionLevel() < (int)/*log*/log2((double)nVars())*sqrt((double)nVars()) && decisionLevel() < maxBaCLevel && /*block[pick]==maxBlock &&*/ !useRestarts && status == algorithm::Algorithm::FEASIBLE && ( (irand(random_seed,scaler) == 0 && /*decisionLevel() > 10 &&*/ num_props < 200*num_decs && a > n_infinity && 0&&a > -lb.asDouble() - 0.01*abs(-lb.asDouble()) && father_ix == 1)
					//|| (decisionLevel() < 2*(int)/*log*/(log2((double)nVars())*sqrt((double)nVars()) * (num_props < 200*num_decs ? 1.0 : /*sqrt*/((double)200*num_decs / (double)num_props))) /*&& num_props < 200*num_decs*//*|| father_ix == 1*/) || (0&&father_ix == 1 && sfather_ix > 6 && irand(random_seed,scaler) == 0) /*|| decisionLevel() == 1*/)  ) {
					int nncuts=0;
					unsigned int gmistim=time(NULL);
					//cntC++;
					scaler++;
					if (scaler > 100) scaler = 100;
					//cerr << "B";
					std::vector<unsigned int> candis;
					//for (int kkk = 0; /*cntCov < max(1,1 + (int)sqrt((double)nVars())-decisionLevel())*/kkk<1 ; kkk++) {
					for (int kkk=0; kkk < (decisionLevel() <3 ? 2 : 1) && (double)LPtim/(double)LPcnt < 0.02*(double)(time(NULL)-ini_time); kkk++) {
						if ((double)(time(NULL) - ini_time)*0.02 < (double)(time(NULL)-gmistim)) break;
						if (QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus() == extSol::QpExternSolver::UNSOLVED) {
							unsigned int lpt=time(NULL);
							QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE, -1,-1 /*simplex iterationen*/);
							if (status == algorithm::Algorithm::IT_LIMIT /*extSol::QpExternSolver::ABORT_IT_LIM && status != extSol::QpExternSolver::ABORT_TIME_LIM*/) {
								//if (status != extSol::QpExternSolver::OPTIMAL && status != extSol::QpExternSolver::INFEASIBLE) {
								cerr << "GMI controlled trouble" << endl;
								break;
							}
							LPtim += time(NULL)-lpt;
							LPcnt++;
							if (info_level & 4) cerr << "nlb=" << -lb.asDouble() << endl;
							statusOK=true;
						}
						if (info_level & 4) cerr << "nlb2=" << -lb.asDouble() << endl;
						ca_vec<pair<double, uint32_t> > xsorter;
						ca_vec<pair<double, uint32_t> > cutsorter;
						pairSortLt psl;
						for (int jj = 0; jj < solution.size();jj++) {
							if (type[jj] == CONTINUOUS || block[pick] < block[jj] || eas[pick] == UNIV) continue;
							//if (isInObj[jj] > nVars()) continue;
							if (assigns[jj] == extbool_Undef) {
								if (solution[jj].asDouble() < 1.0-LP_EPS && solution[jj].asDouble() >= LP_EPS && cnt_goms[jj] < 7) {
									brokenCnt[jj]++;
									xsorter.push(pair<double,uint32_t>(abs((double)solution[jj].asDouble()/*-0.5*/),jj));
								}
							}
						}
						sort(xsorter,psl);
						double dif=LP_EPS;
						if (xsorter.size()>0) dif=(xsorter[0].first > 0.5 ? (1.0-xsorter[0].first)/10.0 : xsorter[0].first/10.0);

						//cerr << "b" << xsorter.size() << "|" << dif << "|";
						candis.clear();
						for (int iii=xsorter.size()-1, ooo=0; iii >= 0; iii--,ooo++) {
							if (solution[xsorter[iii].second].asDouble() < 1.0-dif && solution[xsorter[iii].second].asDouble() >= dif && cnt_goms[xsorter[iii].second] < 7)
								candis.push_back(xsorter[iii].second);
							//if (ooo>50) break;
							//cerr << " " << xsorter[iii].first;
						}
						//cerr << "c" << candis.size();
						if (candis.size() == 0) break;
						if (candis.size()>0) {
							HTCutentry *HTCe;
							pair<coef_t, uint64_t> hash;
							double sum_eff = 0.0;
							bool cutsuc=false;
							//std::vector<unsigned int> candis;
							statusOK=false;
							listOfCutsLhs3.clear();
							listOfCutsRhs3.clear();
							listOfCutsVars.clear();
							int lncuts;
							if (kkk==0) lncuts=((yInterface*)yIF)->GenerateCutAndBranchCuts(QlpStSolve.getExternSolver( maxLPStage ), listOfCutsLhs3, listOfCutsRhs3, listOfCutsVars, t, block[pick] , general_valid, candis, ((yInterface*)yIF)->LuP, type.getData(), assigns.getData(), ini_time,optSol.getData(), VIsFixed.getData(), block.getData());
							else lncuts=((yInterface*)yIF)->GenerateCutAndBranchCuts(QlpStSolve.getExternSolver( maxLPStage ), listOfCutsLhs3, listOfCutsRhs3, listOfCutsVars, t, block[pick] , general_valid, candis, ((yInterface*)yIF)->GMI, type.getData(), assigns.getData(), ini_time,optSol.getData(), VIsFixed.getData(), block.getData());
							//int lncuts=((yInterface*)yIF)->GenerateCutAndBranchCuts(QlpStSolve.getExternSolver( maxLPStage ), listOfCutsLhs3, listOfCutsRhs3, t, block[pick] , general_valid, candis, ((yInterface*)yIF)->GMI, type.getData(), assigns.getData(), ini_time);
							//cerr << "N" << ncuts;
							//for (int ll = 0; ll < ncuts;ll++) {
							//	nncuts++;
							//}
							assert(listOfCutsRhs3.size() == lncuts);
							ca_vec<pair<double, uint32_t> > cutsorter;
							pairSortLt psl;
							for (uint32_t ll = 0; ll < listOfCutsRhs3.size();ll++) {
								if (listOfCutsLhs3[ll].size() < 1) {
									assert(listOfCutsRhs3[ll] == 0.0);
									cerr << "L=" << listOfCutsLhs3[ll].size() << " ";
									continue;
								}
								cutsorter.push(pair<double,uint32_t>((double)-computeEfficacy(listOfCutsLhs3[ll], listOfCutsRhs3[ll], solution),ll) );
							}
							sort(cutsorter,psl);
							int ncuts = 0;
							for (int ll = 0; ll < lncuts;ll++) {
								if (0&&listOfCutsLhs3[cutsorter[ll].second].size() < 1) {
									assert(listOfCutsRhs3[cutsorter[ll].second] == 0.0);
									cerr << "L=" << listOfCutsLhs3[cutsorter[ll].second].size() << " ";
									continue;
								} //else cerr << "CUT IN" << endl;
								if (0&&DLD_sum > 0 && computeDLD(listOfCutsLhs3[cutsorter[ll].second]) > DLD_sum / DLD_num + DLD_sum / (1*DLD_num))
									continue;
								if (computeEfficacy(listOfCutsLhs3[cutsorter[ll].second], listOfCutsRhs3[cutsorter[ll].second], solution) < 0.007)
									continue;
								listOfCutsRhs3[cutsorter[ll].second] -= LP_EPS;//0.01;
								hash = HTC->computeHash(listOfCutsLhs3[cutsorter[ll].second], listOfCutsRhs3[cutsorter[ll].second].asDouble());
								if (!HTC->getEntry(&HTCe,hash.second, hash.first)) {
									listOfEnteredCuts.push( QlpStSolve.addUserCut(maxLPStage, listOfCutsLhs3[cutsorter[ll].second],
											data::QpRhs::greaterThanOrEqual, listOfCutsRhs3[cutsorter[ll].second]) );
									listOfEnteredCutHashs.push(hash);
									cerr << ll << " ";
									cerr << " cs=" << cutsorter[ll].second;
								cerr << " lncuts=" << lncuts;
								cerr << " varssize=" << listOfCutsVars.size();
								cerr << " var=" << listOfCutsVars[cutsorter[ll].second] << endl;
									cnt_goms[listOfCutsVars[cutsorter[ll].second]]++;
									listOfGoms.push(cutsorter[ll].second);
									listOfEnteredCutHashs.push(hash);
									HTC->setEntry(hash.first, hash.second);
									nncuts++;
									ncuts++;
									cutsuc=true;
								}
								if (decisionLevel() >= 4 && nncuts > 5/*0*/) break;
								if (decisionLevel() < 4 && nncuts > /*500*/25) break;
								//if (ll > 10) break;
								sum_eff += (-cutsorter[ll].first);
								cerr << "ef=" << -cutsorter[ll].first << " "<< 0.63333*(sum_eff / ((double)(ll+1))) << endl;
								if (-cutsorter[ll].first < 0.33333*(sum_eff / ((double)(ll+1)))) break;
								if (-cutsorter[ll].first*3 < -cutsorter[0].first) break;
								//if (-cutsorter[ll].first < /*0.99333*/(QlpStSolve.getExternSolver(maxLPStage).getRowCount() / (double)nVars())*(sum_eff / ((double)(ll+1)))) break;

							}


							if (decisionLevel() <= 1) cerr << "   ---  #gmi candidates = " << ncuts << "(" << pncuts << ")" << "in level " << decisionLevel() << endl;
							if (pncuts >= ncuts /*&& ncuts < 5 && cntCov > 50*/) break;
                                                        //if (pncuts > ncuts && ncuts < 5 && cntCov > 50) break;
							pncuts = ncuts;
							scaler++;
							if (scaler > 100) scaler = 100;
							if (/*ncuts > 0*/listOfCutsRhs3.size() > 0) { // es wurden cuts hinzugefuegt
								scaler = 1;
							}
							cntCov++;
							if (!cutsuc) break;
						}
					}
				}

		#else
				//coef_t ggap;
				//if (decisionLevel() <= 1) cerr << "totalcuts=" << totalcuts << endl;
				//if (decisionLevel() <= 1) cerr << "tooManyLPlines=" << tooManyLPlines << endl;
				//ggap = abs(100.0*(-global_dual_bound + global_score) / (abs(global_score)+1e-10) );
				if (/*ggap < 0.5 &&*/ num_props < 900*num_decs && decisionLevel() <= 1 && !tooManyLPlines && /*!feasPhase &&*/ /*(double)LPtim/(double)LPcnt < 0.02*(double)(time(NULL)-ini_time) &&*/ decisionLevel()<=1/*log2((double)nVars())*//*&&num_props < 200*num_decs*/&&/*listOfCutsLhs2.size()==0&&*/useGMI && /*!feasPhase &&*/ decisionLevel() < (int)/*log*/log2((double)nVars())*sqrt((double)nVars()) && decisionLevel() < maxBaCLevel && /*block[pick]==maxBlock &&*/ !useRestarts && status == algorithm::Algorithm::FEASIBLE && ( (irand(random_seed,scaler) == 0 && /*decisionLevel() > 10 &&*/ num_props < 200*num_decs && a > n_infinity && 0&&a > -lb.asDouble() - 0.01*abs(-lb.asDouble()) && father_ix == 1)
						|| (decisionLevel() < 2*(int)/*log*/(log2((double)nVars())*sqrt((double)nVars()) * (num_props < 200*num_decs ? 1.0 : /*sqrt*/((double)200*num_decs / (double)num_props))) /*&& num_props < 200*num_decs*//*|| father_ix == 1*/) || (0&&father_ix == 1 && sfather_ix > 6 && irand(random_seed,scaler) == 0) /*|| decisionLevel() == 1*/)  ) {
				//if ((processNo & 1) == 1 && decisionLevel() <= 1 && !feasPhase && useGMI &&  !useRestarts && status == algorithm::Algorithm::FEASIBLE
				//		) {
					//if (!tooManyLPlines && !feasPhase && /*(double)LPtim/(double)LPcnt < 0.02*(double)(time(NULL)-ini_time) &&*/ decisionLevel()<=1/*log2((double)nVars())*//*&&num_props < 200*num_decs*/&&/*listOfCutsLhs2.size()==0&&*/useGMI && /*!feasPhase &&*/ decisionLevel() < (int)/*log*/log2((double)nVars())*sqrt((double)nVars()) && decisionLevel() < maxBaCLevel && /*block[pick]==maxBlock &&*/ !useRestarts && status == algorithm::Algorithm::FEASIBLE && ( (irand(random_seed,scaler) == 0 && /*decisionLevel() > 10 &&*/ num_props < 200*num_decs && a > n_infinity && 0&&a > -lb.asDouble() - 0.01*abs(-lb.asDouble()) && father_ix == 1)
					//|| (decisionLevel() < 2*(int)/*log*/(log2((double)nVars())*sqrt((double)nVars()) * (num_props < 200*num_decs ? 1.0 : /*sqrt*/((double)200*num_decs / (double)num_props))) /*&& num_props < 200*num_decs*//*|| father_ix == 1*/) || (0&&father_ix == 1 && sfather_ix > 6 && irand(random_seed,scaler) == 0) /*|| decisionLevel() == 1*/)  ) {
					int nncuts=0;
					unsigned int gmistim=time(NULL);
					//cntC++;
					scaler++;
					if (scaler > 100) scaler = 100;
					//cerr << "B";
					std::vector<unsigned int> candis;
					//for (int kkk = 0; /*cntCov < max(1,1 + (int)sqrt((double)nVars())-decisionLevel())*/kkk<1 ; kkk++) {
					for (int kkk=0; kkk < (decisionLevel() <3 ? 2 : 1) && (double)LPtim/(double)LPcnt < 0.02*(double)(time(NULL)-ini_time)+5; kkk++) {
						if ((double)(time(NULL) - ini_time)*0.02 + 5 < (double)(time(NULL)-gmistim)) break;
						if (QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus() == extSol::QpExternSolver::UNSOLVED) {
							unsigned int lpt=time(NULL);
							QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE, -1,-1 /*simplex iterationen*/);
							if (status == algorithm::Algorithm::IT_LIMIT /*extSol::QpExternSolver::ABORT_IT_LIM && status != extSol::QpExternSolver::ABORT_TIME_LIM*/) {
								//if (status != extSol::QpExternSolver::OPTIMAL && status != extSol::QpExternSolver::INFEASIBLE) {
								cerr << "Warning: GMI controlled trouble" << endl;
								break;
							}
							LPtim += time(NULL)-lpt;
							LPcnt++;
							if (info_level & 4) cerr << "nlb=" << -lb.asDouble() << endl;
							statusOK=true;
						}
						if (info_level & 4) cerr << "nlb2=" << -lb.asDouble() << endl;
						ca_vec<pair<double, uint32_t> > xsorter;
						ca_vec<pair<double, uint32_t> > cutsorter;
						pairSortLt psl;
						for (int jj = 0; jj < solution.size();jj++) {
							if (type[jj] == CONTINUOUS || block[pick] < block[jj] || eas[pick] == UNIV) continue;
							//if (isInObj[jj] > nVars()) continue;
							if (assigns[jj] == extbool_Undef) {
								if (solution[jj].asDouble() < 1.0-LP_EPS && solution[jj].asDouble() >= LP_EPS && cnt_goms[jj] < 7) {
									brokenCnt[jj]++;
									xsorter.push(pair<double,uint32_t>(abs((double)solution[jj].asDouble()/*-0.5*/),jj));
								}
							}
						}
						sort(xsorter,psl);
						double dif=LP_EPS;
						if (xsorter.size()>0) dif=(xsorter[0].first > 0.5 ? (1.0-xsorter[0].first)/10.0 : xsorter[0].first/10.0);

						//cerr << "b" << xsorter.size() << "|" << dif << "|";
						candis.clear();
						for (int iii=xsorter.size()-1, ooo=0; iii >= 0; iii--,ooo++) {
							if (solution[xsorter[iii].second].asDouble() < 1.0-dif && solution[xsorter[iii].second].asDouble() >= dif && cnt_goms[xsorter[iii].second] < 7)
								candis.push_back(xsorter[iii].second);
							//if (ooo>50) break;
							//cerr << " " << xsorter[iii].first;
						}
						//cerr << "c" << candis.size();
						if (candis.size() == 0) break;
						if (candis.size()>0) {
							HTCutentry *HTCe;
							pair<coef_t, uint64_t> hash;
							double sum_eff = 0.0;
							bool cutsuc=false;
							//std::vector<unsigned int> candis;
							statusOK=false;
							listOfCutsLhs3.clear();
							listOfCutsRhs3.clear();
							listOfCutsVars.clear();
							int lncuts;
							if (useLuP && kkk==0) {
								lncuts=((yInterface*)yIF)->GenerateCutAndBranchCuts(QlpStSolve.getExternSolver( maxLPStage ), listOfCutsLhs3, listOfCutsRhs3, listOfCutsVars, t, block[pick] , general_valid, candis, ((yInterface*)yIF)->LuP, type.getData(), assigns.getData(), ini_time,optSol.getData(), VIsFixed.getData(), block.getData());
								if (lncuts == 0) continue;
							} else lncuts=((yInterface*)yIF)->GenerateCutAndBranchCuts(QlpStSolve.getExternSolver( maxLPStage ), listOfCutsLhs3, listOfCutsRhs3, listOfCutsVars, t, block[pick] , general_valid, candis, ((yInterface*)yIF)->GMI, type.getData(), assigns.getData(), ini_time,optSol.getData(), VIsFixed.getData(), block.getData());
							//int lncuts=((yInterface*)yIF)->GenerateCutAndBranchCuts(QlpStSolve.getExternSolver( maxLPStage ), listOfCutsLhs3, listOfCutsRhs3, t, block[pick] , general_valid, candis, ((yInterface*)yIF)->GMI, type.getData(), assigns.getData(), ini_time);
							//cerr << "N" << ncuts;
							//for (int ll = 0; ll < ncuts;ll++) {
							//	nncuts++;
							//}
							assert(listOfCutsRhs3.size() == lncuts);
							ca_vec<pair<double, uint32_t> > cutsorter;
							pairSortLt psl;
							for (uint32_t ll = 0; ll < listOfCutsRhs3.size();ll++) {
								if (listOfCutsLhs3[ll].size() < 1) {
									assert(listOfCutsRhs3[ll] == 0.0);
									if (info_level >= 2) cerr << "L=" << listOfCutsLhs3[ll].size() << " ";
									continue;
								}
								cutsorter.push(pair<double,uint32_t>((double)-computeEfficacy(listOfCutsLhs3[ll], listOfCutsRhs3[ll], solution),ll) );
							}
							sort(cutsorter,psl);
							int ncuts = 0;
							for (int ll = 0; ll < lncuts;ll++) {
								if (totalcuts >= 3 && computeEfficacy(listOfCutsLhs3[cutsorter[ll].second], listOfCutsRhs3[cutsorter[ll].second], solution) < 0.007)
									continue;
								listOfCutsRhs3[cutsorter[ll].second] -= LP_EPS;//0.01;
								hash = HTC->computeHash(listOfCutsLhs3[cutsorter[ll].second], listOfCutsRhs3[cutsorter[ll].second].asDouble());
								if (!HTC->getEntry(&HTCe,hash.second, hash.first)) {
									listOfEnteredCuts.push( QlpStSolve.addUserCut(maxLPStage, listOfCutsLhs3[cutsorter[ll].second],
											data::QpRhs::greaterThanOrEqual, listOfCutsRhs3[cutsorter[ll].second]) );
									listOfEnteredCutHashs.push(hash);
									if (info_level >= 2) cerr << ll << " ";
									if (info_level >= 2) cerr << " cs=" << cutsorter[ll].second;
									if (info_level >= 2) cerr << " lncuts=" << lncuts;
									if (info_level >= 2) cerr << " varssize=" << listOfCutsVars.size();
									if (info_level >= 2) cerr << " var=" << listOfCutsVars[cutsorter[ll].second] << endl;
									cnt_goms[listOfCutsVars[cutsorter[ll].second]]++;
									listOfGoms.push(cutsorter[ll].second);
									listOfEnteredCutHashs.push(hash);
									HTC->setEntry(hash.first, hash.second);
									nncuts++;
									ncuts++;
									cutsuc=true;
								}
								if (decisionLevel() >= 4 && nncuts > 5/*0*/) break;
								if (decisionLevel() < 4 && nncuts > /*500*/25) break;
								//if (ll > 10) break;
								sum_eff += (-cutsorter[ll].first);
								if (info_level >= 2) cerr << "ef=" << -cutsorter[ll].first << " "<< 0.63333*(sum_eff / ((double)(ll+1))) << endl;
								if (-cutsorter[ll].first < 0.33333*(sum_eff / ((double)(ll+1)))) break;
								if (-cutsorter[ll].first*3 < -cutsorter[0].first) break;
								//if (-cutsorter[ll].first < /*0.99333*/(QlpStSolve.getExternSolver(maxLPStage).getRowCount() / (double)nVars())*(sum_eff / ((double)(ll+1)))) break;

							}


							if (decisionLevel() <= 1 && info_level >= 2) cerr << "   ---  #gmi candidates = " << ncuts << "(" << pncuts << ")" << "in level " << decisionLevel() << endl;
							if (pncuts >= ncuts /*&& ncuts < 5 && cntCov > 50*/) break;
                                                        //if (pncuts > ncuts && ncuts < 5 && cntCov > 50) break;
							pncuts = ncuts;
							scaler++;
							if (scaler > 100) scaler = 100;
							if (/*ncuts > 0*/listOfCutsRhs3.size() > 0) { // es wurden cuts hinzugefuegt
								scaler = 1;
							}
							cntCov++;
							if (!cutsuc) break;
						}
					}
				}
		#endif

#define USER_CUTS
#ifdef USER_CUTS
		if (QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus() == extSol::QpExternSolver::UNSOLVED) {
			unsigned int lpt=time(NULL);
			QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE, -1,-1 /*simplex iterationen*/);
			if (status == algorithm::Algorithm::IT_LIMIT /*extSol::QpExternSolver::ABORT_IT_LIM && status != extSol::QpExternSolver::ABORT_TIME_LIM*/) {
				cerr << "Warning: UserCut controlled trouble" << endl;
			}
			LPtim += time(NULL)-lpt;
			LPcnt++;
			statusOK=true;
		}
		HTCutentry *HTCe;
		pair<coef_t, uint64_t> hash;
		std::vector<unsigned int> candis;

		listOfCutsLhs3.clear();
		listOfCutsRhs3.clear();
		listOfCutsVars.clear();
		int lncuts=((yInterface*)yIF)->GenerateCutAndBranchCuts(QlpStSolve.getExternSolver( maxLPStage ), listOfCutsLhs3, listOfCutsRhs3, listOfCutsVars, t, block[pick] , general_valid, candis, ((yInterface*)yIF)->UserCut, type.getData(), assigns.getData(), ini_time,optSol.getData(), VIsFixed.getData(), block.getData());
		lncuts = listOfCutsRhs3.size();
		for (int ll = 0; ll < lncuts;ll++) {
			listOfCutsRhs3[ll] -= LP_EPS;
			hash = HTC->computeHash(listOfCutsLhs3[ll], listOfCutsRhs3[ll].asDouble());
			if (!HTC->getEntry(&HTCe,hash.second, hash.first)) {
				listOfEnteredCuts.push( QlpStSolve.addUserCut(maxLPStage, listOfCutsLhs3[ll],
						data::QpRhs::greaterThanOrEqual, listOfCutsRhs3[ll]) );
				listOfEnteredCutHashs.push(hash);
				HTC->setEntry(hash.first, hash.second);
			}
		}

		if (decisionLevel() <= 1 && info_level >= 2) cerr << "   ---  #user cuts = " << lncuts << "in level " << decisionLevel() << endl;
#endif //USER_CUTS

				if (Q) cerr << "T5:" << time(NULL)-T0;

				// -------------------------------

				if ((!feasPhase && statusOK == false) || QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus() == extSol::QpExternSolver::UNSOLVED) {
					unsigned int lpt=time(NULL);
					QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE,-1,/*-1*/feasPhase?-1:/*3*/3-4 /*simplex iterationen*/);
					LPtim += time(NULL)-lpt;
					LPcnt++;
					bool be=false;
					cnt_rat = 0;
					maxDev=0.5;
					for (int mm=0;mm<solution.size();mm++)
						if (type[mm] == BINARY && solution[mm].asDouble() > LP_EPS && solution[mm].asDouble() < 1.0-LP_EPS) {
							be = true;
							cnt_rat++;
							if (feasPhase) {
								varBumpActivity(mm, 10, 0);
								varBumpActivity(mm, 10, 1);
							}
							if (fabs(0.5-solution[mm].asDouble()) < maxDev) {
								//if (decisionLevel() == 1) cerr << solution[mm].asDouble() << ";";
								maxDev = fabs(0.5-solution[mm].asDouble());
							}
						}
				}


				if (decisionLevel() == 1) {
					if (status == algorithm::Algorithm::INFEASIBLE) {
						cerr << "Root-LP:" << "inf" << endl;
						if (!objInverted) cerr << "Global dual bound:" << -global_dual_bound << endl;
						else cerr << "Global dual bound:" << global_dual_bound << endl;
						cerr << "Fixed:" << trail.size() << endl;
						PurgeTrail(trail.size() - 1, decisionLevel() - 1);
						for (int zz = 0; zz < saveUs.size(); zz++) {
							QlpStSolve.setVariableLB(saveUs[zz], 0,type.getData());
							QlpStSolve.setVariableUB(saveUs[zz], 1,type.getData());
							if (!isDirty[saveUs[zz]]) {
								dirtyLPvars.push(saveUs[zz]);
								isDirty[saveUs[zz]] = true;
							}
						}
						saveUs.clear();
						RESOLVE_FIXED(decisionLevel());
						insertVarOrder(Lpick);
						return _StepResult(STACK,n_infinity, n_infinity);
					} else if (status == algorithm::Algorithm::FEASIBLE) {
						if (!objInverted) cerr << "Root-LP:" << lb.asDouble();
						else cerr << "Root-LP:" << -lb.asDouble();
						if (info_level >= 2) cerr << " non-integers: "<< cnt_rat << " max. Dev.:" << 0.5-maxDev << " propagation Ratio:" << (double)num_decs / ((double)num_props+1.0) << endl;
						if (-lb.asDouble() < global_dual_bound) global_dual_bound = -lb.asDouble();
						if (!objInverted)  cerr << " dual:" << -global_dual_bound;
						else cerr << " dual:" << global_dual_bound;
						cerr << " open:" << nVars()-trail.size() << " closed:" << trail.size();
						cerr << " relaxations:" << LPcnt << " / " << LPcntSB << " nodes:" << num_decs << endl;
						if (info_level >= 2) cerr << "Branching: avg=" << SBavg / SBcnt << " StdAbw=" << sqrt(SBsigEst) << ", max=" << SBmaxDi << endl;
						for (int zz = 0; zz < solution.size(); zz++)
							rootLPsol[zz] = solution[zz].asDouble();
						rootLPsolEx = true;
						if (cnt_rat == 0 && -lb.asDouble() > global_score && maxBlock == 1) {
							if (block[Lpick] == 1) {
								for (int iii = 0; iii < nVars();iii++) {
									if (block[iii] == 1) {
										fstStSol[iii] = solution[iii].asDouble();
									}
								}
								global_score = -lb.asDouble();
								discoveredNews += 500;
								coef_t gap;
								gap = abs(100.0*(-global_dual_bound + (-lb.asDouble())) / (abs(lb.asDouble())+1e-10) );
								if (!objInverted) {
									cerr << "\n+++++ " << decisionLevel() << " ++++v score: " << -global_score << " | time: " << time(NULL) - ini_time << " | "
										<< " dual: "<< -global_dual_bound << " gap=" << gap << "%";
								} else {
									cerr << "\n+++++ " << decisionLevel() << " ++++v score: " << global_score << " | time: " << time(NULL) - ini_time << " | "
										<< " dual: "<< global_dual_bound << " gap=" << gap << "%";
								}
								if (info_level >= 2) cerr
									<< ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
								cerr << endl;
								if (info_level >= 2) printBounds(10);
							}
						}
					} else {
						cerr << "Root-LP:" << "failed" << endl;
						if (!objInverted)  cerr << "Global dual bound:" << -global_dual_bound << endl;
						else cerr << "Global dual bound:" << global_dual_bound << endl;
						cerr << "Fixed:" << trail.size() << endl;
						if (eas[pick] == EXIST) score = n_infinity;
						else                    score = p_infinity;
						best_val = dont_know;
						stack_pick[decisionLevel()] = pick;

						goto Lrestart;

					}

				}

				if (status == algorithm::Algorithm::IT_LIMIT/*extSol::QpExternSolver::ABORT_IT_LIM && status != extSol::QpExternSolver::ABORT_TIME_LIM*/) {
					//if (status != extSol::QpExternSolver::OPTIMAL && status != extSol::QpExternSolver::INFEASIBLE) {
					cerr << "Warning: QBPSolver in controlled trouble" << endl;
					if (eas[pick] == EXIST) score = n_infinity;
					else                    score = p_infinity;
					best_val = dont_know;
					stack_pick[decisionLevel()] = pick;

					goto Lrestart;
				}
				//QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE,-1,/*-1*/feasPhase?-1:/*3*/3-4 /*simplex iterationen*/);

				if (useBendersBackJump && status == algorithm::Algorithm::INFEASIBLE) {
					if (/*listOfEnteredCuts.size() <= listOfCuts_lim[decisionLevel()] && */statusOK==true) {
						QlpStSolve.getBendersCut(maxLPStage, bd_lhs, bd_sign, bd_rhs, false, vardata.getData(), eas.getData());
						for (int i = 0; i < bd_lhs.size(); i++) {
							if (type[bd_lhs[i].index] == CONTINUOUS && assigns[bd_lhs[i].index] == extbool_Undef) {
								bd_lhs.clear();
								bd_rhs = 0.0;
								break;
							}
						}
					}
					if (!feasPhase && /*listOfEnteredCuts.size() > listOfCuts_lim[decisionLevel()] ||*/ bd_lhs.size() == 0 /*|| statusOK==false*/) {
						if (statusOK==true&&/*listOfEnteredCuts.size() <= listOfCuts_lim[decisionLevel()] &&*/ bd_lhs.size() == 0)
							if (info_level & 4) cerr << "lost Benders. ";
						//RESOLVE_FIXED(decisionLevel());
						QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE,-1,/*-1*/feasPhase?-1:/*3*/3-4 /*simplex iterationen*/);
						if (status == algorithm::Algorithm::INFEASIBLE) {
							QlpStSolve.getBendersCut(maxLPStage, bd_lhs, bd_sign, bd_rhs, false, vardata.getData(), eas.getData());
							for (int i = 0; i < bd_lhs.size(); i++) {
								if (type[bd_lhs[i].index] == CONTINUOUS && assigns[bd_lhs[i].index] == extbool_Undef) {
									bd_lhs.clear();
									bd_rhs = 0.0;
									break;
								}
							}
							if (bd_lhs.size() == 0 && info_level >= 2) cerr << "X";
							//else cerr << "s";
						} else if (info_level >= 2) cerr << "f";
					}
					//double lhs=0.0;
					//for (int h=0;h<bd_lhs.size();h++) {
					//	lhs = lhs + bd_lhs[h].value.asDouble()*optSol[bd_lhs[h].index];
					//}
					//assert(bd_sign == data::QpRhs::greaterThanOrEqual);
					//if (isOnTrack())  cerr << "bd_lhs<=bd_rhs? " << ((int)(lhs >= bd_rhs.asDouble())) << " " << lhs << " " << bd_rhs.asDouble() << " " << bd_sign << endl;
				}

				if (status == algorithm::Algorithm::FEASIBLE) {
					bool blockvar_av = false;
					if (eas[pick] == EXIST && -lb.asDouble() < (double)b) {
						//cerr << "b:" << b << "->" << -lb.asDouble() << endl;
						if (-lb.asDouble()+LP_EPS < b && -lb.asDouble()+LP_EPS > -lb.asDouble())
							b=(coef_t)(-lb.asDouble()+LP_EPS);
					}
					((yInterface*)yIF)->getRCandB(QlpStSolve.getExternSolver( maxLPStage ));
					LP_solved = true;
					for (int jj = 0; jj < solution.size();jj++) {
						if (assigns[jj] == extbool_Undef && getFixed(jj) == extbool_Undef && a > dont_know && type[jj] == BINARY
								&& eas[pick] == EXIST && block[pick] == maxBlock && type[pick] == BINARY) {
							double d1=0.0,d2=0.0;
							int rcf = ((yInterface*)yIF)->isReducedCostFixed(-a, lb.asDouble(), jj, d1,d2 );
							if (rcf == 0) {
								setFixed(jj, 0, decisionLevel()-1);
								addFixed(decisionLevel()-1,jj);
								cnt_df++;
							} else if (rcf == 1) {
								setFixed(jj, 1, decisionLevel()-1);
								addFixed(decisionLevel()-1, jj);
								cnt_df++;
							}
						}
						((yInterface*)yIF)->integers[jj].tmp_x = solution[jj].asDouble();
						if (type[/*pick*/jj] == CONTINUOUS) continue;
						double pcx;
						double pcy;
						if (best_cont_ix != -1) {
							pcx = (p_pseudocost[best_cont_ix] / (double)p_pseudocostCnt[best_cont_ix]) * (n_pseudocost[best_cont_ix] / (double)n_pseudocostCnt[best_cont_ix]);
							pcy = (p_pseudocost[jj] / (double)p_pseudocostCnt[jj]) * (n_pseudocost[jj] / (double)n_pseudocostCnt[jj]);
						} else {
							pcx = pcy = 0;
						}
						if (assigns[jj] != extbool_Undef) {
							if (assigns[jj] == 1) solution[jj] = data::QpNum(1.0);
							else if (assigns[jj] == 0) solution[jj] = data::QpNum(0.0);
							continue;
						} else {
							if (solution[jj].asDouble() >= 1.0-LP_EPS) {
								solution[jj] = data::QpNum(1.0);
								if (block[jj] == block[pick]) blockvar_av = true;
							} else if (solution[jj].asDouble() <= 0.0+LP_EPS) {
								solution[jj] = data::QpNum(0.0);
								if (block[jj] == block[pick]) blockvar_av = true;
							} else if (best_cont_ix == -1 && block[pick] == block[jj]) {
								best_activity = p_activity[jj]+n_activity[jj];
								best_cont_ix = jj;
							} else if (block[pick] == block[jj] && pcx != pcy && n_pseudocostCnt[best_cont_ix] + p_pseudocostCnt[best_cont_ix] >= 20 && n_pseudocostCnt[jj] + p_pseudocostCnt[jj]>= 20) {
								if (pcx > pcy) {
									best_cont_ix = jj;
									best_activity = p_activity[jj]+n_activity[jj];
								}
							} else if (block[pick] == block[jj] && (isInObj[best_cont_ix] > isInObj[jj] || (isInObj[best_cont_ix] == isInObj[jj] && best_activity < p_activity[jj]+n_activity[jj]))) {
								if (1||n_pseudocostCnt[best_cont_ix] + p_pseudocostCnt[best_cont_ix] < 20) {
									best_activity = p_activity[jj]+n_activity[jj];
									best_cont_ix = jj;
								}
							}
						}
					}
					if (decisionLevel() == 1 && processNo % 2 == 0) {
						if (info_level >= 2) cerr << "dual fixed variables: " << cnt_df << endl;
						static bool nbh=true;
						discoveredNews += 2*cnt_df;
						if (cnt_df > /*0*/(nVars()-trail.size()) / 30) {
							PurgeTrail(trail.size() - 1, decisionLevel() - 1);
							for (int zz = 0; zz < saveUs.size(); zz++) {
								QlpStSolve.setVariableLB(saveUs[zz], 0,type.getData());
								QlpStSolve.setVariableUB(saveUs[zz], 1,type.getData());
								if (!isDirty[saveUs[zz]]) {
									dirtyLPvars.push(saveUs[zz]);
									isDirty[saveUs[zz]] = true;
								}
							}
							saveUs.clear();
							if (isOnTrack()) cerr << "lost solution xy33" << endl;
							RESOLVE_FIXED(decisionLevel());
							break_from_outside = true;
							return _StepResult(STACK,global_score,b);
						}
					}

					if (free_uni_av || (blockvar_av && best_cont_ix == -1 && block[pick] != maxBlock)) {
						//TODO an dieser Stelle kann man ggfs die L�sung hernehmenund bis zur naechste Allvariable vorspielen
						if (best_cont_ix == -1 || free_uni_av) {
							if (solution[pick].asDouble() >= 0.9999) best_pol = 1;
							else if (solution[pick].asDouble() <= 0.0001) best_pol = 0;
						}
						best_activity = p_activity[pick]+n_activity[pick];
						best_cont_ix = pick;
					} else {
						insertVarOrder(pick);
						//pick = best_cont_ix;
					}
					//assert (best_cont_ix > -1 || block[pick] == maxBlock);

					if (best_cont_ix >= 0)
						HT->setEntry((coef_t)-lb.asDouble(), 0, best_cont_ix , nVars()+10, EXIST, UB,trail.size(), max_objective_iterations, dont_know, break_from_outside);
					massert(best_cont_ix==-1 || assigns[best_cont_ix] == extbool_Undef);        //kein Wert bisher zugewiesen
					if (-lb.asDouble() >= (double)constraintallocator[constraints[0]].header.rhs && -lb.asDouble() >= a) {
						if (local_ub > -lb.asDouble()) local_ub = (coef_t)(-lb.asDouble());
						insertVarOrder(pick);
						if (best_cont_ix == -1) {
							double rem_val = -lb.asDouble();
							int dl;
							int leader = -1;
							((yInterface*)yIF)->adaptSolution(solution, type.getData(), assigns.getData());
							if (USE_TRACKER) {
								cerr << "CHECK ";
								for (int ii=0;ii < solution.size();ii++) {
									cerr << "x" << ii << "=" << solution[ii].asDouble() << ", ";
								}
								cerr << endl;
								cerr << "a(" << lb.asDouble() << "," << /*a*/nVars()-trail.size() << "," << b<<",";
								for (int k=0;k<scenario.size();k++) cerr << (int)assigns[scenario[k]];
								cerr << ")";
								cerr << endl;
								for (int h=0;h< trail.size();h++) {
									cerr << " x" << trail[h] << "=" << (int)assigns[trail[h]] << " ";
								}
								cerr << endl;
								for (int h=0;h< nVars();h++) {
									if (type[h] == BINARY) cerr << "B";
									else cerr << "R";
									if (solution[h].asDouble() >= 1e-20 && solution[h].asDouble() < 1e-15) cerr << "o";
									cerr << solution[h].asDouble() << ",";
								}
								cerr << endl;
							}

							for (int uu=0; uu < solution.size();uu++)
								if (eas[uu] == EXIST) killer[uu] = (solution[uu].asDouble() < 0.5 ? 0 : 1);
							out_learnt.clear();
							for (int zz=0;zz < saveUs.size();zz++) {
								QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
								QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
								if (!isDirty[saveUs[zz]]) {
									dirtyLPvars.push(saveUs[zz]);
									isDirty[saveUs[zz]] = true;
								}
							}
							saveUs.clear();
							rem_val=-lb.asDouble();

							assert(eas[pick] == EXIST);
							if (0&&feasPhase /*|| eas[pick] == UNIV*/) { // TODO rechter Teil des || bestimmt falsch. Stehen lassen!
								RESOLVE_FIXED(decisionLevel());
								return _StepResult(STACK,(coef_t)(-lb.asDouble()),(coef_t)(-lb.asDouble()));
							}
							// TODO:in folg. zeilre: a statt -lb....?: if (-lb.asDouble() < a) r�cksprung ohne lernen
							// oder besser: useFastBendersBacktracking = true;
							double result = -objOffset+0.0;
							Constraint &c = constraintallocator[constraints[0]];
							if (rem_val > c.header.rhs && rem_val > a) {
								for (int i = 0; i < c.size();i++) {
									if (type[var(c[i])]==CONTINUOUS && assigns[var(c[i])] == extbool_Undef && !isFixed(var(c[i]))) {
										if (!sign(c[i])) result = result + c[i].coef * solution[var(c[i])].asDouble();
										else result = result - c[i].coef * solution[var(c[i])].asDouble();
										continue;
									}
									if (assigns[var(c[i])] != extbool_Undef || isFixed(var(c[i]))) {
										if (assigns[var(c[i])] != extbool_Undef) {
											if( abs((double)assigns[var(c[i])]-solution[var(c[i])].asDouble()) > 0.001 ) {
												if (type[var(c[i])]==BINARY) cerr << "Warning: numerical issues:" << (double)assigns[var(c[i])] << " " << solution[var(c[i])].asDouble() << " " << (int)((yInterface*)yIF)->getIsInSOSvars(var(c[i])) << endl;
											}
											if (sign(c[i])) result = result - c[i].coef * assigns[var(c[i])];
											else result = result + c[i].coef * assigns[var(c[i])];
										} else {
											if( abs((double)getFixed(var(c[i]))-solution[var(c[i])].asDouble()) > 0.001 ) {
												if (type[var(c[i])]==BINARY) cerr << "Warning: numerical issues II" << " " << (int)((yInterface*)yIF)->getIsInSOSvars(var(c[i])) << endl;
											}
											if (sign(c[i])) result = result - c[i].coef * getFixed(var(c[i]));
											else result = result + c[i].coef * getFixed(var(c[i]));
										}
									} else {
										assert(solution[var(c[i])] >= 0.0);
										if (solution[var(c[i])] > 0.5) {
											if (sign(c[i])) result = result - c[i].coef * 1.0;
											else result = result + c[i].coef * 1.0;
										}
									}
								}
							} else {
								result = rem_val;
							}

							dl = decisionLevel()+1;
							if (useBendersBackJump) computeLocalBackjump((coef_t)(result/*-lb.asDouble()*//*-abs(lb.asDouble()*objective_epsilon)*/),Lpick, b, score, out_vcp, only_one, true, dl);
							for (int zz=0;zz < saveUs.size();zz++) {
								QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
								QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
								if (!isDirty[saveUs[zz]]) {
									dirtyLPvars.push(saveUs[zz]);
									isDirty[saveUs[zz]] = true;
								}
							}
							saveUs.clear();
							//return _StepResult(STACK,(coef_t)(-lb.asDouble()),(coef_t)(-lb.asDouble()));
							if (isOnTrack()) {
								cerr << "opt sol accept a()" << endl;
							}
							RESOLVE_FIXED(decisionLevel());
							if (abs(result-rem_val) > 1.0) cerr << "Error: !!" << result << "," << rem_val << "," << objOffset << "!!" << endl;
							rem_val = result;
							if (block[pick] == maxBlock) {
								//cerr << "chakah!" << endl;
								crossUs(feasPhase, rem_val, solution.data());
							}
							if (block[pick] == 1) {
								for (int iii = 0; iii < nVars();iii++) {
									if (block[iii] == 1) {
										/*if (assigns[iii] != extbool_Undef) {
											fstStSol[iii] = assigns[iii];
										} else */fstStSol[iii] = solution[iii].asDouble();
									}
								}
								global_score = rem_val;
								discoveredNews += 500;
								coef_t gap;
								gap = abs(100.0*(-global_dual_bound + rem_val) / (abs(rem_val)+1e-10) );
								if (LimHorSrch == false) {
									if (!objInverted) {
										cerr << "\n+++++ " << decisionLevel() << " ++++x score: " << -global_score << " | time: " << time(NULL) - ini_time << " | "
											<< " dual: "<< -global_dual_bound << " gap=" << gap << "%";
										if (info_level >= 2) cerr
											<< ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
										cerr << endl;
										if (info_level >= 2) printBounds(10);
										if (gap < SOLGAP) break_from_outside = true;
									} else {
										cerr << "\n+++++ " << decisionLevel() << " ++++x score: " << global_score << " | time: " << time(NULL) - ini_time << " | "
											<< " dual: "<< global_dual_bound << " gap=" << gap << "%";
										if (info_level >= 2) cerr
											<< ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
										cerr << endl;
										if (info_level >= 2) printBounds(10);
										if (gap < SOLGAP) break_from_outside = true;
									}
								}
							}
							return _StepResult(STACK,(coef_t)(rem_val),(coef_t)(rem_val));
						} else {
							if (!feasPhase && -lb.asDouble() < a) {
								int dl;

								if (eas[pick] == UNIV) { // TODO dieses if ...das n�tig?
									insertVarOrder(pick);
									for (int zz=0;zz < saveUs.size();zz++) {
										QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
										QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
										if (!isDirty[saveUs[zz]]) {
											dirtyLPvars.push(saveUs[zz]);
											isDirty[saveUs[zz]] = true;
										}
									}
									saveUs.clear();
									if (isOnTrack()) cerr << "lost solution 2" << endl;
									RESOLVE_FIXED(decisionLevel());
									return _StepResult(STACK,min((coef_t)a,(coef_t)global_score),min((coef_t)a,(coef_t)global_score));
								}
								for (int zz=0;zz < saveUs.size();zz++) {
									QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
									QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
									if (!isDirty[saveUs[zz]]) {
										dirtyLPvars.push(saveUs[zz]);
										isDirty[saveUs[zz]] = true;
									}
								}
								saveUs.clear();
								dl = decisionLevel()+1;
								if (!useBendersBackJump) {
									if (isOnTrack()) cerr << "lost solution xy34" << endl;
									RESOLVE_FIXED(decisionLevel());
									return _StepResult(STACK,-lb.asDouble(),a);
								} else {
									SearchResult r = computeLocalBackjump(min((coef_t)a,(coef_t)global_score), Lpick, b, score, out_vcp, only_one, true, dl);
									if (isOnTrack()) cerr << "lost solution 3" << endl;
									if (dl < decisionLevel()-1-SEARCH_LEARN_TRADEOFF) {
										if (USE_TRACKER & 2) cerr << "J13";
										returnUntil(dl);
										PurgeTrail(trail.size()-1,decisionLevel()-1);
									}
									RESOLVE_FIXED(decisionLevel());
									return _StepResult(STACK,r.value,r.u_bound);
								}
							}

							int bestCliq=-1;
							int bestCliqVal=-1;
							double leftval, rightval;
							assert(bestCliq<=-1);
							if (USE_TRACKER) cerr << "b";

							//static uint64_t enterb=1;
							//static uint64_t enterst=1;
							//static uint64_t nost=1;

							int best_pick = -1;
							int best_pol = -1;
							coef_t best_value = n_infinity;
							coef_t pick0eval = n_infinity;
							coef_t pick1eval = n_infinity;
							int lastImp=0;
							coef_t miniprobe_dual_bound = -n_infinity;
							coef_t miniprobe_score = n_infinity;

							//if (useStrongBranching && !feasPhase && (num_props < 900*num_decs || (decisionLevel() <= 10 /*&& ((double)LPtim < 0.1*(double)(time(NULL)-ini_time))*/)) && eas[pick] == EXIST) {
							if (useStrongBranching && !feasPhase && /*decisionLevel() <= (num_props < 600*num_decs ? ((double)nVars()) :  2*num_decs*1000.0 / ((double)num_props)) &&*/ eas[pick] == EXIST) {
								LPsortmode = true;
								if (LPsortmode && USE_TRACKER) cerr << "*Y" << numLPs << "," << numbLPs << "*Y";

								sorter.clear();
								for (int jj = 0; jj < solution.size();jj++) {
									if (type[jj] == CONTINUOUS || block[pick] < block[jj] || eas[pick] == UNIV) continue;
									if (((yInterface*)yIF)->getIsInSOSvars(jj)) continue;
									if (assigns[jj] == extbool_Undef) {
										if ((solution[jj].asDouble() < 0.999 && solution[jj].asDouble() >= 0.001) || //normal 1 null mehr
												(0&&solution[jj].asDouble() < 1.0-LP_EPS && solution[jj].asDouble() >= LP_EPS && sorter.size() < 3) ) {
											int bitcnt = ((yInterface*)yIF)->integers[jj].bitcnt;
											int index = ((yInterface*)yIF)->integers[jj].index;
											int leader = ((yInterface*)yIF)->integers[jj].pt2leader;
											int leader_index = ((yInterface*)yIF)->integers[jj].index;
												brokenCnt[jj]++;
												sorter.push(jj);
										}
										//if (sorter.size() > sqrt((double)nVars())) break;
									}
								}
								if (sorter.size() == 0) sorter.push(best_cont_ix);

								algorithm::Algorithm::SolutionStatus statush0;
								std::vector<data::QpNum> solutionh0;
								data::QpNum lbh0;
								data::QpNum ubh0;
								std::vector<data::IndexedElement> bd_lhsh00;
								std::vector<data::IndexedElement> bd_lhsh01;
								data::QpRhs::RatioSign bd_signh00;
								data::QpRhs::RatioSign bd_signh01;
								std::vector<int> bd_reash00;
								std::vector<int> bd_reash01;
								std::vector<int> bd_assih00;
								std::vector<int> bd_assih01;
								std::vector<int> bd_trailh00;
								std::vector<int> bd_trailh01;
								data::QpNum bd_rhsh00;
								data::QpNum bd_rhsh01;
								insertVarOrder(pick);
								sort(sorter,lpSOL);
								int max_activity=100000000;
								int max_cnt = sorter.size() / 10;
								int sbstart = time(NULL);
								bool LPHA=true;

								if (0) {
									bool forced20=false;
									bool forced21=false;
									for (int jjj=0;jjj< sorter.size();jjj++) {
										int j;
										j = CM.FirstAdjacentInConflictGraph(2*sorter[jjj]);
										if (j >= 0) {
												//cerr << "j=" << j << endl;
												int kk = CM.NextAdjacentInConflictGraph(j);
												while (kk >= 0) {
													  //cerr << "j=" << j << " kk=" << kk << " a(j)=" << CM.getAdjacent(j) << " a(kk)=" << CM.getAdjacent(kk) << endl;
													  int w = CM.getAdjacent(kk);
													  int var_w = (w >> 1);
													  int sign_w = (w & 1);
													  if ( sign_w && assigns[var_w] == 0) forced20 = true;
													  if (!sign_w && assigns[var_w] == 1) forced20 = true;
													  kk = CM.NextAdjacentInConflictGraph(kk);
												}
										}
									}
									for (int jjj=0;jjj< sorter.size();jjj++) {
										int j;
										j = CM.FirstAdjacentInConflictGraph(2*sorter[jjj]+1);
										if (j >= 0) {
												//cerr << "j=" << j << endl;
												int kk = CM.NextAdjacentInConflictGraph(j);
												while (kk >= 0) {
													  //cerr << "j=" << j << " kk=" << kk << " a(j)=" << CM.getAdjacent(j) << " a(kk)=" << CM.getAdjacent(kk) << endl;
													  int w = CM.getAdjacent(kk);
													  int var_w = (w >> 1);
													  int sign_w = (w & 1);
													  if ( sign_w && assigns[var_w] == 0) forced21 = true;
													  if (!sign_w && assigns[var_w] == 1) forced21 = true;
													  kk = CM.NextAdjacentInConflictGraph(kk);
												}
										}
									}
									if (info_level >= 2)  {
										if (forced21 && forced20) cerr << " BOTH ";
										else if (forced20) cerr << " f20 ";
										else if (forced21) cerr << " f21 ";
									}
								}

								bool useSBsig=true;
								if (irand(random_seed,7) == 0) useSBsig=false;
#ifndef FIND_BUG
								for (int jjj = 0; ac && jjj < sorter.size() && (jjj < (num_props < 300*num_decs ? 50 : 20) || jjj < sorter.size() / 10 || father_ix==0) ;jjj++) {
									if (jjj > lastImp+20) break;
									if (jjj > 0 && time(NULL)-ini_time < 20*(time(NULL)-sbstart)) break;
#else
								for (int jjj = 0; ac && jjj < 50 && (!useSBsig || SBcnt < 10 || jjj <= 2*(SBavg/SBcnt)+1+sqrt(SBsigEst)+1)   && jjj < sorter.size() && (jjj < (num_props < 300*num_decs ? 50 : 20) || jjj < sorter.size() / 10 || father_ix==0) ;jjj++) {
								        if (jjj > lastImp+20/*3*//*7*//*20*/) break;
									if (jjj > 0 && time(NULL)-ini_time < 20*(time(NULL)-sbstart)) break;
#endif
									//if (jjj > 3 && best_value < 1/*LPHA==false*/) break;
									//if (jjj > 0 && (time(NULL)-sbstart) > 2) break;
									pick = sorter[jjj];
									//assert(((yInterface*)yIF)->getIsInSOSvars(pick)==0);
									if (type[pick] == CONTINUOUS) continue;
									if (0) {

									} else
										if (assigns[pick] == extbool_Undef) {
											if (solution[pick].asDouble() < 0.999 && solution[pick].asDouble() >= 0.001) {
											    if (eas[pick] != EXIST) {
											      cerr << "Error: eas[" << pick;
                                                  cerr << "]=" << (int)eas[pick] << endl;
											      for (int m=0; m < sorter.size();m++)
												     cerr << sorter[m] << " ";
											      cerr << endl;
											    }

												assert(eas[pick] == EXIST);
												// teste variable auf 0
												// folgere max 5 bis 10 Folgerungen aus
												// best0eval = bewerte mittels lp
												// nimm zug zur�ck

												// teste variable auf 1
												// folgere max 5 bis 10 Folgerungen  aus
												// best1eval = bewerte mittels lp
												// nimm zug zur�ck


												assert(val[0]+val[1]==1);
												assert(val[0] != val[1]);
												val[0] = 1;
												val[1] = 0;
												bool fullEval0 = true;
												bool fullEval1 = true;
												//uBnds.initUBds();
												if (score > miniprobe_score) miniprobe_score = score;
												score = n_infinity;
												int found0=-1;
												int found1=-1;
												static ca_vec<CoeVar> cbc0;
												cbc0.clear();
												static ca_vec<CoeVar> cbc1;
												cbc1.clear();

												for (val_ix = 0; val_ix <= 1;val_ix++) {
#ifdef FIND_BUG
													if (isFixed(pick) && getFixed(pick) == 1-val[val_ix]) {
														assert(getFixed(pick) != extbool_Undef);
														if (val[val_ix] == 0) pick0eval = n_infinity;
														else pick1eval = n_infinity;
														continue;
													}
													if (decisionLevel() > (num_props < 200*num_decs ? 2*sqrt((double)nVars()) : num_decs*200.0*sqrt((double)nVars()) / ((double)num_props)) || (father_ix == 1 && sfather_ix > 2)) {
														if (val[val_ix]==0 && n_pseudocostCnt[pick] > 5 && irand(random_seed,10)>0) {
															pick0eval =  - (coef_t)lb.asDouble() - n_pseudocost[pick] / n_pseudocostCnt[pick];
															fullEval0 = false;
															continue;
														}
														if (val[val_ix]==1 && p_pseudocostCnt[pick] > 5 && irand(random_seed,10)>0) {
															pick1eval =   - (coef_t)lb.asDouble() - p_pseudocost[pick] / p_pseudocostCnt[pick];
															fullEval1 = false;
															continue;
														}
													}
													oob = assign(pick,val[val_ix], trail.size(),CRef_Undef, false);
													if (oob != ASSIGN_OK) {
														if (val[val_ix] == 0) {
															found0 = oob;
															pick0eval = n_infinity;
															Constraint &c = constraintallocator[oob];
															bd_lhsh00.clear();
															for (int ii=0;ii<c.size();ii++) {
																bd_lhsh00.push_back(0);
																bd_lhsh00[bd_lhsh00.size()-1].index = var(c[ii]);
																bd_lhsh00[bd_lhsh00.size()-1].value = (double)c[ii].coef;
																if(sign(c[ii])) bd_lhsh00[bd_lhsh00.size()-1].value *= -1.0;
															}
															bd_signh00 = data::QpRhs::greaterThanOrEqual;
															bd_rhsh00 = (double)c.header.rhs;
															bd_reash00.clear();
															bd_assih00.clear();
															bd_trailh00.clear();
															bd_trailh00.push_back(pick);
															bd_assih00.push_back(0);
															bd_reash00.push_back(oob);

															int high_2 = -1;
															int high_2j;
															int pickpos = -1;
															for (int j = 0; j < c.size();j++) {
																if (var(c[j]) == pick) {
																	pickpos = j;
																	assert(assigns[pick]==extbool_Undef);
																}
																if (assigns[var(c[j])] != extbool_Undef)
																	if (vardata[var(c[j])].level > high_2) {
																		high_2 = vardata[var(c[j])].level;
																		high_2j = j;
																	}
															}
															if(0)if (high_2 > -1 && !isFixed(pick)) {
																	setFixed(pick, 1);
																	addFixed(high_2, pick);
															}
															if (high_2 > -1 && high_2 < decisionLevel()-3 && pickpos > -1) {
																for (int zz=0;zz < saveUs.size();zz++) {
																	QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																	QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																	if (!isDirty[saveUs[zz]]) {
																		dirtyLPvars.push(saveUs[zz]);
																		isDirty[saveUs[zz]] = true;
																	}
																}
																saveUs.clear();

																out_vcp.cr = oob;
																out_vcp.pos = pickpos;
																out_vcp.v = c[pickpos].x;

																returnUntil(high_2);
																if (propQlimiter[out_vcp.v] <= 0) {
																   PROPQ_PUSH(out_vcp);
																   propQlimiter[out_vcp.v] = propQ.size();
																} else propQ[propQlimiter[out_vcp.v]-1] = out_vcp;
																//-- PROPQ_PUSH(out_vcp);
																PurgeTrail(trail.size()-1,decisionLevel()-1);
																//decreaseDecisionLevel();
																//unassign(pick);
#ifdef FIND_BUG2
																insertVarOrder(pick);
#endif
																RESOLVE_FIXED(decisionLevel());
																if(0){
																	cerr << "A: ";
																	Constraint &c = constraintallocator[oob];
																	for (int u=0;u<c.size();u++) {
																		cerr << (sign(c[u]) ? "-" : "") << c[u].coef <<  (eas[var(c[u])] == EXIST ? "x" : "y") << ((int)var(c[u])) << "(" << (int)assigns[var(c[u])] << "," << (int)type[var(c[u])] <<  "," << vardata[var(c[u])].level << ")" << " + ";
																	}
																	if (c.header.isSat) cerr << "0 --> " << decisionLevel()  << endl;
																	else cerr << "0 >= " << c.header.rhs << " --> "  << decisionLevel() << endl;

																}
																if (isOnTrack()) cerr << "lost solution 1324" << endl;
																if (eas[pick] == EXIST) {
																	// TODO if (!forbidHashing) HT->setEntry(/*score*/n_infinity, val[val_ix], pick , nVars()+10, /*eas[pick]*/EXIST, FIT,trail.size(), max_objective_iterations, dont_know, break_from_outside);
																	return _StepResult(STACK,/*n_infinity,n_infinity);*//*dont_know*/score,score);
																} else {
																	return _StepResult(STACK,n_infinity,n_infinity);
																}
																cerr << "-" << decisionLevel() << "," << pick << "," << jjj << "-";

																RESOLVE_FIXED(decisionLevel());
																return _StepResult(STACK,n_infinity,n_infinity);

															}


														} else {
															found1 = oob;
															pick1eval = n_infinity;
															Constraint &c = constraintallocator[oob];
															bd_lhsh01.clear();
															for (int ii=0;ii<c.size();ii++) {
																bd_lhsh01.push_back(0);
																bd_lhsh01[bd_lhsh01.size()-1].index = var(c[ii]);
																bd_lhsh01[bd_lhsh01.size()-1].value = (double)c[ii].coef;
																if(sign(c[ii])) bd_lhsh01[bd_lhsh01.size()-1].value *= -1.0;
															}
															bd_signh01 = data::QpRhs::greaterThanOrEqual;
															bd_rhsh01 = (double)c.header.rhs;
															bd_reash01.clear();
															bd_assih01.clear();
															bd_trailh01.clear();
															bd_trailh01.push_back(pick);
															bd_assih01.push_back(1);
															bd_reash01.push_back(oob);


															int high_2 = -1;
															int high_2j;
															int pickpos = -1;
															for (int j = 0; j < c.size();j++) {
																if (var(c[j]) == pick) {
																	pickpos = j;
																	assert(assigns[pick]==extbool_Undef);
																}
																if (assigns[var(c[j])] != extbool_Undef)
																	if (vardata[var(c[j])].level > high_2) {
																		high_2 = vardata[var(c[j])].level;
																		high_2j = j;
																	}
															}
															if(0)if (high_2 > -1 && !isFixed(pick)) {
																	setFixed(pick, 1);
																	addFixed(high_2, pick);
															}
															if (high_2 > -1 && high_2 < decisionLevel()-3 && pickpos > -1) {
																for (int zz=0;zz < saveUs.size();zz++) {
																	QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																	QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																	if (!isDirty[saveUs[zz]]) {
																		dirtyLPvars.push(saveUs[zz]);
																		isDirty[saveUs[zz]] = true;
																	}
																}
																saveUs.clear();

																out_vcp.cr = oob;
																out_vcp.pos = pickpos;
																out_vcp.v = c[pickpos].x;

																returnUntil(high_2);
																if (propQlimiter[out_vcp.v] <= 0) {
																   PROPQ_PUSH(out_vcp);
																   propQlimiter[out_vcp.v] = propQ.size();
																} else propQ[propQlimiter[out_vcp.v]-1] = out_vcp;
																//-- PROPQ_PUSH(out_vcp);
																PurgeTrail(trail.size()-1,decisionLevel()-1);
																//decreaseDecisionLevel();
																//unassign(pick);
#ifdef FIND_BUG2
																insertVarOrder(pick);
#endif
																RESOLVE_FIXED(decisionLevel());
																if (isOnTrack()) cerr << "lost solution 1324" << endl;
																if(0){
																	cerr << "B: ";
																	Constraint &c = constraintallocator[oob];
																	for (int u=0;u<c.size();u++) {
																		cerr << (sign(c[u]) ? "-" : "") << c[u].coef <<  (eas[var(c[u])] == EXIST ? "x" : "y") << ((int)var(c[u])) << "(" << (int)assigns[var(c[u])] << "," << (int)type[var(c[u])] <<  "," << vardata[var(c[u])].level << ")" << " + ";
																	}
																	if (c.header.isSat) cerr << "0 --> " << decisionLevel()  << endl;
																	else cerr << "0 >= " << c.header.rhs << " --> "  << decisionLevel() << endl;

																}
																if (eas[pick] == EXIST) {
																	// TODO if (!forbidHashing) HT->setEntry(/*score*/n_infinity, val[val_ix], pick , nVars()+10, /*eas[pick]*/EXIST, FIT,trail.size(), max_objective_iterations, dont_know, break_from_outside);
																	return _StepResult(STACK,/*n_infinity,n_infinity);*//*dont_know*/score,score);
																} else {
																	return _StepResult(STACK,n_infinity,n_infinity);
																}
															}




														}
														if (found0 >= 0 && found1 >= 0) {
															Constraint &c0 = constraintallocator[found0];
															Constraint &c1 = constraintallocator[found1];
															ca_vec< CoeVar > out;
															double nego0 = 0.0;
															double nego1 = 0.0;
															int high_1 = -1;
															int high_2 = -1;
															for (int ii=0; ii < bd_lhsh00.size(); ii++) {
																assert(bd_signh00 == data::QpRhs::greaterThanOrEqual);
																CoeVar q = mkCoeVar(bd_lhsh00[ii].index, (coef_t)(bd_lhsh00[ii].value.asDouble() >= 0.0?bd_lhsh00[ii].value.asDouble():-bd_lhsh00[ii].value.asDouble()), bd_lhsh00[ii].value.asDouble() >= 0.0?false:true);
																if (sign(q)) nego0 = nego0 + 1.0;
																out.push(q);
															}
															for (int ii=0; ii < bd_lhsh01.size(); ii++) {
																assert(bd_signh01 == data::QpRhs::greaterThanOrEqual);
																CoeVar q = mkCoeVar(bd_lhsh01[ii].index, (coef_t)(bd_lhsh01[ii].value.asDouble() >= 0.0?bd_lhsh01[ii].value.asDouble():-bd_lhsh01[ii].value.asDouble()), bd_lhsh01[ii].value.asDouble() >= 0.0?false:true);
																if (sign(q)) nego1 = nego1 + 1.0;
																out.push(q);
															}
															ca_vec<CoeVar> cbc;
															bool dCBC = deriveCombBC(out, pick, cbc);
															if (dCBC) {
																PurgeTrail(trail.size()-1,decisionLevel()-1);
																//cerr << "Sq4-" << decisionLevel();
																int v1=-1;
																int v2=-1;
																for (int i = 0; i < cbc.size();i++) {
																	int real_level = vardata[var(cbc[i])].level;
																	if (vardata[var(cbc[i])].reason != CRef_Undef) real_level--;
																	if (assigns[var(cbc[i])] == extbool_Undef) continue;
																	if (high_1 == -1) {
																		high_1 = real_level;
																		v1 = var(cbc[i]);
																	} else {
																		if (real_level > high_1) {
																			high_2 = high_1;
																			high_1 = real_level;
																			v2 = v1;
																			v1 = var(cbc[i]);
																		} else {
																			if (high_2 == -1 || real_level > high_2) {
																				high_2 = real_level;
																				v2 = var(cbc[i]);
																			}
																		}
																	}
																}
																for (int zz=0;zz < saveUs.size();zz++) {
																	QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																	QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																	if (!isDirty[saveUs[zz]]) {
																		dirtyLPvars.push(saveUs[zz]);
																		isDirty[saveUs[zz]] = true;
																	}
																}
																saveUs.clear();

																if (high_2>-1 && decisionLevel() - high_2 > 2) {
																	int tl = high_1;//vardata[trail[trail_lim[high_1]-1]].level;//high_0_1;// - 1;
																	//assert(assigns[trail[trail_lim[high_1]-1]] != extbool_Undef);
																	if (assigns[v1] != extbool_Undef) {
																		assert(assigns[v1] != extbool_Undef);
																		setFixed(v1, 1-assigns[v1]);
																		//cerr << "V2=" << v2 << endl;
																		addFixed(vardata[v2].level, v1);
																	} else {
																		cerr << "Warning: v1 not set" << endl;
																		//assert(0);
																	}
																	if (USE_TRACKER & 2) cerr << "J5114";
																	returnUntil(tl);
																}
																//cerr << "-" << decisionLevel() << "," << pick << "," << jjj << "-";

																RESOLVE_FIXED(decisionLevel());
																return _StepResult(STACK,n_infinity,n_infinity);
															}


														}
#else
														if (isFixed(pick) && getFixed(pick) == 1-val[val_ix]) {
															assert(getFixed(pick) != extbool_Undef);
															if (val[val_ix] == 0) pick0eval = n_infinity;
															else pick1eval = n_infinity;
															continue;
														}
														if (decisionLevel() > 2*sqrt((double)nVars()) || (father_ix == 1 && sfather_ix > 2)) {
															if (val[val_ix]==0 && n_pseudocostCnt[pick] > 5 && irand(random_seed,10)>0) {
																pick0eval =  - (coef_t)lb.asDouble() - n_pseudocost[pick] / n_pseudocostCnt[pick];
																continue;
															}
															if (val[val_ix]==1 && p_pseudocostCnt[pick] > 5 && irand(random_seed,10)>0) {
																pick1eval =   - (coef_t)lb.asDouble() - p_pseudocost[pick] / p_pseudocostCnt[pick];
																continue;
															}
														}
														oob = assign(pick,val[val_ix], trail.size(),CRef_Undef, false);
														if (oob != ASSIGN_OK) {
															if (val[val_ix] == 0) {
																pick0eval = n_infinity;
																Constraint &c = constraintallocator[oob];
																bd_lhsh00.clear();
																for (int ii=0;ii<c.size();ii++) {
																	bd_lhsh00.push_back(0);
																	bd_lhsh00[bd_lhsh00.size()-1].index = var(c[ii]);
																	bd_lhsh00[bd_lhsh00.size()-1].value = (double)c[ii].coef;
																	if(sign(c[ii])) bd_lhsh00[bd_lhsh00.size()-1].value *= -1.0;
																}
																bd_signh00 = data::QpRhs::greaterThanOrEqual;
																bd_rhsh00 = (double)c.header.rhs;
																bd_reash00.clear();
																bd_assih00.clear();
																bd_trailh00.clear();
																bd_trailh00.push_back(pick);
																bd_assih00.push_back(0);
																bd_reash00.push_back(oob);
															} else {
																pick1eval = n_infinity;
																Constraint &c = constraintallocator[oob];
																bd_lhsh01.clear();
																for (int ii=0;ii<c.size();ii++) {
																	bd_lhsh01.push_back(0);
																	bd_lhsh01[bd_lhsh01.size()-1].index = var(c[ii]);
																	bd_lhsh01[bd_lhsh01.size()-1].value = (double)c[ii].coef;
																	if(sign(c[ii])) bd_lhsh01[bd_lhsh01.size()-1].value *= -1.0;
																}
																bd_signh01 = data::QpRhs::greaterThanOrEqual;
																bd_rhsh01 = (double)c.header.rhs;
																bd_reash01.clear();
																bd_assih01.clear();
																bd_trailh01.clear();
																bd_trailh01.push_back(pick);
																bd_assih01.push_back(1);
																bd_reash01.push_back(oob);
															}
#endif
														//Constraint &c = constraintallocator[oob];
														//c.print(c,assigns,false);
														if (info_level >= 2) cerr << ".";
													} else {
														increaseDecisionLevel(); //starts with decision level 1 in depth 0
														if (hs_propagate(confl, confl_var, confl_partner, false, true, 1000000/*false, num_props < 300*num_decs ? 100 : 50*/)) {
															for (int hh = 0; hh < dirtyLPvars.size();hh++) {
																if (getFixed(dirtyLPvars[hh]) == extbool_Undef && assigns[dirtyLPvars[hh]] == extbool_Undef) {
																	if (type[dirtyLPvars[hh]] == BINARY && eas[dirtyLPvars[hh]] == EXIST) {
																		QlpStSolve.setVariableLB(dirtyLPvars[hh],0,type.getData());
																		QlpStSolve.setVariableUB(dirtyLPvars[hh],1,type.getData());
																	}
																} else if (assigns[dirtyLPvars[hh]] != extbool_Undef) {
																	if (USE_ASSIGNVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)assigns[dirtyLPvars[hh]],type.getData());
																} else {
																	if (USE_EARLYVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)getFixed(dirtyLPvars[hh]),type.getData());
																}

																updateStageSolver(converted_block[pick] >> CONV_BLOCK_RIGHT_SHIFT,dirtyLPvars[hh],dirtyLPvars[hh]);
																isDirty[dirtyLPvars[hh]] = false;
															}
															while (dirtyLPvars.size() > 0) dirtyLPvars.pop();
															solutionh0.clear();
															numLPs++;
															int lpsteps=-1;
															//lpsteps = max(10, (int) ((double)(nVars()-trail.size()) / log((double)(nVars()-trail.size()) ) ) );
															unsigned int lpt=time(NULL);
															QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, statush0, lbh0, ubh0, solutionh0,algorithm::Algorithm::WORST_CASE,-1,/*-1*/feasPhase?-1:/*3*//*3-4*/lpsteps /*simplex iterationen*/);
															LPtim += time(NULL)-lpt;
															LPcntSB++;
															LPcnt++;
															if (statush0 == algorithm::Algorithm::IT_LIMIT) {
																if (info_level >= 2) cerr << "H";
																if (best_pick != -1) {
																	hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																	decreaseDecisionLevel();
																	unassign(pick);
																	jjj = sorter.size();
																	continue;
																} else {
																	best_pick = jjj;
																	hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																	decreaseDecisionLevel();
																	unassign(pick);
																	jjj = sorter.size();
																	continue;
																}
																//statush0 = algorithm::Algorithm::FEASIBLE;
															}
#ifdef FIND_BUG
															if (statush0 == algorithm::Algorithm::INFEASIBLE && useEarlyBackjump) {
																if (val[val_ix] == 0) {
																	bd_lhsh00.clear();
																	bd_reash00.clear();
																	bd_assih00.clear();
																	bd_trailh00.clear();
																	for (int ii = trail.size()-1; ii >=0 ;ii--) {
																		bd_reash00.push_back(vardata[trail[ii]].reason);
																		bd_assih00.push_back(assigns[trail[ii]]);
																		//cerr << "s1et" << trail[ii] << "=" << (int)assigns[trail[ii]] << endl;
																		bd_trailh00.push_back(trail[ii]);
																		if (trail[ii] == pick) break;
																	}
																} else {
																	bd_lhsh01.clear();
																	bd_reash01.clear();
																	bd_assih01.clear();
																	bd_trailh01.clear();
																	for (int ii = trail.size()-1; ii >=0 ;ii--) {
																		bd_reash01.push_back(vardata[trail[ii]].reason);
																		bd_assih01.push_back(assigns[trail[ii]]);
																		bd_trailh01.push_back(trail[ii]);
																		//cerr << "s2et" << trail[ii] << "=" << (int)assigns[trail[ii]] << "=" << bd_assih01[bd_assih01.size()-1] << endl;
																		if (trail[ii] == pick) break;
																	}
																}
																if (val[val_ix] == 0) {
																	QlpStSolve.getBendersCut(maxLPStage, bd_lhsh00, bd_signh00, bd_rhsh00, false, vardata.getData(), eas.getData());
																	for (int iii = 0; iii < bd_lhsh00.size(); iii++) {
																		if (type[bd_lhsh00[iii].index] == CONTINUOUS && assigns[bd_lhsh00[iii].index] == extbool_Undef) {
																			bd_lhsh00.clear();
																			bd_rhsh00 = 0.0;
																			break;
																		}
																	}

																	if (USE_TRACKON > 0) {
																		double lhs=0.0;
																		for (int h=0;h<bd_lhsh00.size();h++) {
																			lhs = lhs + bd_lhsh00[h].value.asDouble()*((double)optSol[bd_lhsh00[h].index]);
																		}
																		assert(bd_signh00 == data::QpRhs::greaterThanOrEqual);
																		if (isOnTrack()) cerr << "bd_lhsh00<=bd_rhs? " << ((int)(lhs <= bd_rhsh00.asDouble())) << " " << lhs << " " << bd_rhsh00.asDouble()<< endl;
																	}
																} else {
																	QlpStSolve.getBendersCut(maxLPStage, bd_lhsh01, bd_signh01, bd_rhsh01, false, vardata.getData(), eas.getData());
																	for (int iii = 0; iii < bd_lhsh01.size(); iii++) {
																		if (type[bd_lhsh01[iii].index] == CONTINUOUS && assigns[bd_lhsh01[iii].index] == extbool_Undef) {
																			bd_lhsh01.clear();
																			bd_rhsh01 = 0.0;
																			break;
																		}
																	}
																	if (USE_TRACKON > 0) {
																		double lhs=0.0;
																		for (int h=0;h<bd_lhsh01.size();h++) {
																			lhs = lhs + bd_lhsh01[h].value.asDouble()*((double)optSol[bd_lhsh01[h].index]);
																		}
																		assert(bd_signh01 == data::QpRhs::greaterThanOrEqual);
																		if (isOnTrack()) cerr << "bd_lhsh01<=bd_rhs? " << ((int)(lhs <= bd_rhsh01.asDouble())) << " " << lhs << " " << bd_rhsh01.asDouble()<< endl;
																	}
																}
															}
#endif
															if (statush0 == algorithm::Algorithm::INFEASIBLE) {
																if (useEarlyBackjump) {
																	bool fbA=true;
																	bool aLC=true;
		#define OP_ON_INFI
		#ifdef OP_ON_INFI
																	if (val[val_ix] == 0) pick0eval = n_infinity;
																	else pick1eval = n_infinity;
																	if (val_ix == 1 || eas[pick] == UNIV) {
																		if ((val[0]==0 ? pick0eval : pick1eval) < miniprobe_dual_bound || eas[pick] == UNIV) {
																			if (eas[pick] == UNIV) miniprobe_dual_bound = n_infinity;
																			else miniprobe_dual_bound = (val[0]==0 ? pick0eval : pick1eval);
																			if(!(pick0eval == n_infinity && pick1eval == n_infinity))
																				if (eas[pick] == UNIV || score >= miniprobe_dual_bound || miniprobe_score >= miniprobe_dual_bound || miniprobe_dual_bound <= a) {
																					/*if (eas[pick] == UNIV) cerr << "univ";
				if (score >= miniprobe_dual_bound) cerr << "s>=mdb";
				if (miniprobe_score >= miniprobe_dual_bound) cerr << "ms>=mdb";
				if (miniprobe_dual_bound <= a) cerr << "mdb<=a";*/
																					static ca_vec<CoeVar> cbc;
																					cbc.clear();
																					int high_1=-1, high_2=-1;
																					in_learnt.clear();
																					if (val[val_ix] == 0) {
																						for (int ii=0; ii < bd_lhsh00.size(); ii++) {
																							assert(bd_signh00 == data::QpRhs::greaterThanOrEqual);
																							CoeVar q = mkCoeVar(bd_lhsh00[ii].index, (coef_t)(bd_lhsh00[ii].value.asDouble() >= 0.0?bd_lhsh00[ii].value.asDouble():-bd_lhsh00[ii].value.asDouble()), bd_lhsh00[ii].value.asDouble() >= 0.0?false:true);
																							in_learnt.push(q);
																						}
																					} else {
																						for (int ii=0; ii < bd_lhsh01.size(); ii++) {
																							assert(bd_signh01 == data::QpRhs::greaterThanOrEqual);
																							CoeVar q = mkCoeVar(bd_lhsh01[ii].index, (coef_t)(bd_lhsh01[ii].value.asDouble() >= 0.0?bd_lhsh01[ii].value.asDouble():-bd_lhsh01[ii].value.asDouble()), bd_lhsh01[ii].value.asDouble() >= 0.0?false:true);
																							in_learnt.push(q);
																						}
																					}
																					//fbA = fastBendersAnalysis(n_infinity, val[val_ix]==0 ? (coef_t)(bd_rhsh00.asDouble()) : (coef_t)(bd_rhsh01.asDouble()), in_learnt, Lpick, out_learnt, out_target_dec_level, out_vcp, false/*learnCombBenCut*/);

																					/*cerr << endl;
																					for (int j = 0; j < in_learnt.size();j++) {
																						if (eas[var(in_learnt[j])] == UNIV) {
																							for (int k = 0; k < saveUs.size();k++)
																								if (saveUs[k] == var(in_learnt[j]))
																									cerr << "U";
																							cerr << (sign(in_learnt[j]) ? "-":"") << "x" << var(in_learnt[j]) << "=(" << (int)assigns[var(in_learnt[j])]<<","<< (isFixed(var(in_learnt[j]))?getFixed(var(in_learnt[j])):2) <<  ") ";
																						}
																					}
																					cerr << endl;
																					if (in_learnt.size() == 0) assert(0);*/
																					bool dCBC = deriveCombBC(in_learnt, pick, cbc);
																					if (dCBC) {
																						hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																						//cerr << "Sq4-" << decisionLevel();
																						for (int i = 0; i < cbc.size();i++) {
																							int real_level = vardata[var(cbc[i])].level;
																							if (vardata[var(cbc[i])].reason != CRef_Undef) real_level--;
																							if (high_1 == -1) {
																								high_1 = real_level;
																							} else {
																								if (real_level > high_1) {
																									high_2 = high_1;
																									high_1 = real_level;
																								} else {
																									if (high_2 == -1 || real_level > high_2) {
																										high_2 = real_level;
																									}
																								}
																							}
																							//cout << (sign(cbc0[i]) ? "-" : "") << cbc0[i].coef << "x" << var(cbc0[i]) << "=" << (int)assigns[var(cbc0[i])]<< "(" << (int)vardata[var(cbc0[i])].level<< ")" << " + ";
																						}



																						for (int zz=0;zz < saveUs.size();zz++) {
																							QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																							QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																							if (!isDirty[saveUs[zz]]) {
																								dirtyLPvars.push(saveUs[zz]);
																								isDirty[saveUs[zz]] = true;
																							}
																						}
																						saveUs.clear();
																						decreaseDecisionLevel();
																						unassign(pick);
																						if (decisionLevel() - high_2 > 10) cerr << "E(" << decisionLevel() << "," << high_2 << ")";
																						if (isOnTrack()) cerr << "lost solution 4" << endl;

																						if (USE_TRACKER & 2) cerr << "Q4";

																						RESOLVE_FIXED(decisionLevel());
																						return _StepResult(STACK,miniprobe_dual_bound,miniprobe_dual_bound);
																					}
																				}
																		}
																	}
																	if (USE_TRACKER) cerr << "B";
																	//out_vcp.v = -1;
																	out_vcp.pos = -1;
																	//out_vcp.cr = -1;
																	out_learnt.clear();
																	in_learnt.clear();
																	if (val[val_ix] == 0) {
																		for (int ii=0; ii < bd_lhsh00.size(); ii++) {
																			CoeVar q = mkCoeVar(bd_lhsh00[ii].index, (coef_t)(bd_lhsh00[ii].value.asDouble() >= 0.0?bd_lhsh00[ii].value.asDouble():-bd_lhsh00[ii].value.asDouble()), bd_lhsh00[ii].value.asDouble() >= 0.0?false:true);
																			in_learnt.push(q);
																		}
																	} else {
																		for (int ii=0; ii < bd_lhsh01.size(); ii++) {
																			CoeVar q = mkCoeVar(bd_lhsh01[ii].index, (coef_t)(bd_lhsh01[ii].value.asDouble() >= 0.0?bd_lhsh01[ii].value.asDouble():-bd_lhsh01[ii].value.asDouble()), bd_lhsh01[ii].value.asDouble() >= 0.0?false:true);
																			in_learnt.push(q);
																		}
																	}
																	if (simplify1(in_learnt, false)) {
																		if (info_level > 0) cout << "simplify leads to tautology in miniprobe" << endl;
																	}

																	if (val[val_ix] == 0) {
																		cbc0.clear();
																		bool dCBC = deriveCombBC(in_learnt, pick, cbc0);
																		if (!dCBC) cbc0.clear();
																		else {
																		}
																	} else {
																		cbc1.clear();
																		bool dCBC = deriveCombBC(in_learnt, pick, cbc1);
																		if (!dCBC) cbc1.clear();
																		else {
																		}
																	}

																	bool learnBendersCut=false;//true;
																	bool learnCombBenCut=true;//false;//false;//true;
																	if (DLD_num < 1000 || density_num < 1000 || computeDLD(in_learnt) <= DLD_sum / DLD_num + DLD_sum / (10*DLD_num)) {
																		if (0&&rand()%10 == 0 && !BendersCutAlarm) learnBendersCut = true;
																		if (1/*rand()%2 == 0*/) learnCombBenCut = true;
																	}
																	if (learnDualCuts==false) {
																		learnBendersCut = learnCombBenCut = false;
																	}

																	learnBendersCut=false;
																	learnCombBenCut=true;

																	if (1) {
																		out_learnt.clear();
																		out_vcp.pos = -1;
																		//cerr << "P5";
																		fbA = fastBendersAnalysis(n_infinity, val[val_ix]==0 ? (coef_t)(bd_rhsh00.asDouble()) : (coef_t)(bd_rhsh01.asDouble()), in_learnt, Lpick, out_learnt, out_target_dec_level, out_vcp, false/*learnCombBenCut*/);
																		//cerr << "Q5";
																	}
																	hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																	for (int zz=0;zz < saveUs.size();zz++) {
																		QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																		QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																		if (!isDirty[saveUs[zz]]) {
																			dirtyLPvars.push(saveUs[zz]);
																			isDirty[saveUs[zz]] = true;
																		}
																	}
																	saveUs.clear();
																	if (learnBendersCut) num_conflicts+=LP_PENALTY;
																	if (learnCombBenCut) num_conflicts++;
																	if (useRestarts && useDeep && num_conflicts > next_check) {
																		if (num_learnts > 0) {
																			break_from_outside = true;
																			for (int l=1;l<decisionLevel();l++) {
																				//cerr << (int)stack_val_ix[l];
																				stack_restart_ready[l] = true;
																				stack_save_val_ix[l] = stack_val_ix[l];
																			}
																		}
																		next_check = next_check + next_level_inc;
																	}
																	//aLC = false;
																	if (max_learnts > constraints.size() && learnBendersCut && learnDualCuts) {
																		if (val[val_ix] == 0) {
																			aLC = addLearnConstraint(in_learnt, /*p_infinity*/(coef_t)bd_rhsh00.asDouble(), 0 /*konfliktvar, not used*/,false);
																		} else {
																			aLC = addLearnConstraint(in_learnt, /*p_infinity*/(coef_t)bd_rhsh01.asDouble(), 0 /*konfliktvar, not used*/,false);
																		}
																		if (aLC) {
																			Constraint &learnt_c =
																					constraintallocator[constraints[constraints.size() - 1]];
																			if (val[val_ix] == 0) {
																				if (LimHorSrch==false) learnt_c.header.rhs = (coef_t)(bd_rhsh00.asDouble()-0.05-abs(bd_rhsh00.asDouble())*0.01);
																			} else {
																				if (LimHorSrch==false) learnt_c.header.rhs = (coef_t)(bd_rhsh01.asDouble()-0.05-abs(bd_rhsh01.asDouble())*0.01);
																			}
		#ifdef TRACE
																			FILE *fpst = fopen("full.trace" ,"a");
																			fprintf(fpst, "--5--\n");
																			fprintf(fpst, "----------------------------\n");
																			for (int i = 0; i < learnt_c.size();i++) {
																				fprintf(fpst,"%s%f%s%d", (sign(learnt_c[i]) ? "-" : ""), learnt_c[i].coef, (eas[var(learnt_c[i])]==UNIV?"D_" : "b_"), var(learnt_c[i]));
																				if (i+1<learnt_c.size()) {
																					if (sign(learnt_c[i+1])) fprintf(fpst," ");
																					else fprintf(fpst," +");
																				} else fprintf(fpst," >= %f", learnt_c.header.rhs);
																			}
																			fprintf(fpst,"\n");
																			fprintf(fpst, "============================\n");
																			fclose(fpst);
																			fpst = fopen("small.trace" ,"a");
																			for (int i = 0; i < learnt_c.size();i++) {
																				fprintf(fpst,"%s%f%s%d", (sign(learnt_c[i]) ? "-" : ""), learnt_c[i].coef, (eas[var(learnt_c[i])]==UNIV?"D_" : "b_"), var(learnt_c[i]));
																				if (i+1<learnt_c.size()) {
																					if (sign(learnt_c[i+1])) fprintf(fpst," ");
																					else fprintf(fpst," +");
																				} else fprintf(fpst," >= %f", learnt_c.header.rhs);
																			}
																			fprintf(fpst,"\n");
																			fclose(fpst);
		#endif

																			//out_vcp.cr = constraints[constraints.size() - 1];
																			//learnt_c.print(learnt_c,assigns,false);
																			//cerr << "---5-----" << endl;

																		}
																	}
																	if (1) {
																		if (0) {
																		} else {

																			out_learnt.clear();
																			out_vcp.pos = -1;
																			if (1) {
																				if (val[val_ix] == 0) pick0eval = n_infinity;
																				else                  pick1eval = n_infinity;
																				if (out_target_dec_level < decisionLevel()-1-SEARCH_LEARN_TRADEOFF) {
																					if (USE_TRACKER) cerr << "$";
																					insertVarOrder(pick);
																					if (!learnCombBenCut) {
																						bool doNotFillImplQ = false;

																						if (vardata[out_vcp.v>>1].reason == CRef_Undef && isRevImpl[vardata[out_vcp.v>>1].level]) {
																							out_target_dec_level = vardata[out_vcp.v>>1].level;
																							doNotFillImplQ = true;
																						} else if(vardata[out_vcp.v>>1].reason != CRef_Undef) {
																							//out_target_dec_level = vardata[out_vcp.v>>1].level-1;
																							doNotFillImplQ = true;
																							//assert(0);
																						} else {
																							assert(out_target_dec_level < decisionLevel());
																							assert(out_target_dec_level < vardata[out_vcp.v>>1].level);
																							assert(vardata[out_vcp.v>>1].level < decisionLevel());
																							for (int zz = out_target_dec_level+1; zz < decisionLevel();zz++) {
																								if (!isRevImpl[zz]) {
																									out_target_dec_level = zz-1;
																								} else
																									if (vardata[out_vcp.v>>1].reason != CRef_Undef && zz == vardata[out_vcp.v>>1].level) {
																										doNotFillImplQ = true;
																										out_target_dec_level = zz;
																										//cerr << "Break 1" << endl;
																										break;

																									}
																							}
																						}
																						if (out_target_dec_level < decisionLevel() - 1) {
																							revImplQ.push(out_vcp);
																						} else {
																							out_vcp.pos = -1;
																							if (revImplQ.size() > 0) revImplQ.pop();
																							out_target_dec_level = decisionLevel();
																							hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																							decreaseDecisionLevel();
																							unassign(pick);
																							if (val[val_ix] == 0) pick0eval = n_infinity;
																							else                  pick1eval = n_infinity;
																							continue;
																						}
																					} else {
																						if (useFULLimpl || propQlimiter[out_vcp.v] <= 0) {
																							PROPQ_PUSH(out_vcp);
																							propQlimiter[out_vcp.v] = propQ.size();
																						} else propQ[propQlimiter[out_vcp.v]-1] = out_vcp;
																						//-- PROPQ_PUSH(out_vcp);
																					}
																					if (USE_TRACKER & 2) cerr << "J15";
																					returnUntil(out_target_dec_level);
																					hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																					for (int zz=0;zz < saveUs.size();zz++) {
																						QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																						QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																						if (!isDirty[saveUs[zz]]) {
																							dirtyLPvars.push(saveUs[zz]);
																							isDirty[saveUs[zz]] = true;
																						}
																					}
																					saveUs.clear();
																					decreaseDecisionLevel();
																					unassign(pick);
																					if (info_level >= 2) cerr << "Q6";
																					if (isOnTrack()) cerr << "lost solution 5" << endl;
																					RESOLVE_FIXED(decisionLevel());
																					if (eas[pick] == EXIST)
																						return _StepResult(STACK,score,score);
																					else
																						return _StepResult(STACK,n_infinity,n_infinity);
																				} else {
																					if (val[val_ix] == 0) pick0eval = n_infinity;
																					else                  pick1eval = n_infinity;
																				}
																			}
																			if (val[val_ix] == 0) pick0eval = n_infinity;
																			else                  pick1eval = n_infinity;
																		}
																	}
																	out_learnt.clear();
																	if (val[val_ix] == 0) pick0eval = n_infinity;
																	else                  pick1eval = n_infinity;
		#endif
																} else {
																	out_learnt.clear();
																	if (val[val_ix] == 0) pick0eval = n_infinity;
																	else                  pick1eval = n_infinity;
																}
															} else if (1) { // if feasible
																bool stability_ok;
																if (QlpStSolve.getExternSolver( maxLPStage ).getSolutionStatus() != extSol::QpExternSolver::OPTIMAL)
																	stability_ok = false;
																else stability_ok = true;
																int cntkk=0;
																int dec_levelh0;
																bool unass_univ_var_exists = false;
																for (int kk=0;kk<solutionh0.size();kk++) {
																	if (eas[kk] == UNIV && assigns[kk] == extbool_Undef) unass_univ_var_exists = true;
																	if (type[kk] != CONTINUOUS && solutionh0[kk].asDouble() > LP_EPS && solutionh0[kk].asDouble() < 1.0-LP_EPS) cntkk++;
																}
																if (cntkk == 0 && !unass_univ_var_exists) {
																	if (-lbh0.asDouble() > miniprobe_score) miniprobe_score = -lbh0.asDouble();
																	if (-lbh0.asDouble() > constraintallocator[constraints[0]].header.rhs) {
																		//score = -lbh0.asDouble();
																		//cerr << "S(" << -lbh0.asDouble() << ")";
																		if (val[val_ix] == 0) pick0eval = -lbh0.asDouble();
																		else pick1eval = -lbh0.asDouble();
																		pick0eval = pick1eval = -lb.asDouble();
																		best_value = -n_infinity;
																		best_pick = pick;
																		best_pol = val[val_ix];
																		jjj = sorter.size()+2;
																		if (val_ix == 0) val_ix=3;
																		ac = false;
																		if (fullEval0) uBnds.setU0(pick0eval, pick);
																		else           uBnds.setU0(-lb.asDouble(), pick);
																		if (fullEval1) uBnds.setU1(pick1eval, pick);
																		else           uBnds.setU1(-lb.asDouble(), pick);
																		//cerr << "\n unusual improved. " << pick << "," << pick0eval << "," << pick1eval << endl;
																		//goto Lemin;
																	} else {
																		if (val[val_ix] == 0) pick0eval = -lbh0.asDouble();
																		else                  pick1eval = -lbh0.asDouble();
																	}
																} else {
																	//if (cntkk == 0 && !unass_univ_var_exists) {
																	//	if (-lbh0.asDouble() > score) score = -lbh0.asDouble();
																	//}
																	if (val[val_ix] == 0) pick0eval = -lbh0.asDouble();
																	else                  pick1eval = -lbh0.asDouble();
																}

#ifndef FIND_BUG_2
																if (val_ix == 1 && cntkk==0 && stability_ok) { // wird hoffentlich nicht mehr gebraucht
																	assert(eas[pick]==EXIST);
																	if (max(pick0eval,pick1eval) < miniprobe_dual_bound /*|| (eas[pick]==UNIV && min(pick0eval,pick1eval) < miniprobe_dual_bound)falsch??*/) {
																		if (eas[pick] == EXIST) miniprobe_dual_bound = max(pick0eval,pick1eval);
																		else miniprobe_dual_bound = min(pick0eval,pick1eval);
																		assert(score==n_infinity);
																		if (miniprobe_score > miniprobe_dual_bound) {
																			if (info_level >= 2) cerr << "Error: miniprobe_score=" << miniprobe_score << ", miniprobe_dual_bound=" << miniprobe_dual_bound << endl;
																		}
																		//assert(miniprobe_score <= miniprobe_dual_bound);
																		assert(eas[pick] == EXIST);
																		assert(eas[Lpick] == EXIST);
																		if (score >= miniprobe_dual_bound || miniprobe_score >= miniprobe_dual_bound || miniprobe_dual_bound <= a) {
																			hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																			for (int zz=0;zz < saveUs.size();zz++) {
																				QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																				QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																				if (!isDirty[saveUs[zz]]) {
																					dirtyLPvars.push(saveUs[zz]);
																					isDirty[saveUs[zz]] = true;
																				}
																			}
																			saveUs.clear();
																			decreaseDecisionLevel();
																			unassign(pick);
#ifndef FIND_BUG_NEW
																			if (miniprobe_dual_bound < score) miniprobe_dual_bound = score;
																			if (miniprobe_dual_bound < miniprobe_score) miniprobe_dual_bound = miniprobe_score;
																			if (miniprobe_dual_bound < global_score) miniprobe_dual_bound = global_score;
																			if (global_score >= miniprobe_dual_bound  && !unass_univ_var_exists && block[Lpick] == 1){
																				for (int z=0; z < nVars();z++) {
																					if (type[z]==BINARY && assigns[z] != extbool_Undef) {
																						assert(isZero(solutionh0[z].asDouble()-(double)assigns[z]));
																					}
																					if (type[z]==BINARY) {
																						if (solutionh0[z].asDouble() > 0.5) fstStSol[z] = 1;
																						else fstStSol[z] = 0;
																					} else {
																						fstStSol[z] = solutionh0[z].asDouble();
																					}
																				}
																				global_score = miniprobe_dual_bound;
																			}
																			if (USE_TRACKER) cerr << "M1 ";
#endif
																			//cerr << " " << pick << ", p0e:" << pick0eval << ", p1e:" << pick1eval << ", mdb:" << miniprobe_dual_bound << ", ms:" << miniprobe_score << " s=" << score << " dl=" << decisionLevel() << "|";
																			if (isOnTrack()) cerr << "lost solution 6" << endl;
																			RESOLVE_FIXED(decisionLevel());
																			return _StepResult(STACK,miniprobe_dual_bound,miniprobe_dual_bound);
																		}
																	}
																}
#endif // FIND_BUG_2
																//assert(a>=constraintallocator[constraints[0]].header.rhs);
																if (useBendersBackJump && -lbh0.asDouble() < a && val_ix == 1 && (val[0] == 0 ? pick0eval < a : pick1eval < a)) {
																	if (USE_TRACKER) cerr << "?";
																	assert(eas[pick] != UNIV);
																	if (feasPhase || eas[pick] == UNIV) {
																		out_learnt.clear();
																		for (int zz=0;zz < saveUs.size();zz++) {
																			QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																			QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																			if (!isDirty[saveUs[zz]]) {
																				dirtyLPvars.push(saveUs[zz]);
																				isDirty[saveUs[zz]] = true;
																			}
																		}
																		saveUs.clear();
																		decreaseDecisionLevel();
																		unassign(pick);
																		if (isOnTrack()) cerr << "lost solution 7" << endl;
																		RESOLVE_FIXED(decisionLevel());
																		return _StepResult(STACK,(coef_t)(-lbh0.asDouble()),(coef_t)(-lbh0.asDouble()));
																	}
																	coef_t olda = a;
																	coef_t oldb = b;
																	coef_t olds = score;
																	double oldlb = lb.asDouble();
																	bool old_oo = only_one;
																	dec_levelh0 = decisionLevel()+1;
																	computeLocalBackjump(min((coef_t)a,(coef_t)global_score),Lpick, b, score, out_vcp, only_one, true, dec_levelh0);
																	if (dec_levelh0 < decisionLevel()-1-SEARCH_LEARN_TRADEOFF) {
																		out_learnt.clear();
																		for (int zz=0;zz < saveUs.size();zz++) {
																			QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																			QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																			if (!isDirty[saveUs[zz]]) {
																				dirtyLPvars.push(saveUs[zz]);
																				isDirty[saveUs[zz]] = true;
																			}
																		}
																		saveUs.clear();
																		if (USE_TRACKER & 2) cerr << "J16";
																		returnUntil(dec_levelh0);
																		//-- PROPQ_PUSH(out_vcp);
																		//TODO HIER : GEHT DAS?? vorher ihne ReturnUntil, nur return
																		hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																		decreaseDecisionLevel();
																		unassign(pick);
																		if (info_level >= 2) cerr << "Lk";
																		if (isOnTrack()) cerr << "lost solution 8" << endl;
																		RESOLVE_FIXED(decisionLevel());
																		return _StepResult(STACK,min((coef_t)a,(coef_t)global_score),min((coef_t)a,(coef_t)global_score));
																	} else {
																		only_one = old_oo;
																		b = oldb;
																		score = olds;
																		a = olda;
																		lb = oldlb;
																		for (int i = dec_levelh0-1; i <= decisionLevel()+1;i++) level_finished[i] = false;
																		while (revImplQ.size() > 0) revImplQ.pop();
																		while (propQ.size() > 0) propQ.pop();
																		only_one = false;
																	}
																}
															} else {
																if (val[val_ix] == 0) pick0eval = -lbh0.asDouble();
																else                  pick1eval = -lbh0.asDouble();
															}
														} else if (1||useEarlyBackjump){
		#ifdef OP_ON_INFI
															if (eas[confl_var] != UNIV) {
																//out_vcp.v = -1;
																out_vcp.pos = -1;
																//out_vcp.cr = -1;
																bool learnClauseOfAnalysis=true;//false;//true;
																if (analyze(confl, confl_var, confl_partner, out_learnt, out_target_dec_level, out_vcp,learnClauseOfAnalysis) && out_vcp.pos != -1
																		&& out_target_dec_level < decisionLevel()-1) {
																	if (USE_TRACKER) cerr << "s";
																	if (learnClauseOfAnalysis) {
																		if (useFULLimpl || propQlimiter[out_vcp.v] <= 0) {
																			PROPQ_PUSH(out_vcp);
																			propQlimiter[out_vcp.v] = propQ.size();
																		} else propQ[propQlimiter[out_vcp.v]-1] = out_vcp;
																	} else {
																		bool doNotFillImplQ=false;
																		if (vardata[out_vcp.v>>1].reason == CRef_Undef && isRevImpl[vardata[out_vcp.v>>1].level]) {
																			out_target_dec_level = vardata[out_vcp.v>>1].level;
																			doNotFillImplQ = true;
																		} else if(vardata[out_vcp.v>>1].reason != CRef_Undef) {
																			//out_target_dec_level = vardata[out_vcp.v>>1].level-1;
																			doNotFillImplQ = true;
																			if (USE_TRACKER) cerr << "K";
																			//assert(0);
																		} else {
																			assert(out_target_dec_level < decisionLevel());
																			assert(out_target_dec_level < vardata[out_vcp.v>>1].level);
																			assert(vardata[out_vcp.v>>1].level < decisionLevel());
																			for (int zz = out_target_dec_level+1; zz < decisionLevel();zz++) {
																				if (!isRevImpl[zz]) {
																					out_target_dec_level = zz-1;
																				} else
																					if (vardata[out_vcp.v>>1].reason != CRef_Undef && zz == vardata[out_vcp.v>>1].level) {
																						doNotFillImplQ = true;
																						out_target_dec_level = zz;
																						//cerr << "Break 1" << endl;
																						break;

																					}
																			}
																		}
																		if (doNotFillImplQ == false) revImplQ.push(out_vcp);
																	}
																	if (USE_TRACKER & 2) cerr << "J17";
																	returnUntil(out_target_dec_level);
																	//-- PROPQ_PUSH(out_vcp);
																	hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																	decreaseDecisionLevel();
																	unassign(pick);
																	insertVarOrder(pick);
																	for (int zz=0;zz < saveUs.size();zz++) {
																		QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																		QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																		if (!isDirty[saveUs[zz]]) {
																			dirtyLPvars.push(saveUs[zz]);
																			isDirty[saveUs[zz]] = true;
																		}
																	}
																	if ((info_level & 4) && decisionLevel()<=2) cerr << "+++++++++ fast lp outbreak 4" << " on level " << decisionLevel() << endl;
																	//cerr << "Lo";
																	saveUs.clear();
																	if (isOnTrack()) cerr << "lost solution 9" << endl;
																	RESOLVE_FIXED(decisionLevel());
																	return _StepResult(STACK,score,score);
																} else {
																	if (val[val_ix] == 0) pick0eval = n_infinity;
																	else pick1eval = n_infinity;
																	hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																	decreaseDecisionLevel();
																	unassign(pick);
																	if (val_ix == 1) {
																		if ((val[0]==0 ? pick0eval : pick1eval) < miniprobe_dual_bound) {
																			miniprobe_dual_bound = (val[0]==0 ? pick0eval : pick1eval);
																			if (score >= miniprobe_dual_bound || miniprobe_score >= miniprobe_dual_bound || miniprobe_dual_bound <= a) {
																				for (int zz=0;zz < saveUs.size();zz++) {
																					QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																					QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																					if (!isDirty[saveUs[zz]]) {
																						dirtyLPvars.push(saveUs[zz]);
																						isDirty[saveUs[zz]] = true;
																					}
																				}
																				saveUs.clear();
																				if (info_level >= 2) cerr << "E3";
																				if (isOnTrack()) cerr << "lost solution 10" << endl;
																				RESOLVE_FIXED(decisionLevel());
																				return _StepResult(STACK,miniprobe_dual_bound,miniprobe_dual_bound);
																			} else continue;
																		}
																	}
																	if (eas[pick] == EXIST) continue;
																	else {
																		for (int zz=0;zz < saveUs.size();zz++) {
																			QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																			QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																			if (!isDirty[saveUs[zz]]) {
																				dirtyLPvars.push(saveUs[zz]);
																				isDirty[saveUs[zz]] = true;
																			}
																		}
																		saveUs.clear();
																		if (info_level >= 2) cerr << "E5";
																		if (isOnTrack()) cerr << "lost solution 11" << endl;
																		RESOLVE_FIXED(decisionLevel());
																		return _StepResult(STACK,n_infinity,n_infinity);
																	}
																}
															} else {
																//out_vcp.v = -1;
																out_vcp.pos = -1;
																//out_vcp.cr = -1;
																if (analyze4All(confl, confl_var, out_learnt, out_target_dec_level, out_vcp) && out_vcp.pos != -1) {
																	if (USE_TRACKER) cerr << "u";
																	if (USE_TRACKER & 2) cerr << "J18";
																	returnUntil(out_target_dec_level);
																	if (useFULLimpl || propQlimiter[out_vcp.v] <= 0) {
																		PROPQ_PUSH(out_vcp);
																		propQlimiter[out_vcp.v] = propQ.size();
																	} else propQ[propQlimiter[out_vcp.v]-1] = out_vcp;
																	//-- PROPQ_PUSH(out_vcp);
																	hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
																	decreaseDecisionLevel();
																	unassign(pick);
#ifndef FIND_BUG
																	insertVarOrder(pick);
#endif
																	for (int zz=0;zz < saveUs.size();zz++) {
																		QlpStSolve.setVariableLB(saveUs[zz],0, type.getData());
																		QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																		if (!isDirty[saveUs[zz]]) {
																			dirtyLPvars.push(saveUs[zz]);
																			isDirty[saveUs[zz]] = true;
																		}
																	}
																	saveUs.clear();
																	if (isOnTrack()) cerr << "lost solution 12" << endl;
																	RESOLVE_FIXED(decisionLevel());
																	return _StepResult(STACK,n_infinity,n_infinity);
																} else {
																	if (val[val_ix] == 0) pick0eval = n_infinity;
																	else pick1eval = n_infinity;
																}
															}
		#endif
														}
														// hier war fr�her die do..while propQ.size>0 schleife zu ende
														hs_PurgeTrail(trail.size()-1,decisionLevel()-1);
														decreaseDecisionLevel();
														unassign(pick);
													}
												}

												//cerr << pick0eval << "/" << pick1eval << "/" << best_pick << endl;
												coef_t loss0,loss1,mue=4.0/1.0;
												double pick_value;
												loss0 = (coef_t)-lb.asDouble() - pick0eval;
												if (loss0 < 0.000001) loss0 = 0.000001;
												loss1 = (coef_t)-lb.asDouble() - pick1eval;
												if (loss1 < 0.000001) loss1 = 0.000001;
												assert(loss0>=0.0 && loss1>= 0.0);
												if (loss0 > loss1)
													pick_value = (1-mue)*loss1 + mue*loss0;
												else
													pick_value = (1-mue)*loss0 + mue*loss1;
												if (LPsortmode) {
													if (loss0 < loss1)
														pick_value = (loss0*loss1);
													else
														pick_value = (loss0*loss1);
													//pick_value = (loss0-loss1)*(loss0-loss1);
												} else
													pick_value = p_activity[pick] + n_activity[pick];
												/*mue = 5.0/6.0;
												if (loss0 > loss1)
														   pick_value = (1-mue)*loss1 + mue*loss0;
												else
														   pick_value = (1-mue)*loss0 + mue*loss1;*/
												//pick_value = irand(random_seed,p_activity[pick] + n_activity[pick]);

												//cout << "$" << (double)enterst/(double)enterb << "," << (double)enterst/(double)nost << "$";

												static double pseudocost_scale = 1.0;
												if (1) {
													if (pick0eval > n_infinity) {
														n_pseudocost[pick] = (0.999*n_pseudocost[pick] + loss0*pseudocost_scale);
														n_pseudocostCnt[pick] ++;
													}
													if (pick1eval > n_infinity) {
														p_pseudocost[pick] = (0.999*p_pseudocost[pick] + loss1*pseudocost_scale);
														p_pseudocostCnt[pick] ++;
													}
													pseudocost_scale = 1.0;
													if ( (pseudocost_scale > 1e20) ) {
														// Rescale:
														if (USE_TRACKER) cerr << "info do pseudocost rescaleing " << n_pseudocost[pick] << " " << p_pseudocost[pick] << endl;
														for (int i = 0; i < nVars(); i++) {
															p_pseudocost[i] *= 1e-20;
															n_pseudocost[i] *= 1e-20;
														}
														pseudocost_scale = 1.0;//*= 1e-100;
													}
												}
												//int pickcsize = max(litInClique[pick+pick+1].size() , litInClique[pick+pick].size());
												//int bpickcsize = max(litInClique[best_pick+best_pick+1].size() , litInClique[best_pick+best_pick].size());
												//if (pickcsize >= bpickcsize)
												if (pick0eval > n_infinity && pick1eval > n_infinity) {
													if (pick0eval > pick1eval) prefDir[pick] = 0;
													else prefDir[pick] = 1;
													inflEstim[pick] = inflEstim[pick] + pick_value;
													infEstimCnt[pick]++;
													if (infEstimCnt[pick] > 40) {
														inflEstim[pick] = inflEstim[pick] / 2.0;
														infEstimCnt[pick] /= 2;
													}
													//if (infEstimCnt[pick] > 10) cerr << infEstimCnt[pick] << " PV=" << pick_value << " Est=" << inflEstim[pick] / infEstimCnt[pick] << endl;
												}
												static double AVGlossSum = 0.0;
												static double AVGlossCnt = 0.0;
												coef_t ggap;
												ggap = abs(100.0*(-global_dual_bound + global_score) / (abs(global_score)+1e-10) );

												if (pick0eval > n_infinity && pick1eval > n_infinity) if (pick_value > best_value ||
														(pick_value == best_value && p_activity[pick]+n_activity[pick] < max_activity) ) {
													lastImp=jjj;
													double AVGloss = AVGlossSum / AVGlossCnt;
													if (pick_value > best_value) {
														best_value = pick_value;
														if (loss1 > loss0) best_pol = 0;
														else best_pol = 1;
														LPHA=true;
														//if (AVGlossCnt > 5 && fmax(loss1,loss0) < 0.1*AVGloss) LPHA=false;
														//if (fmax(loss1,loss0) < 1) LPHA=false;
														//cerr << "X" << loss0 << "," << loss1 << "x";
													} else /*if (max(propLen0,propLen1) > max_propLen)*/ {
														max_activity = p_activity[pick]+n_activity[pick];
														//best_value = pick_value;
														if (loss1 > loss0) best_pol = 0;
														else best_pol = 1;
														if (eas[pick] == UNIV) cerr << "Error: UNIV hat hier nichts zu suchen" << endl;
														//cerr << "X" << loss0 << "," << loss1 << "x";
														LPHA = true;
														//if (AVGlossCnt > 5 && fmax(loss1,loss0) < 0.1*AVGloss) LPHA=false;
														//if (fmax(loss1,loss0) < 1) LPHA=false;
													}

													//cerr << "L" << fabs(loss0-loss1) / fabs(loss0+loss1) << "l";
#ifdef FIND_BUG
													if (1||fabs(loss0-loss1) / fabs(loss0+loss1+1e-20) < 0.1) {
														int cnt0=0;
														int cnt1=0;
														int va = /*best_*/pick;
														for (int i=0; i < VarsInConstraints[va].size();i++) {
															Constraint &c = constraintallocator[VarsInConstraints[va][i].cr];
															int pos = VarsInConstraints[va][i].pos;
															int s = sign(c[pos]);
															if (c.header.learnt) continue;//break;
															if (c.header.isSat) {
																if (c.header.isSat && c.header.btch1.watch1 == -2) continue;
																if (s) { //negativ
																	if (1) cnt0++;
																} else { // positiv
																	if (1) cnt1++;
																}
															} else {
																if (c.saveFeas(assigns)) continue;
																if (s) { //negativ
																	if (c.header.wtch2.worst + c[pos].coef >= c.header.rhs) cnt0++;
																} else { // positiv
																	if (c.header.wtch2.worst + c[pos].coef >= c.header.rhs) cnt1++;
																}
															}
														}

														if (fabs(loss0-loss1) / fabs(loss0+loss1+1e-20) * 30 < fmax(cnt0,cnt1)) {
															double ran = drand(random_seed);
															int evnt = (ran > solution[pick].asDouble()) ? 0 : 1;
															if (cnt1 > cnt0 && cnt0==0 && evnt == 1) {
																best_pol = 1;
																//cerr << " X" ;
															}
															else if (cnt1 < cnt0 && cnt1==0 && evnt == 0) {
																best_pol = 0;
																//cerr << " Y" ;
															}
														}
														/*loss0 = loss0 / (1+cnt0*(solution[pick].asDouble()));
														loss1 = loss1 / (1+cnt1*(1.0-solution[pick].asDouble()));
														if (loss1 > loss0) best_pol = 0;
														else best_pol = 1;*/
													}
#endif

													AVGlossCnt = AVGlossCnt + 1.0;
													AVGlossSum = AVGlossSum + fmax(loss0,loss1);
													//ac=false;
													best_pick = pick;
													if (fullEval0) uBnds.setU0(pick0eval, pick);
													else           uBnds.setU0(-lb.asDouble(), pick);
													if (fullEval1) uBnds.setU1(pick1eval, pick);
													else           uBnds.setU1(-lb.asDouble(), pick);
													//cerr << "\nimproved. " << pick << "," << pick0eval << "," << pick1eval << endl;
													//if (isOnTrack() && max(ubs[0],ubs[1]) < -17) cerr << "GRRRR1" << pick << "," << ubs[0] << ubs[1];

													//latestImprove = jj + lambda;
												}

												if (pick0eval > n_infinity && pick1eval > n_infinity &&
														((pick0eval <= a && pick1eval <= a) || (miniprobe_score >= max(pick0eval,pick1eval)))) {
													LPHA = true;
													//if (eas[pick] == EXIST) miniprobe_dual_bound = max(pick0eval,pick1eval);
													//else miniprobe_dual_bound = min(pick0eval,pick1eval);
													best_value = pick0eval;
													best_pol = 0;
													best_pick = pick;
													if (fullEval0) uBnds.setU0(pick0eval, pick);
													else           uBnds.setU0(-lb.asDouble(), pick);
													if (fullEval1) uBnds.setU1(pick1eval, pick);
													else           uBnds.setU1(-lb.asDouble(), pick);
													//cerr << "\n 1 improved. " << pick << "," << pick0eval << "," << pick1eval << endl;
													//if (isOnTrack() && max(ubs[0],ubs[1]) < -17) cerr << "GRRRRR2" << pick << "," << ubs[0] << ubs[1];

													//miniprobe_score = n_infinity;
													miniprobe_dual_bound = min(max(pick0eval,pick1eval), miniprobe_dual_bound);//-n_infinity;
													break;
												}

												if (pick0eval > n_infinity && pick1eval == n_infinity) {
													LPHA = true;
													if (cbc1.size()>0) {
														double numnegs=0.0;
														for (int iii=0; iii < cbc1.size();iii++) {
															if (sign(cbc1[iii])) numnegs += 1.0;
														}
														bool laLC = addLearnConstraint(cbc1, 1.0-numnegs, 0 /*konfliktvar, not used*/,true);
														if (laLC) {
															found1 = constraints[constraints.size() - 1];
														}
													}

													if (found1 >= 0) setFixed(pick, 0, decisionLevel()-1, found1);
													else setFixed(pick, 0, decisionLevel()-1);
													varBumpActivity(pick, 1, 1);
													addFixed(decisionLevel()-1, pick);
													QlpStSolve.setVariableFixation(pick,0,type.getData());
													if (!isDirty[pick]) {
														dirtyLPvars.push(pick);
														isDirty[pick] = true;
													}
													pick_value = -pick1eval/2;
													if (1||pick_value > best_value) {
														best_value = pick_value;
														best_pol = 0;
														best_pick = pick;
														if (fullEval0) uBnds.setU0(pick0eval, pick);
														else           uBnds.setU0(-lb.asDouble(), pick);
														if (fullEval1) uBnds.setU1(pick1eval, pick);
														else           uBnds.setU1(-lb.asDouble(), pick);
													}
													//cerr << "\n 2 improved. " << pick << "," << pick0eval << "," << pick1eval << endl;

													break;
												}
												if (pick1eval > n_infinity && pick0eval == n_infinity) {
													LPHA = true;
													if (cbc0.size()>0) {
														double numnegs=0.0;
														for (int iii=0; iii < cbc0.size();iii++) {
															if (sign(cbc0[iii])) numnegs += 1.0;
														}
														bool laLC = addLearnConstraint(cbc0, 1.0-numnegs, 0 /*konfliktvar, not used*/,true);
														if (laLC) {
															found0 = constraints[constraints.size() - 1];
														}
													}

													if (found0 >= 0) setFixed(pick, 1, decisionLevel()-1, found0);
													else setFixed(pick, 1, decisionLevel()-1);
													addFixed(decisionLevel()-1, pick);
													varBumpActivity(pick, 1, 0);
													QlpStSolve.setVariableFixation(pick,1,type.getData());
													if (!isDirty[pick]) {
														dirtyLPvars.push(pick);
														isDirty[pick] = true;
													}
													pick_value = -pick0eval/2;
													if (1||pick_value > best_value) {
														best_value = pick_value;
														best_pol = 1;
														best_pick = pick;
														if (fullEval0) uBnds.setU0(pick0eval, pick);
														else           uBnds.setU0(-lb.asDouble(), pick);
														if (fullEval1) uBnds.setU1(pick1eval, pick);
														else           uBnds.setU1(-lb.asDouble(), pick);
													}
													//cerr << "\n 3 improved. " << pick << "," << pick0eval << "," << pick1eval << endl;

													break;
												}

												if (pick0eval == n_infinity && pick1eval == n_infinity && useEarlyBackjump) {
													LPHA = true;
													static ca_vec<CoeVar> cbc0;
													static ca_vec<CoeVar> cbc1;
													int high_0_1=-1, high_0_2=-1, high_1_1=-1, high_1_2=-1;
													int tl;
													in_learnt.clear();
													for (int ii = 0; ii < bd_trailh00.size();ii++) {
														//cerr << "S1ET" << bd_trailh00[ii] << "=" << bd_assih00[ii] << endl;
														assigns[bd_trailh00[ii]] = bd_assih00[ii];
														vardata[bd_trailh00[ii]].reason = bd_reash00[ii];
													}
													for (int ii=0; ii < bd_lhsh00.size(); ii++) {
														assert(bd_signh00 == data::QpRhs::greaterThanOrEqual);
														CoeVar q = mkCoeVar(bd_lhsh00[ii].index, (coef_t)(bd_lhsh00[ii].value.asDouble() >= 0.0?bd_lhsh00[ii].value.asDouble():-bd_lhsh00[ii].value.asDouble()), bd_lhsh00[ii].value.asDouble() >= 0.0?false:true);
														in_learnt.push(q);
													}
													/*static ca_vec<CoeVar> temp;
													temp.clear();
													for (int ii = 0; ii < in_learnt.size();ii++)
														temp.push(in_learnt[ii]);
													bool dCBC0 = deriveCombBC(in_learnt, pick, cbc0);
													cbc0.clear();
													in_learnt.clear();
													for (int ii = 0; ii < temp.size();ii++)
														in_learnt.push(temp[ii]);
													temp.clear();*/
													bool dCBC0 = deriveCombBC(in_learnt, pick, cbc0);
													//cerr << endl << "CBC0";
													for (int i = 0; i < cbc0.size();i++) {
														int real_level = vardata[var(cbc0[i])].level;
														if (vardata[var(cbc0[i])].reason != CRef_Undef) real_level--;
														if (high_0_1 == -1) {
															high_0_1 = real_level;
														} else {
															if (real_level > high_0_1) {
																high_0_2 = high_0_1;
																high_0_1 = real_level;
															} else {
																if (high_0_2 == -1 || real_level > high_0_2) {
																	high_0_2 = real_level;
																}
															}
														}
														//cout << (sign(cbc0[i]) ? "-" : "") << cbc0[i].coef << "x" << var(cbc0[i]) << "=" << (int)assigns[var(cbc0[i])]<< "(" << (int)vardata[var(cbc0[i])].level<< ")" << " + ";
													}
													//cout << "xxxx " << decisionLevel() << endl;
													//if (decisionLevel() - high_0_2 > 2) cerr << "z" << decisionLevel() - high_0_2 << "|" << endl;
													for (int ii = 0; ii < bd_trailh00.size();ii++) {
														assigns[bd_trailh00[ii]] = extbool_Undef;
														vardata[bd_trailh00[ii]].reason = CRef_Undef;
													}
													//cerr << "P1->p2" << endl;

													in_learnt.clear();
													for (int ii = 0; ii < bd_trailh01.size();ii++) {
														//cerr << "S2ET" << bd_trailh01[ii] << "=" << bd_assih01[ii] << endl;
														assigns[bd_trailh01[ii]] = bd_assih01[ii];
														vardata[bd_trailh01[ii]].reason = bd_reash01[ii];
													}
													//cerr << "g1o";
													for (int ii=0; ii < bd_lhsh01.size(); ii++) {
														assert(bd_signh01 == data::QpRhs::greaterThanOrEqual);
														CoeVar q = mkCoeVar(bd_lhsh01[ii].index, (coef_t)(bd_lhsh01[ii].value.asDouble() >= 0.0?bd_lhsh01[ii].value.asDouble():-bd_lhsh01[ii].value.asDouble()), bd_lhsh01[ii].value.asDouble() >= 0.0?false:true);
														in_learnt.push(q);
														//cout << (sign(q) ? "-" : "") << q.coef << "x" << var(q) << "=" << (int)assigns[var(q)]<< "(" << (int)vardata[var(q)].level<< ")" << " + ";

													}
													//cerr << "g2o";
													/*temp.clear();
													for (int ii = 0; ii < in_learnt.size();ii++)
														temp.push(in_learnt[ii]);
													bool dCBC1 = deriveCombBC(in_learnt, pick, cbc1);
													cbc1.clear();
													in_learnt.clear();
													for (int ii = 0; ii < temp.size();ii++)
														in_learnt.push(temp[ii]);
													temp.clear();*/
													bool dCBC1 = deriveCombBC(in_learnt, pick, cbc1);
													//cerr << endl << "CBC1";
													for (int i = 0; i < cbc1.size();i++) {
														int real_level = vardata[var(cbc1[i])].level;
														if (vardata[var(cbc1[i])].reason != CRef_Undef) real_level--;
														if (high_1_1 == -1) {
															high_1_1 = real_level;
														} else {
															if (real_level > high_1_1) {
																high_1_2 = high_1_1;
																high_1_1 = real_level;
															} else {
																if (high_1_2 == -1 || real_level > high_1_2) {
																	high_1_2 = real_level;
																}
															}
														}
														//cout << (sign(cbc1[i]) ? "-" : "") << cbc1[i].coef << "x" << var(cbc1[i]) << "=" << (int)assigns[var(cbc1[i])]<< "(" << (int)vardata[var(cbc1[i])].level<< ")" << " + ";
													}
													//cout << "yyyy " << decisionLevel() << endl;
													//if (decisionLevel() - high_1_2 > 2) cerr << "Z" << decisionLevel() - high_1_2 << "|" << endl;
													//if (decisionLevel() - high_0_2 > 2 && decisionLevel() - high_1_2 > 2) cerr << "z" << decisionLevel() - high_0_2 << "," << decisionLevel() - high_1_2 << "|" << endl;
													//if (decisionLevel() != high_0_1 || decisionLevel() != high_1_1) cerr << "Z" << decisionLevel() << "," << high_0_1 << "," << high_1_1 << "|" << endl;
													if (high_0_1 == high_1_1 && high_0_1 == decisionLevel()) {
														ca_vec<CoeVar> in_;
														assert(pick==trail[trail_lim[high_1_1]-1]);
														for (int ii=0;ii < cbc0.size();ii++) {
															if (var(cbc0[ii]) != trail[trail_lim[high_1_1]-1]) in_.push(cbc0[ii]);
														}
														for (int ii=0;ii < cbc1.size();ii++) {
															if (var(cbc1[ii]) != trail[trail_lim[high_1_1]-1]) in_.push(cbc1[ii]);
														}
														cbc1.clear();
														bool dCBC3 = deriveCombBC(in_, pick, cbc1);
														//cerr << endl << "CBC3";
														high_1_1 = high_1_2 = -1;
														int high_2 = -1;
														int high_2j, high_j;

														for (int i = 0; i < cbc1.size();i++) {
															int real_level = vardata[var(cbc1[i])].level;
															if (vardata[var(cbc1[i])].reason != CRef_Undef) real_level--;
															if (high_1_1 == -1) {
																high_1_1 = real_level;
																high_j = i;
															} else {
																if (real_level > high_1_1) {
																	high_1_2 = high_1_1;
																	high_1_1 = real_level;
																	high_2j = high_j;
																	high_j = i;
																} else {
																	if (high_1_2 == -1 || real_level > high_1_2) {
																		high_1_2 = real_level;
																		high_2j = i;
																	}
																}
															}
															//cout << (sign(cbc1[i]) ? "-" : "") << cbc1[i].coef << "x" << var(cbc1[i]) << "=" << (int)assigns[var(cbc1[i])]<< "(" << (int)vardata[var(cbc1[i])].level<< ")" << " + ";
														}
														//cout << endl;
#ifdef FIND_BUG
														high_2 = high_1_2;
														int pickpos = -1;
														int num_neg=0;
														if(0)for (int j = 0; j < cbc1.size();j++) {
															if (var(cbc1[j]) == pick) {
																pickpos = j;
																assert(assigns[pick]==extbool_Undef);
															} else if (sign(cbc1[j])) num_neg++;
															if (assigns[var(cbc1[j])] != extbool_Undef)
																if (vardata[var(cbc1[j])].level > high_2) {
																	high_2 = vardata[var(cbc1[j])].level;
																	high_2j = j;
																}
														}
														high_2 = high_1_2;
														//cerr << high_2 << " " << decisionLevel() << " " << high_1_1 << endl;
														if (high_2 > -1 && high_2 < decisionLevel()-1 /*&& pickpos > -1*/) {
															for (int zz=0;zz < saveUs.size();zz++) {
																QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
																QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
																if (!isDirty[saveUs[zz]]) {
																	dirtyLPvars.push(saveUs[zz]);
																	isDirty[saveUs[zz]] = true;
																}
															}
															saveUs.clear();
															if (!addLearnConstraint(cbc1, 1.0-num_neg, pick, true)) {
																//assert(0);
															} else if (1){
																//cerr << "7a";
																Constraint &learnt_c =
																		constraintallocator[constraints[constraints.size() - 1]];
																learnt_c.header.rhs = 1.0 - num_neg;
																//learnt_c.print(learnt_c,assigns,false);
																returnUntil(high_1_1+1);
																//cout << "back to " << high_1_1 << endl;
															}

														}
#endif
														if (decisionLevel() - high_1_2 > 3) {
															if (info_level >= 2) cerr << "TOR" << decisionLevel() - high_1_2 << "|";
															tl = vardata[trail[trail_lim[high_1_1]-1]].level;//high_0_1;// - 1;
															assert(assigns[trail[trail_lim[high_1_1]-1]] != extbool_Undef);
															if (eas[trail[trail_lim[high_1_1]-1]] == EXIST) {
																setFixed(trail[trail_lim[high_1_1]-1], 1-assigns[trail[trail_lim[high_1_1]-1]]);
																if (vardata[trail[trail_lim[high_1_1]-1]].reason == CRef_Undef) {
																	//assert(high_1_2 >= 0);
																	if (cbc1.size() > 1) addFixed(vardata[trail[trail_lim[high_1_2]-1]].level, trail[trail_lim[high_1_1]-1]);
																} else {
																	assert(0);
																}
															}
															if (USE_TRACKER & 2) cerr << "J19";
															returnUntil(tl);
														}
													}

													for (int ii = 0; ii < bd_trailh01.size();ii++) {
														assigns[bd_trailh01[ii]] = extbool_Undef;
														vardata[bd_trailh01[ii]].reason = CRef_Undef;
													}
													cbc0.clear();
													cbc1.clear();
													bd_trailh00.clear();
													bd_assih00.clear();
													bd_reash00.clear();
													bd_trailh01.clear();
													bd_assih01.clear();
													bd_reash01.clear();

													if (USE_TRACKER) cerr << "Z";
													insertVarOrder(pick);
													for (int zz=0;zz < saveUs.size();zz++) {
														QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
														QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
														if (!isDirty[saveUs[zz]]) {
															dirtyLPvars.push(saveUs[zz]);
															isDirty[saveUs[zz]] = true;
														}
													}
													saveUs.clear();
													if (isOnTrack()) cerr << "lost solution 13" << endl;
													RESOLVE_FIXED(decisionLevel());
													return _StepResult(STACK,n_infinity,n_infinity);
												}
											}
										}
								} // here ends the for loop over the variables of miniprobe


								if (/*best_value < 1 && best_pick >= 0*/!LPHA) {
									double x_i = solution[best_pick].asDouble();
									if (x_i > 0.8 || x_i < 0.2) {
										if (x_i > 0.5) best_pol = 1;
										else best_pol = 0;
									} else if (0&&p_activity[best_pick] + n_activity[best_pick] > 5) {
										if (p_activity[best_pick] < n_activity[best_pick]) best_pol = 0;
										else best_pol = 1;
									} else {
										if (x_i > 0.5) best_pol = 1;
										else best_pol = 0;
									}
									if(best_pol == 1/*p_activity[pick] < n_activity[pick]*/) {
										val[0] = 1;
										val[1] = 0;
									} else {
										val[0] = 0;
										val[1] = 1;
									}
								}
								//if (best_value < -dont_know / 2) cerr << "Z" << best_value << "z";
								if (USE_TRACKER) cerr << "Q7" << " a=" << a << " b=" << b << " ub=" << local_ub << " dl=" << decisionLevel() << "Q8";
								ac = false;
								if(best_pol == 1/*p_activity[pick] < n_activity[pick]*/) {
									val[0] = 1;
									val[1] = 0;
								} else {
									val[0] = 0;
									val[1] = 1;
								}
								if (block[best_cont_ix]==maxBlock && best_pick == -1) {
									for (int ii=0; ii < solution.size();ii++) {
										if (type[ii] != BINARY) continue;
										if (assigns[ii] == extbool_Undef && eas[ii] == EXIST && getFixed(ii) == extbool_Undef) {
											if (solution[ii] < 0.5) solution[ii] = 0.0;
											else solution[ii] = 1.0;
											QlpStSolve.setVariableFixation(ii,solution[ii].asDouble()<0.5?0.0:1.0,type.getData());
											if (!isDirty[ii]) {
												dirtyLPvars.push(ii);
												isDirty[ii] = true;
											}
										} else {
											solution[ii] = -1.0;
										}
									}
									for (int hh = 0; hh < dirtyLPvars.size();hh++) {
										if (getFixed(dirtyLPvars[hh]) == extbool_Undef && assigns[dirtyLPvars[hh]] == extbool_Undef) {
											if (type[dirtyLPvars[hh]] == BINARY && eas[dirtyLPvars[hh]] == EXIST) {
												QlpStSolve.setVariableLB(dirtyLPvars[hh],0,type.getData());
												QlpStSolve.setVariableUB(dirtyLPvars[hh],1,type.getData());
											}
										} else if (assigns[dirtyLPvars[hh]] != extbool_Undef) {
											if (USE_ASSIGNVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)assigns[dirtyLPvars[hh]],type.getData());
										} else {
											if (USE_EARLYVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)getFixed(dirtyLPvars[hh]),type.getData());
										}

										updateStageSolver(converted_block[pick] >> CONV_BLOCK_RIGHT_SHIFT,dirtyLPvars[hh],dirtyLPvars[hh]);
										isDirty[dirtyLPvars[hh]] = false;
									}
									while (dirtyLPvars.size() > 0) dirtyLPvars.pop();
									solutionh0.clear();
									unsigned int lpt=time(NULL);
									QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, statush0, lbh0, ubh0, solutionh0,algorithm::Algorithm::WORST_CASE,-1,/*-1*/feasPhase?-1:/*3*/3-4 /*simplex iterationen*/);
									LPtim += time(NULL)-lpt;
									LPcnt++;
									if (statush0 == algorithm::Algorithm::IT_LIMIT) {
										if (info_level >= 2) cerr << "B";
										for (int ii=0; ii < solution.size();ii++) {
											if (type[ii] != BINARY) continue;
											if (solution[ii].asDouble() > -0.99) {
												QlpStSolve.setVariableLB(ii,0,type.getData());
												QlpStSolve.setVariableUB(ii,1,type.getData());
												if (!isDirty[ii]) {
													dirtyLPvars.push(ii);
													isDirty[ii] = true;
												}
											}
										}
									} else if (statush0 == algorithm::Algorithm::INFEASIBLE) {
										//cerr << "BG!";
										for (int ii=0; ii < solution.size();ii++) {
											if (type[ii] != BINARY) continue;
											if (solution[ii].asDouble() > -0.99) {
												QlpStSolve.setVariableLB(ii,0,type.getData());
												QlpStSolve.setVariableUB(ii,1,type.getData());
												if (!isDirty[ii]) {
													dirtyLPvars.push(ii);
													isDirty[ii] = true;
												}
											}
										}
									} else /*if (block[trail[trail.size()-1]] falsch == maxBlock)*/if(1) {
										double result = -objOffset;//0.0;
										Constraint &c = constraintallocator[constraints[0]];
										((yInterface*)yIF)->adaptSolution(solutionh0, type.getData(), assigns.getData());
										for (int i = 0; i < c.size();i++) {
											if (assigns[var(c[i])] != extbool_Undef || getFixed(var(c[i])) != extbool_Undef) {
												assert(type[var(c[i])] == BINARY || assigns[var(c[i])] == 0);
												if (assigns[var(c[i])] != extbool_Undef) {
													if (sign(c[i])) result = result - c[i].coef * assigns[var(c[i])];
													else result = result + c[i].coef * assigns[var(c[i])];
												} else {
													if (sign(c[i])) result = result - c[i].coef * getFixed(var(c[i]));
													else result = result + c[i].coef * getFixed(var(c[i]));
												}
											} else {
												if (type[var(c[i])] == BINARY) {
													if (solutionh0[var(c[i])] < 0.0) {
														if (info_level >= 2) cerr << "Error: numerical issue:" << solutionh0[var(c[i])].asDouble() << endl;
														if (solutionh0[var(c[i])].asDouble() >= -LP_EPS) solutionh0[var(c[i])] = 0.0;
													}
													//assert(solutionh0[var(c[i])].asDouble() >= 0.0);
													if (solutionh0[var(c[i])].asDouble() > 0.5) {
														if (sign(c[i])) result = result - c[i].coef * 1.0;
														else result = result + c[i].coef * 1.0;
													}
												} else {
													if (sign(c[i])) result = result - c[i].coef * solutionh0[var(c[i])].asDouble();
													else result = result + c[i].coef * solutionh0[var(c[i])].asDouble();
												}
											}
										}
										for (int ii=0; ii < solution.size();ii++) {
											if (type[ii] != BINARY) continue;
											if (solution[ii].asDouble() > -0.99) {
												QlpStSolve.setVariableLB(ii,0,type.getData());
												QlpStSolve.setVariableUB(ii,1,type.getData());
												if (!isDirty[ii]) {
													dirtyLPvars.push(ii);
													isDirty[ii] = true;
												}
											}
										}
										if (abs(result+lbh0.asDouble()) > 0.0001 * max(abs(lbh0.asDouble()),abs(result))) ;//cerr << "!*" << result << "," << -lbh0.asDouble() << "!!" << endl;
										else {
											int leader=-1;
											if (!checkSolution(a, false, false, -1, Lpick, lbh0.asDouble()/*n_infinity*/, leader, solutionh0)) {
												/*insertVarOrder(pick);
													pick = Lpick = best_cont_ix = leader;
													if (leader > -1) {
														val[0] = 0;
														val[1] = 1;
													}*/
											} else {

												if (info_level >= 5) cerr << endl << "Sonderloesung: +++ " << decisionLevel() << " +++ " << /*lbh0.asDouble()*/result << " " << objOffset << endl;
												PurgeTrail(trail.size()-1,decisionLevel()-1);
												for (int zz=0;zz < saveUs.size();zz++) {
													QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
													QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
													if (!isDirty[saveUs[zz]]) {
														dirtyLPvars.push(saveUs[zz]);
														isDirty[saveUs[zz]] = true;
													}
												}
												saveUs.clear();
												if (isOnTrack()) cerr << "lost solution 114" << endl;
												RESOLVE_FIXED(decisionLevel());
												if (block[pick] == maxBlock) {
													//cerr << "chakah!" << endl;
													crossUs(feasPhase, result, solutionh0.data());
												}
#ifndef FIND_BUG
												insertVarOrder(Lpick);

#endif
#ifndef FIND_BUG_NEW
												if (block[Lpick] == 1){
													for (int z=0; z < nVars();z++) {
														if (type[z]==BINARY && assigns[z] != extbool_Undef) {
															assert(isZero(solutionh0[z].asDouble()-(double)assigns[z]));
														}
														if (type[z]==BINARY) {
															if (solutionh0[z].asDouble() > 0.5) fstStSol[z] = 1;
															else fstStSol[z] = 0;
														}
														if (type[z]!=BINARY) {
															fstStSol[z] = solutionh0[z].asDouble();
														}
													}
													global_score = result;
												}
#endif
												return _StepResult(STACK,/*-lb.asDouble(),-lb.asDouble()*/result,result);///*floor((double)constraintallocator[constraints[0]].header.rhs);*/floor(-lb.asDouble());//n_infinity;
											}
										}
									}
								}
								if (best_pick == -1) {
									//cerr << "best_pick=-1" << endl;
									best_pick = best_cont_ix;
									best_pol = -1;
									uBnds.setU0(-lb.asDouble(), best_pick);
									uBnds.setU1(-lb.asDouble(), best_pick);
									ac = false;
								}
							}

							if (SBcnt > 0.5) SBsigEst = SBcnt * SBsigEst;
							else SBsigEst = 0.0;
						    SBavg = SBavg + (double)lastImp;
						    SBcnt = SBcnt + 1.0;
						    if ((double)lastImp > SBmaxDi) SBmaxDi = (double)lastImp;
						    SBsigEst = SBsigEst + ((SBavg/SBcnt) - (double)lastImp) * ((SBavg/SBcnt) - (double)lastImp);
						    if (SBcnt > 0.5) SBsigEst = SBsigEst / SBcnt;
						    else SBsigEst = 0.0;

							Lemin:;

							//cerr << "b(" << a << "," << constraintallocator[constraints[0]].header.rhs << ")";
							pick = best_pick;
							assert(((yInterface*)yIF)->getIsInSOSvars(pick)==0);
							if (pick == -1) {
								if (!feasPhase && info_level >= 5) cerr << "pick=-1" << endl;
								pick = best_cont_ix;
								if (((yInterface*)yIF)->getIsInSOSvars(pick)) pick = Lpick;
								assert(((yInterface*)yIF)->getIsInSOSvars(pick)==0);
								best_pol = -1;
								uBnds.setU0(-lb.asDouble(), pick);
								uBnds.setU1(-lb.asDouble(), pick);
							}
							//cerr << "bestpick=" << best_pick;

							if (best_pol == -1 && isInObj[best_cont_ix] < nVars()+2) {
								if (eas[best_cont_ix] == EXIST) {
									if (sign(constraintallocator[constraints[0]][isInObj[best_cont_ix]])) {
										val[0] = 0;
										val[1] = 1;
									} else {
										val[0] = 1;
										val[1] = 0;
									}
								} else {
									if (sign(constraintallocator[constraints[0]][isInObj[best_cont_ix]])) {
										val[0] = 1;
										val[1] = 0;
									} else {
										val[0] = 0;
										val[1] = 1;
									}
								}
							}
						}
					} else {  // if -lb.value < rhs
		#ifndef USE_BENDERS_OBJ_CUTS
						HT->setEntry(-lb.asDouble()/*(double)constraintallocator[constraints[0]].header.rhs*/, 0, best_cont_ix , lsd, getEA(best_cont_ix), UB, trail.size(), objective_iterations, dont_know, break_from_outside);
						only_one = true;
						//out_vcp.v = -1;
						out_vcp.pos = -1;
						//out_vcp.cr = -1;

						if (USE_TRACKER) cerr << "z";
						for (int zz=0;zz < saveUs.size();zz++) {
							QlpStSolve.setVariableLB(saveUs[zz],0, type.getData());
							QlpStSolve.setVariableUB(saveUs[zz],1, type.getData());
							if (!isDirty[saveUs[zz]]) {
								dirtyLPvars.push(saveUs[zz]);
								isDirty[saveUs[zz]] = true;
							}
						}
						saveUs.clear();
						if (isOnTrack()) cerr << "lost solution 16" << endl;
						RESOLVE_FIXED(decisionLevel());
#ifndef FIND_BUG
						insertVarOrder(Lpick);
#endif
						return _StepResult(STACK,n_infinity,-lb.asDouble());
					}
		#else
		#endif
				} else { /*cout << "infeas:" << trail.size() << endl;*/
					if (USE_TRACKER) cerr << "-";
					score = n_infinity;
					b = dont_know;
					only_one = true;

					if (useBendersBackJump) {
						//out_vcp.v = -1;
						out_vcp.pos = -1;
						//out_vcp.cr = -1;
						/*cout << "+++++> ";
							for (int l=0;l<trail.size();l++)
								cout << " x" << trail[l] << "=" << (int)assigns[trail[l]];
							cout << "<+++++" << endl;
						 */
						out_learnt.clear();
						in_learnt.clear();

						//int cnt_negs=0;
						for (int ii=0; ii < bd_lhs.size(); ii++) {
							CoeVar q = mkCoeVar(bd_lhs[ii].index, (coef_t)(bd_lhs[ii].value.asDouble() >= 0.0?bd_lhs[ii].value.asDouble():-bd_lhs[ii].value.asDouble()), bd_lhs[ii].value.asDouble() >= 0.0?false:true);
							in_learnt.push(q);
						}
						if (simplify1(in_learnt, false)) {
							if (info_level > 0) cout << "simplify leads to tautology in lp-infeas" << endl;
						}

						bool learnBendersCut = false;
						bool learnCombBenCut = true;//false;
						if (learnDualCuts==false && !useRestarts) {
							learnBendersCut = learnCombBenCut = false;
						}

						if (max_learnts > constraints.size()) {

							if (learnBendersCut && (in_learnt.size()==0 || !addLearnConstraint(in_learnt, (coef_t)bd_rhs.asDouble()/*p_infinity*/, 0 /*konfliktvar, not used*/,false))) {
								//if (!addLearnConstraint(out_learnt, (coef_t)(1-cnt_negs), 0 /*konfliktvar, not used*/,true)) {
								// e.g. if not enough memory
								if (info_level > 0) {
									if (in_learnt.size()>0) ;//cout << "unsinnige Constraint in bd gelernt" << endl;
									else ;//cout << "Warning: empty constraint in Benders" << endl;
								}
								insertVarOrder(pick);
								for (int zz=0;zz < saveUs.size();zz++) {
									QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
									QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
									if (!isDirty[saveUs[zz]]) {
										dirtyLPvars.push(saveUs[zz]);
										isDirty[saveUs[zz]] = true;
									}
								}
								saveUs.clear();
								if (isOnTrack()) cerr << "lost solution 17" << endl;
								RESOLVE_FIXED(decisionLevel());
								return _StepResult(STACK,n_infinity,n_infinity);
							} else {
								if (learnBendersCut) {
									Constraint &learnt_c =
											constraintallocator[constraints[constraints.size() - 1]];
									if (LimHorSrch==false) learnt_c.header.rhs = /*n_infinity;//*/(coef_t)(bd_rhs.asDouble()-0.05-abs(bd_rhs.asDouble())*0.01);
								}
								//if (!validateCut(learnt_c,bd_rhs.asDouble())) assert(0);
								//constraintBumpActivity(learnt_c);
								//learnt_c.print(learnt_c, assigns,false);
								//cout << ">=" << learnt_c.header.rhs << endl
								if (learnBendersCut) num_conflicts+=LP_PENALTY;
								if (learnCombBenCut) num_conflicts++;
								if (useRestarts && useDeep && num_conflicts > next_check) {
									if (num_learnts > 0) {
										break_from_outside = true;
										for (int l=1;l<decisionLevel();l++) {
											//cerr << (int)stack_val_ix[l];
											stack_restart_ready[l] = true;
											stack_save_val_ix[l] = stack_val_ix[l];
										}
									}
									next_check = next_check + next_level_inc;
								}
								out_learnt.clear();
								out_vcp.pos = -1;
								if ((1||!(learnBendersCut && learnCombBenCut)) ? (fastBendersAnalysis(n_infinity, (coef_t)(bd_rhs.asDouble()), in_learnt, Lpick, out_learnt, out_target_dec_level, out_vcp, learnCombBenCut) && out_vcp.pos != -1)
										: (analyzeBendersFeasCut(constraints[constraints.size() - 1], Lpick, out_learnt, out_target_dec_level, out_vcp) && out_vcp.pos != -1)) {
									/*Constraint& learnt_cc = constraintallocator[constraints[constraints.size()-1]];
										if (validateCut(learnt_cc,learnt_cc.header.rhs)) ;
										else {
											cerr << "Error" << endl;
											cerr << "#gesetzte Vars:" << trail.size() << endl;
											learnt_cc.print(learnt_cc,assigns,false);
											cerr << endl << "entstand aus:"  << endl;
											Constraint &ccc = constraintallocator[constraints[constraints.size() - 2]];
											ccc.print(ccc,assigns,false);
											cerr << "{";
											for (int zzz=0; zzz < ccc.size();zzz++) {
												cerr << "(x" << (ccc[zzz].x >> 1) << "=" << (int)assigns[ccc[zzz].x>>1]
													 << "," << vardata[var(ccc[zzz])].level << "," << ((unsigned int)(vardata[var(ccc[zzz])].reason)==4294967295u?-1:((int)vardata[var(ccc[zzz])].reason)) <<
													 "," << optSol[var(ccc[zzz])] << ")" << endl;
											}
											//cerr << " RHS=" << ccc.header.rhs << " RHS1=" << constraintallocator[constraints[constraints.size() - 2]].header.rhs << " bd_rhs=" << bd_rhsh0.asDouble() << " akt:" << pick << " tdl=" <<out_target_dec_level<< "}";
											assert(0);
										}*/

									insertVarOrder(pick);
									if (!learnCombBenCut && !(out_target_dec_level == 0)) {
										bool doNotFillImplQ = false;

										if (vardata[out_vcp.v>>1].reason == CRef_Undef && isRevImpl[vardata[out_vcp.v>>1].level]) {
											out_target_dec_level = vardata[out_vcp.v>>1].level;
											doNotFillImplQ = true;
										} else if(vardata[out_vcp.v>>1].reason != CRef_Undef) {
											//out_target_dec_level = vardata[out_vcp.v>>1].level-1;
											doNotFillImplQ = true;
											//assert(0);
										} else {
											assert(out_target_dec_level < decisionLevel());
											assert(out_target_dec_level < vardata[out_vcp.v>>1].level);
											assert(vardata[out_vcp.v>>1].level < decisionLevel());
											for (int zz = out_target_dec_level+1; zz < decisionLevel();zz++) {
												if (!isRevImpl[zz]) {
													out_target_dec_level = zz-1;
												} else
													if (vardata[out_vcp.v>>1].reason != CRef_Undef && zz == vardata[out_vcp.v>>1].level) {
														doNotFillImplQ = true;
														out_target_dec_level = zz;
														//cerr << "Break 1" << endl;
														break;

													}
											}
										}
										if (out_target_dec_level < decisionLevel() - 2) {
											revImplQ.push(out_vcp);
										} else {
											out_vcp.pos = -1;
											if (revImplQ.size() > 0) revImplQ.pop();
											out_target_dec_level = decisionLevel();
										}
									} else {
										if (USE_TRACKER & 2) cerr << "J22A";
										if (learnBendersCut) {
											if (out_vcp.cr == CRef_Undef && out_vcp.pos != -1) {
												Constraint &c = constraintallocator[constraints[constraints.size() - 1]];
												if(!c.header.isSat && c.header.btch1.best < c.header.rhs) {
													out_vcp.cr = constraints[constraints.size() - 1];
													if (USE_TRACKER & 2) cerr << "BENDERS CORRECTION" << endl;
												}
											}
										}
										if (useFULLimpl || propQlimiter[out_vcp.v] <= 0) {
											PROPQ_PUSH(out_vcp);
											propQlimiter[out_vcp.v] = propQ.size();
										} else propQ[propQlimiter[out_vcp.v]-1] = out_vcp;
										//-- PROPQ_PUSH(out_vcp);
									}
									if (USE_TRACKER & 2) cerr << "J22";
									returnUntil(out_target_dec_level);
									PurgeTrail(trail.size()-1,decisionLevel()-1);
									//if(trail[trail.size()-1] == out_vcp.v / 2)
									//	cerr << "anaBen:" << out_vcp.v / 2 << " " << decisionLevel() << " " << out_target_dec_level << " " << level_finished[decisionLevel()] << endl;
									//constraintallocator[constraints[constraints.size() - 1]].print(constraintallocator[constraints[constraints.size() - 1]],assigns,false);
									if (USE_TRACKER) cerr << decisionLevel()-out_target_dec_level << "'" << decisionLevel() << "," << pick << "'";
									//return _StepResult(STACK,/*n_infinity,n_infinity);*/dont_know,p_infinity);
									for (int zz=0;zz < saveUs.size();zz++) {
										QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
										QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
										if (!isDirty[saveUs[zz]]) {
											dirtyLPvars.push(saveUs[zz]);
											isDirty[saveUs[zz]] = true;
										}
									}
									saveUs.clear();
									if (isOnTrack()) cerr << "lost solution 18" << endl;
									RESOLVE_FIXED(decisionLevel());
									return _StepResult(STACK,n_infinity,n_infinity);
								}
								if (USE_TRACKER) cerr << "'1";
								insertVarOrder(pick);
								for (int zz=0;zz < saveUs.size();zz++) {
									QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
									QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
									if (!isDirty[saveUs[zz]]) {
										dirtyLPvars.push(saveUs[zz]);
										isDirty[saveUs[zz]] = true;
									}
								}
								saveUs.clear();
								PurgeTrail(trail.size()-1,decisionLevel()-1);
								if (isOnTrack()) {

									{
										/*for (int zz=0;zz < nVars();zz++) {
												QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
												QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
												if (!isDirty[saveUs[zz]]) {
													dirtyLPvars.push(saveUs[zz]);
													isDirty[saveUs[zz]] = true;
												}
											}*/
										QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE,-1,-1);
									}

									cerr << "lost solution 19:" << (status == algorithm::Algorithm::FEASIBLE ? "FEAS: ":" not feas: ") << lb.asDouble() << endl;
									cerr << "on level " << decisionLevel() << endl;
									algorithm::Algorithm::QlpSolution sol = ((yInterface*)yIF)->resolveDEP(assigns.getData());

									cout << "DEP Solution: " << sol.getSolutionStatusString() << endl;
									cout << "DEP Objective Value: " << sol.getObjFunctionValue() << endl;
									if (-sol.getObjFunctionValue().asDouble() > a) cout << "DEP Vars: "
											<< data::QpNum::vecToString(sol.getSolutionVector()) << endl;
									std::vector<data::QpNum> solu = sol.getSolutionVector();
									{
										data::Qlp* qlp = BinQlp();
										assert(assigns[pick] == 2);
										assert(isFixed(pick) == false);
										for (int z=0; z < nVars();z++)
											if (assigns[z] != 2) {
												qlp->getVariableVector().at(z)->setLowerBound((double)assigns[z]);
												qlp->getVariableVector().at(z)->setUpperBound((double)assigns[z]);
											} else if (isFixed(z)) {
												qlp->getVariableVector().at(z)->setLowerBound(getFixed(z));
												qlp->getVariableVector().at(z)->setUpperBound(getFixed(z));
												cerr << "fixe: " << z << "," << fixdata[z].level << endl;
											} else {
												qlp->getVariableVector().at(z)->setLowerBound(0.0);
												qlp->getVariableVector().at(z)->setUpperBound(1.0);
											}
										QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE,-1,-1);
										cerr << "lost solution 19B:" << (status == algorithm::Algorithm::FEASIBLE ? "FEAS: ":" not feas: ") << lb.asDouble() << endl;
									}
									{
										RESOLVE_FIXED(decisionLevel());
										data::Qlp* qlp = BinQlp();
										assert(assigns[pick] == 2);
										//assert(isFixed(pick) == false);
										if (isFixed(pick)) cerr << "Warning: pick=" << pick << " is fixed to " << ((int)getFixed(pick)) << endl;
										for (int z=0; z < nVars();z++)
											if (assigns[z] != 2) {
												qlp->getVariableVector().at(z)->setLowerBound((double)assigns[z]);
												qlp->getVariableVector().at(z)->setUpperBound((double)assigns[z]);
											} else if (isFixed(z)) {
												qlp->getVariableVector().at(z)->setLowerBound(0.0);
												qlp->getVariableVector().at(z)->setUpperBound(1.0);
												//cerr << "fixe: " << z << "," << fixdata[z].level
											} else {
												qlp->getVariableVector().at(z)->setLowerBound(0.0);
												qlp->getVariableVector().at(z)->setUpperBound(1.0);
											}
										QLPSTSOLVE_SOLVESTAGE(fmax((double)constraintallocator[constraints[0]].header.rhs,a),maxLPStage, status, lb, ub, solution,algorithm::Algorithm::WORST_CASE,-1,-1);
										cerr << "lost solution 19C:" << (status == algorithm::Algorithm::FEASIBLE ? "FEAS: ":" not feas: ") << lb.asDouble() << endl;
									}
								}
								RESOLVE_FIXED(decisionLevel());
								return _StepResult(STACK,n_infinity,n_infinity);
							}
						}
						out_learnt.clear();
						if (USE_TRACKER) cerr << "F";
						//insertVarOrder(pick);
						/*for (int zz=0;zz < saveUs.size();zz++) {
								QlpStSolve.setVariableLB(saveUs[zz],0);
								QlpStSolve.setVariableUB(saveUs[zz],1);
							}
							saveUs.clear();*/
						//return _StepResult(STACK,n_infinity,n_infinity);
					}
				}
		#endif
				for (int zz=0;zz < saveUs.size();zz++) {
					QlpStSolve.setVariableLB(saveUs[zz],0,type.getData());
					QlpStSolve.setVariableUB(saveUs[zz],1,type.getData());
					if (!isDirty[saveUs[zz]]) {
						dirtyLPvars.push(saveUs[zz]);
						isDirty[saveUs[zz]] = true;
					}
				}
				saveUs.clear();
			}
	    }

		if (useDeep && ac) {
			if (irand(random_seed,p_activity[pick] + n_activity[pick]) > n_activity[pick]) {
				//cout << "links" << endl;
				val[0] = 0; val[1] = 1;
			} else {
				val[0] = 1; val[1] = 0;
				//cout << "rechts " << endl;
			}
			//if (!feasPhase)
			if (/*eas[pick] == UNIV &&*/ killer[pick] >= 0) {
				assert(killer[pick] == 0 || killer[pick] == 1);
				val[0] = killer[pick];
				val[1] = 1-killer[pick];
			}
		}

		if (((yInterface*)yIF)->getIsInSOSvars(pick)) {
			cerr << "Warning: unexpected setting of sos variable." << endl;
			pick = -1;
			goto Lstart;
		}
		if (assigns[pick] != extbool_Undef) {
			cerr << "Warning: unexpected setting of variable." << endl;
			pick = -1;
			goto Lstart;
		}

		if (revImplQexists) {
			insertVarOrder(pick);
			if (assigns[revImplQpick] != extbool_Undef) {
				if (assigns[revImplQpick] != 1-revImplQpol) {
					if (info_level >= 2) cerr << "Warning reverse Implication " << (int)assigns[revImplQpick] << " " << 1-revImplQpol << " " << decisionLevel() - vardata[revImplQpick].level << " " << decisionLevel() << endl;
					if (USE_TRACKER & 2) cerr << "J23";
					returnUntil(vardata[revImplQpick].level);
					PurgeTrail(trail.size()-1,decisionLevel()-1);
					insertVarOrder(pick);
					if (isOnTrack()) cerr << "lost solution 20" << endl;
					RESOLVE_FIXED(decisionLevel());
					return _StepResult(STACK,n_infinity,p_infinity);//n_infinity,n_infinity);
					//TODO this is error correcting code. not good :-(
				}
			} else pick = revImplQpick;
			//cerr << "SET in level " << decisionLevel() << " pick=" << pick << endl;
			//cerr << "isRevImpl:" << isRevImpl[t+1] << endl;
			if (revImplQpol == 0) {
				val[0] = 1; val[1] = 0;
			} else {
				val[0] = 0; val[1] = 1;
			}
			if (isRevImpl[t+1]) val[1] = val[0];
		}

		ismono = 0;
		if (eas[pick]==UNIV && useMonotones) ismono = univIsMono(pick, feasPhase);
		if (eas[pick]==UNIV && useMonotones && ismono<0/*(CW.getCWatcher(pick+pick) == -1 || (feasPhase && CW.getCWatcher(pick+pick) == 0))*/ ) {
			//cerr << "M";
			bool lost=false;
			if (/*isInObj[pick] >= nVars()+2 &&*/ !lost) {
				if (eas[pick] != EXIST)
					val[0] = val[1] = 0;
				else
					val[0] = val[1] = 1;
				//cerr << "P";
			}
			//val[0] = val[1] = 1;
			//cerr << "P";
		} else if (eas[pick]==UNIV && useMonotones && ismono>0 /*(CW.getCWatcher(pick+pick+1) == -1 || (feasPhase && CW.getCWatcher(pick+pick+1) == 0))*/ ) {
			bool lost=false;
			if (/*isInObj[pick] >= nVars()+2 &&*/ !lost) {
				if (eas[pick] != EXIST)
					val[0] = val[1] = 1;
				else
					val[0] = val[1] = 0;
				//cerr << "N";
			}
		}

	}

	remPick=pick;
	left = val[0];
	right = val[1];
	((yInterface*)yIF)->setBranchingDecision(pick, left, right);
    if (remPick != pick) {
    	insertVarOrder(remPick);
    }
	// search actually begins ...
	if (eas[pick] == EXIST) score = n_infinity;
	else                    score = p_infinity;
	best_val = dont_know;
	stack_pick[decisionLevel()] = pick;
    //checkHeap(pick);

Lrestart:;
	if(decisionLevel()==1) {
	   trail_lim[0] = trail.size();
	}
	{
		int level=-1;
		int sigvar=-1;
		int fbct = CM.forcedByConflictTable(pick, nVars(),assigns,level, (CliqueManager::VarData *)vardata.getData(),sigvar);
		if (eas[pick] == EXIST && fbct != extbool_Undef) {
			if (fbct == 4) {
				if (isOnTrack()) cerr << "lost solution xy41" << endl;
				RESOLVE_FIXED(decisionLevel());
				insertVarOrder(pick);
				return _StepResult(STACK,n_infinity,p_infinity);
				//setFixed(sv >> 1, 1-(sv&1), decisionLevel());
				//addFixed(decisionLevel()-2,sv>>1);
			} else if (decisionLevel() <= 1) {
				val[0] = val[1] = fbct;
				setFixed(pick, fbct, 0/*decisionLevel()*/);
				//addFixed(decisionLevel(),pick);
				if (decisionLevel() <= 1) {
				//	cnt_df++;
				}
			} else if (1||block[pick] < maxBlock) {
			    ca_vec<CoeVar> in_learnt;
				std::vector<data::IndexedElement> in_cut4Hash;
				HTCutentry *HTCe;
				pair<coef_t, uint64_t> hash;

				assert(level >= 0 && level <= nVars());
				val[0] = val[1] = fbct;
				if (!feasPhase) {
					setFixed(pick, fbct, /*decisionLevel()*/level);
					addFixed(level/*decisionLevel()*/,pick);
				} else {
					data::IndexedElement e;
					in_learnt.clear();
					//in_cut4Hash.clear();
					assert(assigns[sigvar>>1] == 0 || assigns[sigvar>>1] == 1);
					CoeVar q1 = mkCoeVar(pick, 1.0, fbct ? false : true);
					in_learnt.push(q1);
					//e.index = (q1.x>>1);
					//e.value = -1.0;
					//in_cut4Hash.push_back(e);
					CoeVar q2 = mkCoeVar(sigvar>>1, 1.0, assigns[sigvar>>1] == 0 ? false : true);
					in_learnt.push(q2);
					//e.index = (q2.x>>1);
					//e.value = 1.0;
					//in_cut4Hash.push_back(e);
					//hash = HTC->computeHash(in_cut4Hash, 0.0);

					if (1|| !HTC->getEntry(&HTCe,hash.second, hash.first)) {
						//listOfEnteredCuts.push( QlpStSolve.addUserCut(maxLPStage, in_cut4Hash,
						//		data::QpRhs::greaterThanOrEqual, 0.0) );
						//listOfEnteredCutHashs.push(hash);
						//HTC->setEntry(hash.first, hash.second);
						//addOrgConstraint(in_learnt,0.0-LP_EPS,0);
						bool aLC = addLearnConstraint(in_learnt, 0.0, 0 /*konfliktvar, not used*/,true);
						if (aLC == false) cerr << "Error: could not learn symmetry-breaking constraint." << endl;
						else {
							if (info_level >= 2) cerr << " L ";
							returnUntil(level);
							ValueConstraintPair out_vcp;
							out_vcp.cr = constraints[constraints.size()-1];
							out_vcp.pos = -1;
							out_vcp.v = q1.x;
							PROPQ_PUSH(out_vcp);
							RESOLVE_FIXED(decisionLevel());
							insertVarOrder(pick);
							return _StepResult(STACK,n_infinity,p_infinity);
						}
					}
				}
			}
		}
	}

	if (val[0] == val[1] && getFixed(pick) != extbool_Undef && val[0] != getFixed(pick)) {
		if (USE_TRACKER) cerr << "R2";
		if (isOnTrack()) cerr << "lost solution xy41B" << endl;
		RESOLVE_FIXED(decisionLevel());
		insertVarOrder(pick);
		return _StepResult(STACK,n_infinity,p_infinity);
		assert(0);
	}
    if (getFixed(pick) != extbool_Undef) val[0] = val[1] = getFixed(pick);

    //if (eas[pick]==UNIV) cerr << "ENTER universal node x32 on level "<<decisionLevel()<< endl;

    //uBnds.setU0(-n_infinity,pick);
    //uBnds.setU1(-n_infinity,pick);
    //if (pick == uBnds.getVar(0) && pick == uBnds.getVar(1)) cerr << "G";
    if (!feasPhase && pick != uBnds.getVar(0)) {
    	//cerr << "N->" << pick << "," << uBnds.getVar(0) << "|";
    	uBnds.setU0(-n_infinity,pick);
    }
    if (!feasPhase && pick != uBnds.getVar(1)) {
    	//cerr << "n->" << pick << "," << uBnds.getVar(1) << "|";;
    	uBnds.setU1(-n_infinity,pick);
    }

	for (restart==false ? val_ix = 0 : restart=false ; val_ix <= ((only_one&&getEA(pick)==EXIST)?0:1);val_ix++) {
		if (val_ix == 1 && val[0]==val[1]) continue;
		if (level_finished[t+1] || break_from_outside) {  // t+1 is correct: decision-level
			//cout << "verlasse level " << decisionLevel() << endl;
			if (USE_TRACKER) cerr << "R3";
			insertVarOrder(pick);
			RESOLVE_FIXED(decisionLevel());
			if (isOnTrack()) cerr << "lost solution 21, level tot" << endl;
			if (getEA(pick) == EXIST) {
				return _StepResult(STACK,score,p_infinity);//n_infinity,n_infinity);
			} else {
				if (USE_TRACKER) cerr << "R4";
				return _StepResult(STACK,n_infinity,p_infinity);//n_infinity,n_infinity);
			}
		}
		if (val_ix == 1) {
			if (uBnds.getMax() <= score && getEA(pick) == EXIST) {
				//cerr << "Z(" << score << ">=" << ubs[0] << ","<< ubs[1]<< ","<< isOnTrack() << ")";
				break;
			}
			if (global_dual_bound <= score && getEA(pick) == EXIST) {
				//cerr << "Z2";
				break;
			}
		}
	    //if (eas[pick]==UNIV) cerr << "USE universal node x32 on level "<<decisionLevel() << "with val="<<(int)val[val_ix]<<endl;

	    oob = assign(pick,val[val_ix], trail.size(),CRef_Undef, true);
	    if (eas[pick] == UNIV) killer[pick] = val[val_ix];

	    if (oob != ASSIGN_OK) {
	    	if (getEA(pick)==UNIV) {
	    		insertVarOrder(pick);
	    		num_conflicts_per_level[decisionLevel()]++;
	    		num_conflicts++; //TODO rennt sich sonst manchmal fest
      		    if (useRestarts && useDeep &&  (!isFixed(pick) || fixdata[pick].reason == CRef_Undef) && num_conflicts > next_check) {
                      if (num_learnts > 0) {
                    	  break_from_outside = true;
                    	  for (int l=1;l<decisionLevel();l++) {
                    		  //cerr << (int)stack_val_ix[l];
                    		  stack_restart_ready[l] = true;
                    		  stack_save_val_ix[l] = stack_val_ix[l];
                    	  }
                      }
                      next_check = next_check + next_level_inc;
      		    }

    			RESOLVE_FIXED(decisionLevel());
    			if (isOnTrack()) cerr << "lost solution 122 restart" << endl;
    			if (isFixed(pick) && fixdata[pick].reason != CRef_Undef /*USE_TRACKER*/) {
    				ca_vec<CoeVar> cbc;
    				//if (fixdata[pick].level <= 0) cerr << "W";
    				//if (isFixed(pick)) cerr << decisionLevel()-fixdata[pick].level << "|" << fixdata[pick].reason << "," << oob << ",";
    				Constraint &c = constraintallocator[oob];

    				if (1) {
    					cbc.clear();
    					in_learnt.clear();
    					for (int i = 0; i < c.size();i++) {
    						in_learnt.push(mkCoeVar(var(c[i]),c[i].coef,sign(c[i])));
							//cerr << (sign(c[i]) ? "-" : "") << c[i].coef << "x" << var(c[i]) << "=" << (int)assigns[var(c[i])]<< "(" << (int)vardata[var(c[i])].level<< ")" << " + ";
    					}
    					//cerr << endl;
						bool dCBC = deriveCombBC(in_learnt, pick, cbc);
						//cerr << "B" << dCBC;
						if (dCBC) {
							int high_1 = -1;
							int high_2 = -1;
							PurgeTrail(trail.size()-1,decisionLevel());
							//cerr << "Sq4-" << decisionLevel();
							for (int i = 0; i < cbc.size();i++) {
								int real_level = vardata[var(cbc[i])].level;
								if (vardata[var(cbc[i])].reason != CRef_Undef) real_level--;
								if (high_1 == -1) {
									high_1 = real_level;
								} else {
									if (real_level > high_1) {
										high_2 = high_1;
										high_1 = real_level;
									} else {
										if (high_2 == -1 || real_level > high_2) {
											high_2 = real_level;
										}
									}
								}
								//cerr << (sign(cbc[i]) ? "-" : "") << cbc[i].coef << "x" << var(cbc[i]) << "=" << (int)assigns[var(cbc[i])]<< "(" << (int)vardata[var(cbc[i])].level<< ")" << " + ";
							}
							//cerr << " ### " << high_1 << " " << high_2 << endl;
							//decreaseDecisionLevel();
							//unassign(pick);

							if (1) {
								int tl = decisionLevel();
								if (decisionLevel() - high_1 > 3) {
									//cerr << "TRY" << decisionLevel() - high_1 << "|";
									tl = vardata[trail[trail_lim[high_1]-1]].level;//high_0_1;// - 1;
									assert(assigns[trail[trail_lim[high_1]-1]] != extbool_Undef);
									if (eas[trail[trail_lim[high_1]-1]] == EXIST) {
										setFixed(trail[trail_lim[high_1]-1], 1-assigns[trail[trail_lim[high_1]-1]]);
										if (vardata[trail[trail_lim[high_1]-1]].reason == CRef_Undef) {
											//assert(high_1_2 >= 0);
											if (cbc.size() > 1) addFixed(vardata[trail[trail_lim[high_2]-1]].level, trail[trail_lim[high_1]-1]);
										} else {
											assert(0);
										}
									}
									if (USE_TRACKER & 2) cerr << "J19";
									returnUntil(tl);
								}
								insertVarOrder(pick);
								if (isOnTrack()) cerr << "lost solution xy43" << endl;
								RESOLVE_FIXED(decisionLevel());
								return _StepResult(STACK,a,p_infinity);
							}
						}
    				}
    	    		cerr << "Warning: U infeasible without implication" << endl; // --> passiert nicht.
    			}

      		    RESOLVE_FIXED(decisionLevel());
    			if (isOnTrack()) cerr << "lost solution 22 restart" << endl;
    			if (info_level >= 5) cerr << "V";
	    		return _StepResult(STACK,n_infinity,n_infinity);
	    	} else {
	    		num_conflicts_per_level[decisionLevel()]++;
	    		num_conflicts++; //TODO rennt sich sonst manchmal fest
      		    if (useRestarts && useDeep && (!isFixed(pick) || fixdata[pick].reason == CRef_Undef)&&num_conflicts > next_check) {
                      if (num_learnts > 0) {
                    	  break_from_outside = true;
                    	  for (int l=1;l<decisionLevel();l++) {
                    		  //cerr << (int)stack_val_ix[l];
                    		  stack_restart_ready[l] = true;
                    		  stack_save_val_ix[l] = stack_val_ix[l];
                    	  }
                      }
                      next_check = next_check + next_level_inc;
      		    }

    			RESOLVE_FIXED(decisionLevel());
    			if (isOnTrack()) cerr << "lost solution 122 restart" << endl;
    			if (0 && (!isFixed(pick) || (fixdata[pick].reason == CRef_Undef && getFixed(pick) == val[val_ix]))) {
    				ca_vec<CoeVar> cbc;
    				//if (fixdata[pick].level <= 0) cerr << "W";
    				//if (isFixed(pick)) cerr << decisionLevel()-fixdata[pick].level << "|" << fixdata[pick].reason << "," << oob << ",";
    				Constraint &c = constraintallocator[oob];

    				if (1) {
    					cbc.clear();
    					in_learnt.clear();
    					for (int i = 0; i < c.size();i++) {
    						in_learnt.push(mkCoeVar(var(c[i]),c[i].coef,sign(c[i])));
							//cerr << (sign(c[i]) ? "-" : "") << c[i].coef << "x" << var(c[i]) << "=" << (int)assigns[var(c[i])]<< "(" << (int)vardata[var(c[i])].level<< ")" << " + ";
    					}
    					//cerr << endl;
						bool dCBC = deriveCombBC(in_learnt, pick, cbc);
						//cerr << "B" << dCBC;
						if (dCBC) {
							int high_1 = -1;
							int high_2 = -1;
							int pickpos = -1;
							PurgeTrail(trail.size()-1,decisionLevel());
							//cerr << "Sq4-" << decisionLevel();
							for (int i = 0; i < cbc.size();i++) {
								if (var(cbc[i]) == pick) {
									pickpos = i;
									assert(assigns[pick]==extbool_Undef);
								}
								int real_level = vardata[var(cbc[i])].level;
								if (vardata[var(cbc[i])].reason != CRef_Undef) real_level--;
								if (high_1 == -1) {
									high_1 = real_level;
								} else {
									if (real_level > high_1) {
										high_2 = high_1;
										high_1 = real_level;
									} else {
										if (high_2 == -1 || real_level > high_2) {
											high_2 = real_level;
										}
									}
								}
								//cerr << (sign(cbc[i]) ? "-" : "") << cbc[i].coef << "x" << var(cbc[i]) << "=" << (int)assigns[var(cbc[i])]<< "(" << (int)vardata[var(cbc[i])].level<< ")" << " + ";
							}
							if (high_1 > -1 /*&& high_1 < decisionLevel()-3*/ && pickpos > -1) {
								if (!isFixed(pick) ) {
									out_vcp.cr = oob;
									out_vcp.pos = pickpos;
									out_vcp.v = c[pickpos].x;

									returnUntil(high_1);
									if (propQlimiter[out_vcp.v] <= 0) {
									   PROPQ_PUSH(out_vcp);
									   propQlimiter[out_vcp.v] = propQ.size();
									} else propQ[propQlimiter[out_vcp.v]-1] = out_vcp;
									//-- PROPQ_PUSH(out_vcp);
								} else if (high_1 > -1) {
									returnUntil(fmax(high_1+1,fixdata[pick].level));
								}
								PurgeTrail(trail.size()-1,decisionLevel());
								//decreaseDecisionLevel();
								//unassign(pick);
								insertVarOrder(pick);
								RESOLVE_FIXED(decisionLevel());
								if(0){
									cerr << high_1 << "|" << high_2 << "A++: ";
									Constraint &c = constraintallocator[oob];
									for (int u=0;u<c.size();u++) {
										cerr << (sign(c[u]) ? "-" : "") << c[u].coef <<  (eas[var(c[u])] == EXIST ? "x" : "y") << ((int)var(c[u])) << "(" << (int)assigns[var(c[u])] << "," << (int)type[var(c[u])] <<  "," << vardata[var(c[u])].level << ")" << " + ";
									}
									if (c.header.isSat) cerr << "0 --> " << decisionLevel()  << endl;
									else cerr << "0 >= " << c.header.rhs << " --> "  << decisionLevel() << endl;
									cerr << "getFixed = " << getFixed(out_vcp.v / 2) << " " << fixdata[out_vcp.v / 2].reason  << " " << out_vcp.v / 2 << " " <<  fixdata[out_vcp.v / 2].level << endl;
									if (isFixed(out_vcp.v / 2) && fixdata[out_vcp.v / 2].reason != CRef_Undef) {
										cerr << getFixed(out_vcp.v / 2) << "B+: ";
										Constraint &c = constraintallocator[fixdata[out_vcp.v / 2].reason];
										for (int u=0;u<c.size();u++) {
											cerr << (sign(c[u]) ? "-" : "") << c[u].coef <<  (eas[var(c[u])] == EXIST ? "x" : "y") << ((int)var(c[u])) << "(" << (int)assigns[var(c[u])] << "," << (int)type[var(c[u])] <<  "," << vardata[var(c[u])].level << ")" << " + ";
										}
										if (c.header.isSat) cerr << "0 --> " << decisionLevel()  << endl;

									}

								}
								if (isOnTrack()) cerr << "lost solution 001324" << endl;
								return _StepResult(STACK,a,p_infinity);

							} else if (info_level >= 2) cerr << "Y";



						}
    				}

    			} else if (0 && (!isFixed(pick) || fixdata[pick].reason == CRef_Undef)) {

					Constraint &c = constraintallocator[oob];
                    constraintBumpActivity(c);
                    varBumpActivity(pick, val[val_ix]);
					int high_2 = -1;
					int high_2j;
					int pickpos = -1;
					for (int j = 0; j < c.size();j++) {
						if (var(c[j]) == pick) {
							pickpos = j;
							assert(assigns[pick]==extbool_Undef);
						}
						if (assigns[var(c[j])] != extbool_Undef) {
							int real_level = vardata[var(c[j])].level;
							if (vardata[var(c[j])].reason != CRef_Undef) real_level--;

							if (real_level > high_2) {
								high_2 = real_level;
								high_2j = j;
							}
						}
					}
					if (high_2 > -1 && high_2 < decisionLevel()-3 && pickpos > -1) {
						out_vcp.cr = oob;
						out_vcp.pos = pickpos;
						out_vcp.v = c[pickpos].x;

						returnUntil(high_2);
						if (propQlimiter[out_vcp.v] <= 0) {
						   PROPQ_PUSH(out_vcp);
						   propQlimiter[out_vcp.v] = propQ.size();
						} else propQ[propQlimiter[out_vcp.v]-1] = out_vcp;
						//-- PROPQ_PUSH(out_vcp);
						PurgeTrail(trail.size()-1,decisionLevel());
						//decreaseDecisionLevel();
						//unassign(pick);
						insertVarOrder(pick);
						RESOLVE_FIXED(decisionLevel());
						if(0){
							cerr << high_2 << "A+: ";
							Constraint &c = constraintallocator[oob];
							for (int u=0;u<c.size();u++) {
								cerr << (sign(c[u]) ? "-" : "") << c[u].coef <<  (eas[var(c[u])] == EXIST ? "x" : "y") << ((int)var(c[u])) << "(" << (int)assigns[var(c[u])] << "," << (int)type[var(c[u])] <<  "," << vardata[var(c[u])].level << ")" << " + ";
							}
							if (c.header.isSat) cerr << "0 --> " << decisionLevel()  << endl;
							else cerr << "0 >= " << c.header.rhs << " --> "  << decisionLevel() << endl;
							cerr << "getFixed = " << getFixed(out_vcp.v / 2) << " " << fixdata[out_vcp.v / 2].reason  << " " << out_vcp.v / 2 << " " <<  fixdata[out_vcp.v / 2].level << endl;
							if (isFixed(out_vcp.v / 2) && fixdata[out_vcp.v / 2].reason != CRef_Undef) {
								cerr << getFixed(out_vcp.v / 2) << "B+: ";
								Constraint &c = constraintallocator[fixdata[out_vcp.v / 2].reason];
								for (int u=0;u<c.size();u++) {
									cerr << (sign(c[u]) ? "-" : "") << c[u].coef <<  (eas[var(c[u])] == EXIST ? "x" : "y") << ((int)var(c[u])) << "(" << (int)assigns[var(c[u])] << "," << (int)type[var(c[u])] <<  "," << vardata[var(c[u])].level << ")" << " + ";
								}
								if (c.header.isSat) cerr << "0 --> " << decisionLevel()  << endl;

							}

						}
						if (isOnTrack()) cerr << "lost solution 01324" << endl;
						return _StepResult(STACK,a,p_infinity);

					}



    			} else if (isFixed(pick) && fixdata[pick].reason != CRef_Undef && getFixed(pick) == val[val_ix]/*USE_TRACKER*/) {
    				//assert(getFixed(pick) == 1-val[val_ix]);
    				ca_vec<CoeVar> cbc;
    				//if (fixdata[pick].level <= 0) cerr << "W";
    				//if (isFixed(pick)) cerr << decisionLevel()-fixdata[pick].level << "|" << fixdata[pick].reason << "," << oob << ",";
    				Constraint &c = constraintallocator[oob];

    				if (1) {
    					cbc.clear();
    					in_learnt.clear();
    					for (int i = 0; i < c.size();i++) {
    						in_learnt.push(mkCoeVar(var(c[i]),c[i].coef,sign(c[i])));
							//cerr << (sign(c[i]) ? "-" : "") << c[i].coef << "x" << var(c[i]) << "=" << (int)assigns[var(c[i])]<< "(" << (int)vardata[var(c[i])].level<< ")" << " + ";
    					}
    					//cerr << endl;
						bool dCBC = deriveCombBC(in_learnt, pick, cbc);
						//cerr << "B" << dCBC;
						if (dCBC) {
							int high_1 = -1;
							int high_2 = -1;
							PurgeTrail(trail.size()-1,decisionLevel());
							//cerr << "Sq4-" << decisionLevel();
							for (int i = 0; i < cbc.size();i++) {
								int real_level = vardata[var(cbc[i])].level;
								if (vardata[var(cbc[i])].reason != CRef_Undef) real_level--;
								if (high_1 == -1) {
									high_1 = real_level;
								} else {
									if (real_level > high_1) {
										high_2 = high_1;
										high_1 = real_level;
									} else {
										if (high_2 == -1 || real_level > high_2) {
											high_2 = real_level;
										}
									}
								}
								//cerr << (sign(cbc[i]) ? "-" : "") << cbc[i].coef << "x" << var(cbc[i]) << "=" << (int)assigns[var(cbc[i])]<< "(" << (int)vardata[var(cbc[i])].level<< ")" << " + ";
							}
							//cerr << " ### " << high_1 << " " << high_2 << endl;
							//decreaseDecisionLevel();
							//unassign(pick);

							if (1) {
								int tl = decisionLevel();
								if (decisionLevel() - high_1 > 3) {
									//cerr << "TRY" << decisionLevel() - high_1 << "|";
									tl = vardata[trail[trail_lim[high_1]-1]].level;//high_0_1;// - 1;
									assert(assigns[trail[trail_lim[high_1]-1]] != extbool_Undef);
									if (eas[trail[trail_lim[high_1]-1]] == EXIST) {
										setFixed(trail[trail_lim[high_1]-1], 1-assigns[trail[trail_lim[high_1]-1]]);
										if (vardata[trail[trail_lim[high_1]-1]].reason == CRef_Undef) {
											//assert(high_1_2 >= 0);
											if (cbc.size() > 1) addFixed(vardata[trail[trail_lim[high_2]-1]].level, trail[trail_lim[high_1]-1]);
										} else {
											assert(0);
										}
									}
									if (USE_TRACKER & 2) cerr << "J19";
									returnUntil(tl);
								}
								insertVarOrder(pick);
								if (isOnTrack()) cerr << "lost solution xy41" << endl;
								RESOLVE_FIXED(decisionLevel());
								return _StepResult(STACK,a,p_infinity);
							}
						} //else cerr << "Warning: Derive cut without answer." << endl;
    				}
    			}
	    		//cerr << "Warning: infeasible without implication" << endl; // --> passiert nicht.
	    	    //break_from_outside = true;
	    	}
	    } else {
	    	increaseDecisionLevel(); //starts with decision level 1 in depth 0
	    	do {
                if (level_finished[t+1] || break_from_outside) {
                	if (!level_finished[t+1] && decisionLevel() > 0) {
                		while(propQ.size() > 0) {
                			propQlimiter[propQ[propQ.size()-1].v] = 0;
                			propQ.pop();
                		}
                	}
        			insertVarOrder(pick);
        			PurgeTrail(trail.size()-1,decisionLevel()-1);
        			decreaseDecisionLevel();
        			massert(trail.size() > 0);
        			unassign(pick);
        			RESOLVE_FIXED(decisionLevel());
        			if (isOnTrack()) cerr << "lost solution 23 restart" << endl;
        			if (USE_TRACKER) cerr << "R5 " << break_from_outside << " s=" << score << " ub=" << local_ub << "|";
        			if (getEA(pick) == EXIST) {
        				return _StepResult(STACK,score,local_ub);//n_infinity,n_infinity);
        			} else {
        				if (USE_TRACKER) cerr << "R6";
        		        return _StepResult(STACK,n_infinity,local_ub);//n_infinity,n_infinity);
        			}
                    // fr�her: v = n_infinity; break;
                }
                //int wasone;
                //int reasonno;
                //if (propQ.size()==1) {
                //	wasone = propQ[0].v;
                //    reasonno = propQ[0].cr;
                //} else wasone = -1;
                if (propagate(confl, confl_var, confl_partner, false, false, 1000000)) {
                	   //SearchResult V;
                	   //if (wasone >= 0) {
                		//   if (!feasPhase) {
                		//	   cerr << "Eine Variable in propagate geschoben: x" << wasone / 2 << "=" << (int)assigns[wasone/2] << " " << getFixed(wasone/2) << " " <<  (reasonno==CRef_Undef)  << " " << reasonno<< endl;
                        //   	int vari = wasone / 2;
           				//	if (isFixed(vari) && fixdata[vari].reason == CRef_Undef) {
           				//			cerr << getFixed(vari) << "C+: " << endl;
           							//Constraint &c = constraintallocator[fixdata[vari].reason];
           							//for (int u=0;u<c.size();u++) {
           							//	cerr << (sign(c[u]) ? "-" : "") << c[u].coef <<  (eas[var(c[u])] == EXIST ? "x" : "y") << ((int)var(c[u])) << "(" << (int)assigns[var(c[u])] << "," << (int)type[var(c[u])] <<  "," << vardata[var(c[u])].level << ")" << " + ";
           							//}
           							//if (c.header.isSat) cerr << "0 --> " << decisionLevel()  << endl;

           				//		}

                		//   }
                	   //}
                	   if (eas[pick] == EXIST) {
                		  do {
                              local_ub = uBnds.getNewUb(local_ub);
							  if (decisionLevel() == 2 && local_ub < global_dual_bound)
								  global_dual_bound = local_ub;
          					if ((info_level & 4) && decisionLevel() == 2) cerr << "new gd1?=" << global_dual_bound << " " << uBnds.getU0() << " " << uBnds.getU1() << endl;
          				    if ((info_level & 4) && decisionLevel()<=2) cerr << "+++++++++ enter move " << " on level " << decisionLevel() << ": x" << pick << " block(p)=" << block[pick] << " " << (int)assigns[pick]<< endl;
          				    //cerr << "enter level " << decisionLevel() << endl;
          				    //V = alphabeta(t + 1,lsd-1,fmax(a,score),b,only_one,fatherval, pick, val[val_ix], qex, alwstren, val_ix, sfather_ix+val_ix, LimHorSrch);
        	                  search_stack.setStatus(REK_EXIST);
        	            	  moveDown(decisionLevel(), pick, val[val_ix], val_ix);
         	                  search_stack.down(n_infinity,t + 1,lsd-1,fmax(a,score),b,only_one,fatherval, pick, val[val_ix], qex, alwstren, val_ix, sfather_ix+val_ix, LimHorSrch);
         	                  return REK_EXIST;
         	                  LREK_EXIST:;
            				  //cerr << "leave level " << decisionLevel() << endl;
         	                  V = result;
            	              if (propQ.size() >0 && revImplQ.size() > 0) {
            	            	  //cerr << "PropQ: " << (propQ[0].v >> 1) << " " << 1-(propQ[0].v&1) << " " << vardata[propQ[0].v >> 1].level << endl;
            	            	  //cerr << "ImplQ: " << (revImplQ[0].v >> 1) << " " << 1-(revImplQ[0].v&1) << " " << vardata[revImplQ[0].v >> 1].level << endl;
            	            	  //cerr << revImplQ.size() << " "<< propQ.size() << endl;
            	            	  while (revImplQ.size() > 0) revImplQ.pop();
            	            	  assert(propQ.size() + revImplQ.size() <= 1);
            	              }
            	              if (propQ.size() > 1) {
            	            	  cerr << "Error: propQ.size() > 0 when returning." << endl;
            	            	  while (propQ.size() > 0) propQ.pop();
            	              }
            				  //if (decisionLevel() == 2) cerr << "new gd2?=" << global_dual_bound << " " << uBnds.getU0() << " " << uBnds.getU1() << endl;
            			    	//if (decisionLevel() == 2) cerr << "1 theMax=" << uBnds.getMax() << endl;
	  			              if (val[val_ix] == 0 && V.u_bound < uBnds.getU0()) {
	  			            	  ////ubs[0] = V.u_bound;//
	  			            	  //if (max(score,V.value) > ubs[0]) ubs[0] = max(score,V.value);
	  			              } else if (val[val_ix] == 1 && V.u_bound < uBnds.getU1()) {
	  			            	  ////ubs[1] = V.u_bound;//
	  			            	  //if (max(score,V.value) > ubs[1]) ubs[1] = max(score,V.value);
	  			              }
	  				    	//if (decisionLevel() == 2) cerr << "2 theMax=" << uBnds.getMax() << endl;

		  			          if (V.value>score && V.value > a)  { score=V.value; best_val = val[val_ix];
								if (val_ix == 0) num_firstStrong++;
								else             num_secondStrong++;
		  			            if (score > a && score > dont_know && /*!feasPhase&&*/hasObjective && block[pick] == 1 && score > global_score && alwstren) {
		  			              global_score = score;
		  			              discoveredNews += 500;
                     			  coef_t gap;
                      			  gap = fabs(100.0*(-global_dual_bound + score) / (fabs(score)+1e-10) );
 		  			              if (LimHorSrch == false) {
 		  			            	  if (!objInverted) {
										  cerr << "\n+++++ " << decisionLevel() << " +++++ score: " << -score << " | time: " << time(NULL) - ini_time << " | "
										   << " dual: " << -global_dual_bound << " gap=" << gap << "%";
										if (info_level >= 2)
										   cerr << ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
										cerr << endl;
 		  			            	  } else {
										  cerr << "\n+++++ " << decisionLevel() << " +++++ score: " << score << " | time: " << time(NULL) - ini_time << " | "
										   << " dual: " << global_dual_bound << " gap=" << gap << "%";
										if (info_level >= 2)
										   cerr << ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
										cerr << endl;
 		  			            	  }
 		  			            	if (info_level >= 2) printBounds(10);
 		  			              }
 		  			              if(0)for (int e=0; e < nVars();e++)
 		  			            	  if (eas[e]==UNIV) cerr << "Var x"<<e<< " ist UNIV" << endl;
 		  			              if(0)for (int e=0;e<trail.size();e++)
 		  			        	      cerr << (eas[trail[e]]==UNIV? "*Y":"Y") << trail[e] << " " << vardata[trail[e]].level << " " << vardata[trail[e]].reason << endl;
                                  for (int iii = 0; iii < nVars();iii++) {
                                      if (block[iii] == 1) {
                                              if (assigns[iii] != extbool_Undef) {
                                                      fstStSol[iii] = assigns[iii];
                                              } else fstStSol[iii] = extbool_Undef;
                                              //cerr << fstStSol[iii] << ", ";
                                      } else fstStSol[iii] = block[iii]+10;
                                  }
                                  if (LimHorSrch == false && gap < SOLGAP) break_from_outside = true;
		  			            }
								if ((processNo & 1) == 0 && /*!feasPhase&&*/hasObjective && block[pick] == 1 && score > constraintallocator[constraints[0]].header.rhs && alwstren) {
									Constraint &learnt_c = constraintallocator[constraints[0]];
									if (LimHorSrch==false) learnt_c.header.rhs = score + abs(score)*objective_epsilon; //mehr darf nicht, da Berechnung noch nicht zu Ende ist.
	                                for (int zz = 0; zz <= maxLPStage; zz++) {
	                                    QLPSTSOLVE_TIGHTEN_OBJ_FUNC_BOUND(zz,(double)-learnt_c.header.rhs);
									    //QlpStSolve.changeUserCutRhs((*learnt_c.header.userCutIdentifiers)[zz],(double)learnt_c.header.rhs);
	                                }
	                				if (!feasPhase && decisionLevel()==1 && uBnds.getMax() <= global_dual_bound) {
	                					 global_dual_bound = uBnds.getMax();
	                					 if (decisionLevel() == 2 && info_level >= 2) cerr << "Und:" << uBnds.getU0() << " " << uBnds.getU1() << endl;
	                				}
								}
           					    if (score >= /*global_dual_bound*/local_ub - LP_EPS && propQ.size() == 0 && revImplQ.size() == 0) { if (decisionLevel() == 2 && info_level >= 2) cerr << "E4 " << score << " " << global_dual_bound;
           					        //while (revImplQ.size()>0) revImplQ.pop(); //geht das, wenn level nict finished??
           					        //while (propQ.size()>0) propQ.pop();
           					        break;
           					    } //
							  }
		  			    	//if (decisionLevel() == 2) cerr << " 5 theMax=" << uBnds.getMax() << endl;

	  			             if (level_finished[t+1] && revImplQ.size()>0 && (revImplQ[0].v >> 1) == pick
	  			 	  			            		  && 1-(revImplQ[0].v & 1) != assigns[pick])
	  			            	if (val[0] == val[1] || val_ix == 1) revImplQ.pop();
	  			 	  	     if (level_finished[t+1] || break_from_outside) {
	  			 	  	         //while (revImplQ.size()>0) revImplQ.pop();
	  			 	  	         //while (propQ.size()>0) propQ.pop();
	  			 	  	    	 break;
	  			 	  	     }
                             if (score >= b) {
                            	 // TODO: folgende Zeile sehr! sorgf�ltig testen, bevor Einbau freigegeben.
             					 //if (!forbidHashing) HT->setEntry(score, val[val_ix], pick , v>=p_infinity ? nVars()+10 : lsd, getEA(pick), v >= b ? LB : /*FIT*/LB, trail.size(), v>=p_infinity? max_objective_iterations : objective_iterations, dont_know, break_from_outside);
	  			 	  	         //while (revImplQ.size()>0) revImplQ.pop();
	  			 	  	         //while (propQ.size()>0) propQ.pop();
                            	 break;
                             }
                		  } while (revImplQ.size() > 0);
              	    	//if (decisionLevel() == 2) cerr << " 6 theMax=" << uBnds.getMax() << endl;

	  			          v = V.value;
	  			          if (v>score)  {
	  			            //assert(0);
						  }
	  			          if (score >=b  && propQ.size() == 0) {
 	  			        	  //TODO cerr << "W100: score >= b" << endl;
	  			        	  while(propQ.size() > 0) {
	  			        	  	  propQlimiter[propQ[propQ.size()-1].v] = 0;
	  			        	  	  propQ.pop();
	  			        	  }
	  			        	  break;
	  			          }
	  			    	//if (decisionLevel() == 2) cerr << "7 theMax=" << uBnds.getMax() << endl;

	  			          if (!break_from_outside && propQ.size() == 0) {
							  if (val[val_ix]==0 && V.u_bound < uBnds.getU0()) uBnds.setU0(V.u_bound,pick);
							  if (val[val_ix]==1 && V.u_bound < uBnds.getU1()) uBnds.setU1(V.u_bound,pick);
							  /*if (val[val_ix]==0) {
								  ubs[0] = V.u_bound;
								  //if (score > ubs[0]) ubs[0] = score;
							  } else {
								  ubs[1] = V.u_bound;
								  //if (score > ubs[1]) ubs[1] = score;
							  }*/
							  local_ub = uBnds.getNewUb(local_ub);
							  if (USE_TRACKER)
								  if (decisionLevel() ==2 && info_level >= 2) cerr << "bei nbreak:" << uBnds.getU0() << "," << uBnds.getU0() << " " << local_ub << " a=" << a << " b=" << b << " s=" << score << " dl=" << decisionLevel() << " lf1:" << level_finished[t+1] << " lf2:" << level_finished[t+2] << endl;
							  if (score >= local_ub - LP_EPS) { /*cerr << "E5" ;*/ break; }
	  			          }
	  			    	//if (decisionLevel() == 2) cerr << "8 theMax=" << uBnds.getMax() << endl;

                	   } else { // if universal
                		  do {
            					if (decisionLevel() == 2 && info_level >= 2) cerr << "new gd3?=" << global_dual_bound << " " << uBnds.getU0() << " " << uBnds.getU1() << endl;
 	  			              //V = alphabeta(t + 1,lsd-1,a,fmin(score,b),only_one,fatherval, pick, val[val_ix], qex, alwstren, val_ix, sfather_ix+val_ix, LimHorSrch);
             	                  search_stack.setStatus(REK_UNIV);
            	            	  moveDown(decisionLevel(), pick, val[val_ix], val_ix);
             	                  search_stack.down(n_infinity,t + 1,lsd-1,a,fmin(score,b),only_one,fatherval, pick, val[val_ix], qex, alwstren, val_ix, sfather_ix+val_ix, LimHorSrch);
             	                  return REK_UNIV;
             	                  LREK_UNIV:;
             	                  V = result;
             	         	    //if (eas[pick]==UNIV) cerr << "USE universal node x32 wirh value "<<V.value<<endl;

 	          					if (decisionLevel() == 2 && info_level >= 2) cerr << "new gd4?=" << global_dual_bound << " " << uBnds.getU0() << " " << uBnds.getU1() << endl;
 	          				  if (val[val_ix] == 0 && V.u_bound < uBnds.getU0()) {
	  			            	  //ubs[0] = V.u_bound;//
	  			            	  //if (max(score,V.value) > ubs[0]) ubs[0] = max(score,V.value);
	  			              } else if (val[val_ix] == 1 && V.u_bound < uBnds.getU1()) {
	  			            	  //ubs[1] = V.u_bound;//
	  			            	  //if (max(score,V.value) > ubs[1]) ubs[1] = max(score,V.value);
	  			              }
 	  			              //if (val[val_ix] == 0 && V.u_bound < ubs[0]) ubs[0] = V.u_bound;    //
	  			              //else if (val[val_ix] == 1 && V.u_bound < ubs[1]) ubs[1] = V.u_bound;//
 	  			              if (level_finished[t+1] && revImplQ.size()>0 && (revImplQ[0].v >> 1) == pick
 	  			            		  && 1-(revImplQ[0].v & 1) != assigns[pick])
 	  			            	  if (val[0] == val[1] || val_ix == 1) revImplQ.pop();
 	  			   		      if (level_finished[t+1] || break_from_outside) break;
         					  //if (V.value <= global_score) { /*cerr << "E5";*/ break; }
         					  //if (V.value <= a) { cerr << "E6"; break; }
                		  } while (revImplQ.size() > 0);
 	  			          v = V.value;
 	  			          if (v < score && v < b && propQ.size() == 0) { score = v; best_val = val[val_ix]; }
     					  //if (score <= global_score  && !break_from_outside) { cerr << "E7"; break; }
     					  //if (score <= a  && !break_from_outside) { cerr << "E8"; break; }
     					  if (score <= a && !break_from_outside) {
 	  			        	  // TODO cerr << "W101: score < a" << endl;
	  			        	  while(propQ.size() > 0) {
	  			        		  propQlimiter[propQ[propQ.size()-1].v] = 0;
	  			        		  propQ.pop();
	  			        	  }
 	  			        	  break;
 	  			          }
	  			          if (!break_from_outside) {
							  if (val[val_ix]==0 && V.u_bound < uBnds.getU0()) uBnds.setU0(V.u_bound, pick);
							  if (val[val_ix]==1 && V.u_bound < uBnds.getU1()) uBnds.setU1(V.u_bound, pick);
							  coef_t m = uBnds.getU0();
							  if (uBnds.getU1() < m) m = uBnds.getU1();
							  if (m < local_ub) local_ub = m;
	  			          }
                	   }
	    		} else {
	    			massert(confl_var >= 0);
	    			num_conflicts_per_level[decisionLevel()]++;
	    			if (eas[confl_var] != UNIV) {
	    				//out_vcp.v = -1;
	    				out_vcp.pos = -1;
	    				//out_vcp.cr = -1;
	    				//cerr << "TL=" << out_target_dec_level;
	   				    if (analyze(confl, confl_var, confl_partner, out_learnt, out_target_dec_level, out_vcp) && out_vcp.pos != -1) {
	   				    	if (eas[pick] == UNIV) {
	   				    		for (int k = 0;k < scenario.size();k++)
	   				    			killer[scenario[k]] = assigns[scenario[k]];
	   				    	}
	   				    	//cerr << "TL=" << out_target_dec_level;
	   				    	if (USE_TRACKER & 2) cerr << "J24";
	   				    	returnUntil(out_target_dec_level);
	                        if (useFULLimpl || propQlimiter[out_vcp.v] <= 0) {
	        				   PROPQ_PUSH(out_vcp);
	        				   propQlimiter[out_vcp.v] = propQ.size();
	                        } else propQ[propQlimiter[out_vcp.v]-1] = out_vcp;
	   				    	//-- PROPQ_PUSH(out_vcp);
	   				    	PurgeTrail(trail.size()-1,decisionLevel()-1);
	   				    	decreaseDecisionLevel();
	   				    	unassign(pick);
	   				    	insertVarOrder(pick);
	   				    	//cerr << ".";
	   				    	//in feas fall: n_inf ist richtig. Back to decision xyz
	   				    	//in opt case: was ist, wenn zwar feas. erreicht werden kann,
	   				    	//aber nicht mehr der opt-Wert?
	   						RESOLVE_FIXED(decisionLevel());
	   						if (isOnTrack()) cerr << "lost solution 24" << endl;
	   				    	if (eas[pick] == EXIST) {
		   				    	// TODO if (!forbidHashing) HT->setEntry(/*score*/n_infinity, val[val_ix], pick , nVars()+10, /*eas[pick]*/EXIST, FIT,trail.size(), max_objective_iterations, dont_know, break_from_outside);
	   				    	    return _StepResult(STACK,/*n_infinity,n_infinity);*//*dont_know*/score,score);
	   				    	} else {
		   				    	if (!forbidHashing) HT->setEntry(n_infinity, val[val_ix], pick , nVars()+10, /*eas[pick]*/EXIST, FIT,trail.size(), max_objective_iterations, dont_know, break_from_outside);
	   				    		return _StepResult(STACK,n_infinity,n_infinity);
	   				    	}
	   				    } else {
	   				    	if (USE_TRACKER & 2) cerr << "J24b";
	   				    	v = n_infinity;
	   				    }
	    			} else {
	    				//out_vcp.v = -1;
	    				out_vcp.pos = -1;
	    				//out_vcp.cr = -1;
	   				    if (analyze4All(confl, confl_var, out_learnt, out_target_dec_level, out_vcp) && out_vcp.pos != -1) {
	   		    			num_conflicts_per_level[decisionLevel()]++;
	   				    	if (USE_TRACKER) cerr << ":";
	   				    	if (eas[pick] == UNIV) {
	   				    		for (int k = 0;k < scenario.size();k++)
	   				    			killer[scenario[k]] = assigns[scenario[k]];
	   				    	}
	   				    	if (USE_TRACKER & 2) cerr << "J25";
	   				    	returnUntil(out_target_dec_level);
	                        if (useFULLimpl || propQlimiter[out_vcp.v] <= 0) {
	        				   PROPQ_PUSH(out_vcp);
	        				   propQlimiter[out_vcp.v] = propQ.size();
	                        } else propQ[propQlimiter[out_vcp.v]-1] = out_vcp;
	   				    	//-- PROPQ_PUSH(out_vcp);
	   				    	PurgeTrail(trail.size()-1,decisionLevel()-1);
	   				    	decreaseDecisionLevel();
	   				    	unassign(pick);
	   				    	insertVarOrder(pick);
	   				    	// HIER GGFS JANS QLP
	   				    	//
	   						RESOLVE_FIXED(decisionLevel());
	   						if (isOnTrack()) cerr << "lost solution 25" << endl;
	   				    	if (eas[pick] == EXIST) {
		   				       // TODO if (!forbidHashing) HT->setEntry(n_infinity /*score*/, val[val_ix], pick , nVars()+10, /*eas[pick]*/UNIV, FIT,trail.size(), max_objective_iterations, dont_know, break_from_outside);
	   				    	   return _StepResult(STACK,/*n_infinity,n_infinity);*//*dont_know*/score,score);
	   				    	} else {
		   				    	if (!forbidHashing) HT->setEntry(n_infinity, val[val_ix], pick , nVars()+10, /*eas[pick]*/UNIV, FIT,trail.size(), max_objective_iterations, dont_know, break_from_outside);
	   				    		return _StepResult(STACK,n_infinity,n_infinity);
	   				    	    //return _StepResult(STACK,n_infinity,n_infinity);
	   				    	}
	   				    } else {
	   				    	if (USE_TRACKER & 2) cerr << "J25B";
	    				    v = n_infinity;
	   				    }
	    			}
	    		}
                if (0&&propQ.size() > 0 && eas[propQ[0].v >> 1] == UNIV) {  //careful!! do not delete 0&&
                	if (USE_TRACKER) {
                	   cerr << "Warning! universal variable reverse implied, cr=" << propQ[0].cr << ", ";
                	   if (assigns[propQ[0].v >> 1] == 1-(propQ[0].v & 1)) cerr << "richtig rum" << endl;
                	   else cerr << "falsch rum " << (int)assigns[propQ[0].v >> 1] << endl;
                	}
                	assert(propQ.size() == 1);
                	propQlimiter[propQ[propQ.size()-1].v] = 0;
                	propQ.pop();
                	v = n_infinity;
                	break;
	    	    }
#ifdef INSPECT_PROPQ
                if (propQ.size() > 0 && assigns[propQ[0].v >> 1] != extbool_Undef) {
                	assert(level_finished[decisionLevel()-1] == 1);
                	if (level_finished[decisionLevel()-2] != 1) {
                		for (int tt = trail.size()-2; tt > 0 && vardata[trail[tt]].level == decisionLevel()-1;tt--) {
                		   ValueConstraintPair out_vcp(vardata[trail[tt]].reason,assigns[trail[tt]] == 1 ? 2*trail[tt] : 2*trail[tt]+1,-1);
                		   cerr << "-- add " << trail[tt] << "reason in level " << vardata[trail[tt]].level << endl;
	                        if (useFULLimpl ||propQlimiter[out_vcp.v] <= 0) {
	        				   PROPQ_PUSH(out_vcp);
	        				   propQlimiter[out_vcp.v] = propQ.size();
	                        } else propQ[propQlimiter[c[l].x]-1] = ValueConstraintPair(VarsInConstraints[va][i].cr,c[l].x,l));
                		   //PROPQ_PUSH(out_vcp);
                		}
                	}
                	cerr << "\n -- propQ-warning:" << (propQ[0].v >> 1) << " " << pick << " " << level_finished[decisionLevel()-1] << " " << level_finished[decisionLevel()-2] << " " << decisionLevel() << endl;
                }
                if (propQ.size() > 0 && assigns[propQ[0].v >> 1] == extbool_Undef) {
                	//assert(propQ.size() == 1);
                	for (int tt = 0; tt < propQ.size();tt++) {
             		    cerr << "++ inspect " << (propQ[tt].v >> 1) << "reason in level " << vardata[propQ[tt].v >> 1].level << endl;
                		if (tt==0) assert(assigns[propQ[tt].v >> 1] == extbool_Undef);
                		else assert(assigns[propQ[tt].v >> 1] != extbool_Undef);
                	}
                	//assert dass alle Member of propQ gesetzt sind, ausser propQ[0]
                 	cerr << "\n ++ propQ-warning:" << (propQ[0].v >> 1) << " " << pick << " " << level_finished[decisionLevel()-1] << " " << level_finished[decisionLevel()-2] << " " << decisionLevel() << endl;
                }
#endif
                if (propQ.size()==1 && propQ[0].cr == CRef_Undef) {
                	//analyzeTrailCut(true, propQ[0]) ;
                	if (info_level > 0) cout << "ANALYZE CR-WARNING!" << endl;
                	num_conflicts++;
          		    if (useRestarts && useDeep &&num_conflicts > next_check) {
                          if (num_learnts > 0) {
                        	  break_from_outside = true;
                          }
                          next_check = next_check + next_level_inc;
          		    }
                } else if (propQ.size()==1) {
                	int v = propQ[0].v >> 1;
                	int s = propQ[0].v & 1;
                }
                if (useRestarts && num_conflicts > next_check) {
                	num_conflicts++;
                    next_check = next_check + next_level_inc;
                    break_from_outside = true;
                	if (info_level > 0 && (info_level & 4)) cout << "PROPQ-LOOP-WARNING!" << endl;
                }
	    	} while(propQ.size() > 0);
			PurgeTrail(trail.size()-1,decisionLevel()-1);
			decreaseDecisionLevel();
			massert(trail.size() > 0);
			unassign(pick);
			RESOLVE_FIXED_NOCUTS(decisionLevel());

            if (!feasPhase && eas[pick] == EXIST && type[pick] == BINARY && !break_from_outside && decisionLevel() == 1) {
            	if (val_ix == 0 /*&& val[0] != val[1]*/) {
            		setFixed(pick,val[1],0);
            		discoveredNews = 0;
            	}
            }

			if (getEA(pick) == EXIST) {
				if (v > score) {
					score = v;
					best_val = val[val_ix];
					if (val_ix == 0) num_firstStrong++;
					else             num_secondStrong++;
				}
				if (score >= b && useAlphabeta) {
					if (!feasPhase && USE_TRACKER) cerr << "T";
					if (!forbidHashing) HT->setEntry(score, val[val_ix], pick , v>=p_infinity ? nVars()+10 : lsd, getEA(pick), v >= b ? LB : /*FIT*/LB, trail.size(), v>=p_infinity? max_objective_iterations : objective_iterations, dont_know, break_from_outside);
					varBumpActivity(pick, val[val_ix]);
					insertVarOrder(pick);
					if (isOnTrack()) cerr << "lost solution 26 cut off s=" << score << " b=" << b << endl;
				    RESOLVE_FIXED(decisionLevel());
					return _StepResult(STACK,score, local_ub);
				} else if (score >= /*global_dual_bound*/ local_ub - LP_EPS) {
					if (USE_TRACKER & 2) if (!feasPhase) cerr << "Y";
					insertVarOrder(pick);
					if (isOnTrack()) cerr << "lost solution 27 cut off 2" << endl;
				    RESOLVE_FIXED(decisionLevel());
					return _StepResult(STACK,/*local_ub, local_ub*/score,score);
				}
				if ((info_level & 4) && (processNo & 1) == 0 && decisionLevel()==1) cerr << "\n>>>>>>>> score: " << global_score << " | LB: " << global_dual_bound << endl;
				if ((processNo & 1) == 0 && !break_from_outside && !feasPhase && decisionLevel()==1 && uBnds.getMax() < global_dual_bound) {
					global_dual_bound = uBnds.getMax();
					if (info_level > 5) cerr << "new gd=" << global_dual_bound << " " << uBnds.getU0() << " " << uBnds.getU1() << endl;
				}

			} else {
				if (v < score) {
					score = v;
					best_val = val[val_ix];
				}
				if (score <= a && useAlphabeta) {
					killer[pick] = val[val_ix];
					if (!forbidHashing) HT->setEntry(score, val[val_ix], pick , v<=n_infinity ? nVars()+10 : lsd, getEA(pick), v <= a ? UB : /*FIT*/UB, trail.size(), v>=p_infinity? max_objective_iterations : objective_iterations, dont_know, break_from_outside);
					varBumpActivity(pick, val[val_ix]);
					insertVarOrder(pick);
					//increaseDecisionLevel();
					/*for (int ii = trail.size() - 1; ii >= 0; ii--) {
                        cerr << "  x" << trail[ii] << "=" << (int)assigns[trail[ii]] << "(" << (vardata[trail[ii]].reason != CRef_Undef ? vardata[trail[ii]].reason : -1) << "," << vardata[trail[ii]].level << ")";
					}
					cerr << endl;*/
					if (useDeep && !break_from_outside) {
						/*for (int ii = trail.size() - 1; ii >= 0; ii--) {
	                        cerr << "  x" << trail[ii] << "=" << (int)assigns[trail[ii]] << "(" << (vardata[trail[ii]].reason != CRef_Undef ? vardata[trail[ii]].reason : -1) << "," << vardata[trail[ii]].level << ")";
						}
						cerr << endl;*/
						num_conflicts += LP_PENALTY;
	          		    if (useRestarts && useDeep && num_conflicts > next_check) {
	          		    	  if (num_learnts > 0) {
	          		    		  break_from_outside = true;
	          		    		  for (int l=1;l<decisionLevel();l++) {
	          		    			 //cerr << (int)stack_val_ix[l];
	          		    			 stack_restart_ready[l] = true;
		                    		 stack_save_val_ix[l] = stack_val_ix[l];
	          		    		}
	          		    	  }
	                          next_check = next_check + next_level_inc;
	          		    }
					}
                    //constraintallocator[constraints[constraints.size()-1]].print(constraintallocator[constraints[constraints.size()-1]],assigns,false);
					//decreaseDecisionLevel();
					if (isOnTrack()) cerr << "lost solution cutoff all" << endl;
				    RESOLVE_FIXED(decisionLevel());
					if (useUniversalBackjump && getEA(pick) == UNIV && BackJumpInfo[decisionLevel()].bj_level[val[1-val_ix]] >= 0
							                                        && BackJumpInfo[decisionLevel()].bj_level[val[val_ix]] >= 0) {
						//cerr << "can jump, universal IVa:" << v << " " << BackJumpInfo[decisionLevel()].bj_value[val[1-val_ix]] <<
						//		" " << decisionLevel() << " -> " << BackJumpInfo[decisionLevel()].bj_level[val[val_ix]] << " "
						//		                                 << BackJumpInfo[decisionLevel()].bj_level[val[1-val_ix]] << ": valix=" << (int)val_ix << endl;
						if (BackJumpInfo[decisionLevel()].bj_level[val[1-val_ix]] > BackJumpInfo[decisionLevel()].bj_level[val[val_ix]]) {
							int target_dec_level = BackJumpInfo[decisionLevel()].bj_level[val[1-val_ix]];
							int retUnt = decisionLevel();
							for (retUnt = decisionLevel()-1; retUnt >= 0; retUnt--) {
								if (retUnt <= target_dec_level) {
									break;
								}
								int retPick = trail[trail_lim[retUnt]-1];
								if (retUnt>0 && eas[trail[trail_lim[retUnt]-1]] == UNIV) {
									int8_t *s_val;
									s_val = &stack_val[retUnt<<1];
									int8_t &vx = stack_val_ix[retUnt];
									//returnUntil(retUnt);
									BackJumpInfo[retUnt].AddInfo(BackJumpInfo[decisionLevel()].bj_sivar[val[1-val_ix]], vx, s_val[vx], target_dec_level,
											retUnt, decisionLevel(), eas[retPick], BackJumpInfo[decisionLevel()].bj_value[val[1-val_ix]],
											BackJumpInfo[decisionLevel()].bj_reason[val[1-val_ix]]);
									break;
								}
							}
							//if (vardata[BackJumpInfo[decisionLevel()].bj_sivar[val[1-val_ix]]].level > retUnt || eas[trail[trail_lim[retUnt]-1]] == EXIST) {
								if (getFixed(BackJumpInfo[decisionLevel()].bj_sivar[val[1-val_ix]]>>1) == extbool_Undef) {
									if (BackJumpInfo[decisionLevel()].bj_reason[val[1-val_ix]] != CRef_Undef)
										setFixed(BackJumpInfo[decisionLevel()].bj_sivar[val[1-val_ix]]>>1, 1-(BackJumpInfo[decisionLevel()].bj_sivar[val[1-val_ix]] & 1));
									else cerr << "Warning: Backjump without reason!" << endl;
									if (retUnt>0) addFixed(retUnt, BackJumpInfo[decisionLevel()].bj_sivar[val[1-val_ix]]>>1);
								} else if (info_level >= 2) cerr << "R0";
							//}
						} else {
							int target_dec_level = BackJumpInfo[decisionLevel()].bj_level[val[val_ix]];
							int retUnt = decisionLevel();
							for (retUnt = decisionLevel()-1; retUnt >= 0; retUnt--) {
								if (retUnt <= target_dec_level) {
									break;
								}
								int retPick = trail[trail_lim[retUnt]-1];
								if (retUnt>0 && eas[trail[trail_lim[retUnt]-1]] == UNIV) {
									int8_t *s_val;
									s_val = &stack_val[retUnt<<1];
									int8_t &vx = stack_val_ix[retUnt];
									BackJumpInfo[retUnt].AddInfo(BackJumpInfo[decisionLevel()].bj_sivar[val[val_ix]], vx, s_val[vx], target_dec_level,
											retUnt, decisionLevel(), eas[retPick], BackJumpInfo[decisionLevel()].bj_value[val[val_ix]],
											BackJumpInfo[decisionLevel()].bj_reason[val[val_ix]]);
									break;
								}
							}
							//if (vardata[BackJumpInfo[decisionLevel()].bj_sivar[val[val_ix]]].level > retUnt || eas[trail[trail_lim[retUnt]-1]] == EXIST) {
								if (getFixed(BackJumpInfo[decisionLevel()].bj_sivar[val[val_ix]]>>1) == extbool_Undef) {
									if (BackJumpInfo[decisionLevel()].bj_reason[val[val_ix]] != CRef_Undef)
										setFixed(BackJumpInfo[decisionLevel()].bj_sivar[val[val_ix]]>>1, 1-(BackJumpInfo[decisionLevel()].bj_sivar[val[val_ix]] & 1));
									else cerr << "Backjump without reason!!" << endl;
									if (retUnt>0) addFixed(retUnt, BackJumpInfo[decisionLevel()].bj_sivar[val[val_ix]]>>1);
								} else if (info_level >= 2) cerr << "R1";
							//}
						}
					}
					return _StepResult(STACK,score,a);
				}
			}
	    }
	}
    //checkHeap(pick);

    //if (eas[pick]==UNIV) cerr << "SUCCESSFULLXY leave  universal node x32 on level "<<decisionLevel()<< endl;


	if ((info_level & 4) && (((!feasPhase) && USE_TRACKON > 0) || decisionLevel()<=2)) cerr << "+++++++++ leave alphabeta reg with var  xy" << pick << " on level " << decisionLevel() << " " << propQ.size() << " " << revImplQ.size() << endl;

	if ((processNo & 1) == 0 && !useRestarts && decisionLevel()==1 && score < b && score > a && !break_from_outside && !level_finished[1] && score < global_dual_bound)
		global_dual_bound = score;

	if (wot && !isOnTrack()) {
		cerr << "kept solution, should be found: "  << decisionLevel() << " " << score << "," << local_ub << endl;
		for (int h=trail_lim[1]; h < trail.size();h++) {
			cerr << "x"<<trail[h]<< "=" << ((int)assigns[trail[h]]) << " ";
		}
		cerr << endl;
		assert(0);
	}
	if (eas[pick] == UNIV) killer[pick] = best_val;
	insertVarOrder(pick);
	if (!forbidHashing && (a < score && score < b)) HT->setEntry(score, best_val, pick , lsd, getEA(pick), FIT, trail.size(), objective_iterations, dont_know, break_from_outside);
	if (getEA(pick) == UNIV &&
			((BackJumpInfo[decisionLevel()].bj_level[val[0]] >= 0 && BackJumpInfo[decisionLevel()].bj_level[val[0]] < decisionLevel()-2 ) ||
			 (BackJumpInfo[decisionLevel()].bj_level[val[1]] >= 0 && BackJumpInfo[decisionLevel()].bj_level[val[1]] < decisionLevel()-2 ) )) {
		if (info_level >= 2) cerr << "can jump, universal V:" << v << " " << BackJumpInfo[decisionLevel()].bj_value[val[1-val_ix]] <<
				" " << decisionLevel() << " -> " << BackJumpInfo[decisionLevel()].bj_level[val[val_ix]] << " "
				                                 << BackJumpInfo[decisionLevel()].bj_level[val[1-val_ix]] << endl;
	}
    RESOLVE_FIXED(decisionLevel());
	return _StepResult(STACK,score,local_ub);
}
#endif

int QBPSolver::nextDepth(int d) {
	if (d < 2) return 2;
	if (d < 5) return 5;
	if (d <= 5) return 10;
    if (d <= 10) return 15;
    if (d <= 15) return 19;
    return d+1;
}

coef_t QBPSolver::search(int t, void *ifc) {
	    coef_t v;
	    recvBuf = (trailInfo*)malloc(sizeof(trailInfo)*nVars() + 100);
	    assert(recvBuf != 0);
		if (processNo % 2 == 1) info_level = 0;
		if (processNo % 2 == 0) v = searchPrimal(t, ifc);
		else v = searchDual(t, ifc);
		free(recvBuf);
		return v;
}

coef_t QBPSolver::searchDual(int t, void *ifc) {
    CommPrint C;
    yIF = ifc;
	int iteration=1;
	std::vector<std::pair<int,double> > cpropQ;
	time_t starttime = time(NULL);
    Constraint &objective = constraintallocator[constraints[0]];
    global_score = n_infinity;
    global_dual_bound= -n_infinity;
    p_infinity = -n_infinity;
    bool comp_finished = false;
    objOffset = 0.0;
	int cnt_cpQ;
	int cnt_runs = 0;
	int old_ts=0;
	CRef confl=CRef_Undef;
	CRef confl_partner=CRef_Undef;
	int confl_var=-1;
    MPI_Status status;

	for (int i=0;i < nVars();i++) {
		level_finished[i] = 0;
		p_activity[i] = 0;
		n_activity[i] = 0;
		initFixed(i);
		seen[i] = 0;
	}
	for (int j=0; j < nVars();j++) {
		isInObj[j] = nVars()+10;
	}
	for (int j = 0; j < constraints.size(); j++)
		constraintallocator[constraints[j]].mark(0);

	int old_lpls = QlpStSolve.getExternSolver(maxLPStage).getRowCount();
    cpropQ.clear();

	do {
		int size, ti_size;
		coef_t result;
		int flag = 0;
		//recv
		do {
		   MPI_Iprobe(processNo-1,MPI_ANY_TAG,MPI_COMM_WORLD,&flag,&status);
		   std::this_thread::sleep_for(std::chrono::milliseconds(100));
		} while (!flag);
		C.mefprint(processNo,"get Message with TAG %d\n",status.MPI_TAG);
		switch (status.MPI_TAG) {
	        case FINISH:
	    		MPI_Recv(recvBuf, 1, MPI_CHAR, processNo-1,status.MPI_TAG,MPI_COMM_WORLD,&status);
	    		return n_infinity;
	        case START_TRAIL:
				MPI_Get_count(&status,MPI_CHAR,&size);
				MPI_Recv(recvBuf, size, MPI_CHAR, processNo-1,status.MPI_TAG,MPI_COMM_WORLD,&status);
				ti_size = size / sizeof(trailInfo);
		    	for (int i = 0; i < ti_size;i++) {
		    		//C.mefprint(processNo,"T:%d V:%d | ",recvBuf[i].var,recvBuf[i].value);
		    		if (assigns[recvBuf[i].var] == extbool_Undef) {
		    			vardata[recvBuf[i].var].level = 0;
						int oob;
						if (type[recvBuf[i].var] == BINARY)
							oob = assign(recvBuf[i].var,recvBuf[i].value > 0.5 ? 1 : 0, trail.size(),CRef_Undef, true);
						else
							oob = real_assign(recvBuf[i].var, recvBuf[i].value, trail.size(),CRef_Undef);
						assert(oob == ASSIGN_OK);
		    		}
		    	}
		    	//C.mefprint(processNo,"\n");
		    	break;
		    case UPD_CONSTRAINTS:
	    		MPI_Recv(recvBuf, 1, MPI_CHAR, processNo-1,status.MPI_TAG,MPI_COMM_WORLD,&status);
				do {
					cnt_runs++;
					int probe_pick=-1;
					int favour_pol = 0;
					//cerr << "initial probing";
					old_ts = trail.size();
					bool probe_output = probe(probe_pick, favour_pol, false);
					  // TODO : darf die Zeile 'if ...' rein?? bringt es was?? //
					  //if (probe_output == false) return _SearchResult(n_infinity,n_infinity);
					if (cnt_runs > 3 && !(trail.size() > old_ts + (nVars()-old_ts)/10)) {
						break;
					}
					if (probe_pick != -1) varBumpActivity(probe_pick, favour_pol);
				    cnt_cpQ = 0;
					cpropQ.clear();
					if (old_lpls > QlpStSolve.getExternSolver(maxLPStage).getRowCount())
						old_lpls = QlpStSolve.getExternSolver(maxLPStage).getRowCount();
					((yInterface*)yIF)->updateConstraints(((yInterface*)yIF)->qlp , this->QlpStSolve, assigns.getData(), -constraintallocator[constraints[0]].header.rhs, type.getData(), maxLPStage, cpropQ, lowerBounds.getData(), upperBounds.getData(),feasPhase, constraintList, block.getData(),eas.getData());
					QlpStSolve.getExternSolver(maxLPStage).saveSnapshot();
					makeAsnapshot(constraintList);
					addSymmetryConstraint(constraintList,cpropQ);
#ifdef FIND_BUG
					QlpStSolve.getExternSolver(maxLPStage).retrieveSnapshot();
					((yInterface*)yIF)->findComponents(((yInterface*)yIF)->qlp, assigns.getData(), components.getData(), varsOfComponents);
#endif
					if (cpropQ.size() > 0) {
						for (int uuu=0; !comp_finished && uuu < cpropQ.size(); uuu++) {
							bool isMonotone = false;
							if (cpropQ[uuu].first < 0) {
								cpropQ[uuu].first = -cpropQ[uuu].first - 1;
								isMonotone = true;
							}
							if (isMonotone && eas[cpropQ[uuu].first] == UNIV) continue;
							if (assigns[cpropQ[uuu].first] == extbool_Undef && eas[cpropQ[uuu].first] != UNIV) {
								// TODO Pruefen ob cpropQ[uuu].first wirklich manchmal UNIV und wegen Monotonie gesetzt.
								// TODO falls ja, kann UNIVERSAL auf anderen Wert fixiert werden !?
								int oob;
								if (type[cpropQ[uuu].first] == BINARY)
									oob = assign(cpropQ[uuu].first,cpropQ[uuu].second > 0.5 ? 1 : 0, trail.size(),CRef_Undef, true);
								else
									oob = real_assign(cpropQ[uuu].first, cpropQ[uuu].second, trail.size(),CRef_Undef);

								if (oob != ASSIGN_OK) {
									//cerr << "contradicting input" << endl;
									//return n_infinity;
									global_dual_bound = n_infinity;
								} else {
									//cerr << "Variable x" << cpropQ[uuu].first << " is input-fixed to " << cpropQ[uuu].second << endl;
									//if (USE_TRACKON) assert(isOnTrack());
								}

								if (oob != ASSIGN_OK || eas[cpropQ[uuu].first] == UNIV) {
									//cerr << "3a:INFEASIBLE!" << endl;
									//PurgeTrail(trail.size()-1,decisionLevel()-1);
									//return n_infinity;
									global_dual_bound = n_infinity;
								}
								if (!propagate(confl, confl_var, confl_partner,false,false,1000000)) {
									//cerr << "3a:INFEASIBLE 2!" << endl;
									//PurgeTrail(trail.size()-1,decisionLevel()-1);
									//return n_infinity;
									global_dual_bound = n_infinity;
								}
								cnt_cpQ++;
								vardata[cpropQ[uuu].first].level = 0;
								vardata[cpropQ[uuu].first].reason = CRef_Undef;
								settime[cpropQ[uuu].first] = 0;
								//cerr << "have fixed x" <<  cpropQ[uuu].first << " mit cF_index=" << cpropQ[uuu].second << endl;
							}
						}
					}
					//cerr << "Begin: cpropQ.size = " << cnt_cpQ << " and lpls: " << old_lpls << " ; " << QlpStSolve.getExternSolver(maxLPStage).getRowCount() << endl;
				} while (cnt_cpQ>0 || old_lpls > QlpStSolve.getExternSolver(maxLPStage).getRowCount() || trail.size() > old_ts + (nVars()-old_ts)/10);
				cpropQ.clear();
		    	break;
		    case UPD_TRAIL_SOLVE:
		    	global_dual_bound = -n_infinity;
		    	coef_t alpha,beta;
		    	int remainD;
				double rem_gs = global_score;
				coef_t rhs = constraintallocator[constraints[0]].header.rhs;
				int trailsi = trail.size();
		    	int rem_trail_size = trail.size();
				MPI_Get_count(&status,MPI_CHAR,&size);
				MPI_Recv(recvBuf, size, MPI_CHAR, processNo-1,status.MPI_TAG,MPI_COMM_WORLD,&status);
				MPI_Recv(&alpha, sizeof(coef_t), MPI_CHAR, processNo-1,status.MPI_TAG,MPI_COMM_WORLD,&status);
				MPI_Recv(&beta, sizeof(coef_t), MPI_CHAR, processNo-1,status.MPI_TAG,MPI_COMM_WORLD,&status);
				MPI_Recv(&remainD, sizeof(int), MPI_CHAR, processNo-1,status.MPI_TAG,MPI_COMM_WORLD,&status);
				ti_size = size / sizeof(trailInfo);
				increaseDecisionLevel();
				if (info_level > 0) cerr << "RECIEVE PS(" << ti_size << "), " << trail.size() << ":";
		    	for (int i = ti_size-1; i >= 0;i--) {
		    		if (info_level > 0) cerr << "V:" << recvBuf[i].var<<"="<<recvBuf[i].value<< ", ";
		    		//C.mefprint(processNo,"T:%d V:%d | ",recvBuf[i].var,recvBuf[i].value);

		    		if (assigns[recvBuf[i].var] == extbool_Undef) {
						int oob;
						assert(type[recvBuf[i].var] == BINARY);
						if (type[recvBuf[i].var] == BINARY)
							oob = assign(recvBuf[i].var,recvBuf[i].value > 0.5 ? 1 : 0, trail.size(),CRef_Undef, true);
						else
							oob = real_assign(recvBuf[i].var, recvBuf[i].value, trail.size(),CRef_Undef);
						assert(oob == ASSIGN_OK);
		    		}
		    	}
		    	if (info_level > 0) cerr << endl;
		    	if (info_level > 0) for (int fg=0;fg<trail.size();fg++) cerr << "#" << trail[fg] << "(" << vardata[trail[fg]].level << "), ";
		    	if (propQ.size() > 0) C.mefprint(processNo, "CpropQ not empty!!\n");
		    	propQ.clear();
		    	//C.mefprint(processNo,"\n");
		    	int lmax_sd  = remainD;
		    	coef_t start_a = alpha;
		    	coef_t start_b = beta;
		    	cerr << "START HELPER SEARCH [" << alpha << "," << beta << "] with D=" << remainD << endl;
		    	break_from_outside = false;
		    	feasPhase = false;
		    	useRestarts = false;
		    	useDeep = false;
				if (info_level & 2) cout << "Start with maximum depth " << lmax_sd << " use Restarts: " << useRestarts << " Alpha=" << start_a << " Beta=" << start_b << endl;
				it_starttime = time(NULL);
				//for (int hh = 0; hh < n_activity.size(); hh++) n_activity[hh] /= (num_learnts-old_num_learnts+1);//10000;
				//for (int hh = 0; hh < p_activity.size(); hh++) p_activity[hh] /= (num_learnts-old_num_learnts+1);//10000;
				//old_num_learnts = num_learnts;
				max_sd = nVars()+10;
				lp_decider_depth = max_sd;
				num_decs = 100;
				num_props = 1000;
				decreaseDecisionLevel();
#ifdef FIND_BUG
		    	SearchResult V = alphabeta_loop(t,lmax_sd ,start_a, start_b,false,p_infinity,-1,0, true, true,0,0,false);
#else
		    	SearchResult V;
#endif
		    	if (break_from_outside) V.value = V.u_bound;
		    	cerr << "FINISHED HELPER SEARCH with result " << V.value << endl;
		    	if (break_from_outside) {
		    		cerr << "ERROR: BFO in HelperSearch" << endl;
		    		assert(0);
		    	}
		    	while (rem_trail_size < trail.size()) {
		    		unassign(trail[trail.size()-1],false,false);
		    	}
				for (int i=0;i < nVars();i++) {
					setFixed(i, extbool_Undef);
				}
				if (trail.size() != rem_trail_size) cerr << "ts=" << trail.size() << " und rts=" << rem_trail_size << endl;
				assert(trail.size() == rem_trail_size);
				MPI_Send(&V, sizeof(SearchResult), MPI_CHAR, processNo-1,BOUGHT_BOUND,MPI_COMM_WORLD);
				global_score = rem_gs;
				constraintallocator[constraints[0]].header.rhs = rhs;
				reduceDB(true);
				assert(trail.size() == rem_trail_size);
		    	break;
		}
	} while (!comp_finished);
	PurgeTrail(trail.size()-1,decisionLevel()-1);
	return best_objective;
}

coef_t QBPSolver::buyDualBound(int trail_start, coef_t a, coef_t b, int theMaxIx) {
	SearchResult V;
	MPI_Status status;
	//theMaxIx--;
	int remainD = fmax(1,sqrt((double)((decisionLevel()-theMaxIx)*3/4)));
	if (info_level & 2) cerr << "BUY: theMAxIx=" << theMaxIx << endl;
	stack_container *s = &search_stack.stack[theMaxIx];
	coef_t &score = stack_score[theMaxIx+1];
	int8_t *val;
	val = &stack_val[(theMaxIx+1)<<1];
	int8_t &val_ix = stack_val_ix[theMaxIx+1];

	assert(val_ix == 0);
	if (val[val_ix] == 0) {
		if (remainD <= s->uBnds.getDepth(1) && !s->uBnds.getSuc(1)) return -n_infinity;
		else if (remainD > s->uBnds.getDepth(1)) ;
		else if (remainD <= s->uBnds.getDepth(1) && s->uBnds.getSuc(1)) {
			remainD = s->uBnds.getDepth(1)*12/10 ;//+ max(1,(decisionLevel()-s->uBnds.getDepth(1)-theMaxIx)/2);
			if (theMaxIx + remainD > decisionLevel()) return -n_infinity;
		}
		s->uBnds.setDepth(1, remainD);
	} else {
		if (remainD <= s->uBnds.getDepth(0) && !s->uBnds.getSuc(0)) return -n_infinity;
		else if (remainD > s->uBnds.getDepth(0)) ;
		else if (remainD <= s->uBnds.getDepth(0) && s->uBnds.getSuc(0)) {
			remainD = s->uBnds.getDepth(0)*12/10;// + max(1,(decisionLevel()-s->uBnds.getDepth(0)-theMaxIx)/2);
			if (theMaxIx + remainD > decisionLevel()) return -n_infinity;
		}
		s->uBnds.setDepth(0, remainD);
	}
	//cerr << "theMax=" << b << " U0/U1:" << s->uBnds.getU0() << "/" << s->uBnds.getU1() << " val[val_ix]=" << (int)val[val_ix]<< endl;
	//cerr << "theMax-1=" << b << " U0/U1:" << (s-1)->uBnds.getU0() << "/" << (s-1)->uBnds.getU1() << " val[val_ix]=" << (int)val[val_ix]<< endl;
	//cerr << "theMax+1=" << b << " U0/U1:" << (s+1)->uBnds.getU0() << "/" << (s+1)->uBnds.getU1() << " val[val_ix]=" << (int)val[val_ix]<< endl;
    if (val[val_ix] == 0) assert(b == s->uBnds.getU1());
    else assert(b == s->uBnds.getU0());
	if (info_level & 2) cerr << "buy params " << trail_start << " Pick="<<s->pick<<endl;
	int j = 0;
	assert(s->pick > -1);
	assert(val[0] != val[1]);
	recvBuf[j].var = s->pick;
	if (val[val_ix] == 0) recvBuf[j].value = 1;
	else                  recvBuf[j].value = 0;
    j++;
	for (int i = trail_start; i > 0 && vardata[trail[i]].level > 0;i--,j++) {
		recvBuf[j].var = trail[i];
		recvBuf[j].value = assigns[trail[i]];
	}
	if (info_level & 2) for (int fg=0;fg<j;fg++) cerr << "@" << recvBuf[fg].var << "(" << vardata[recvBuf[fg].var].level << "), ";
	MPI_Send(recvBuf, j*sizeof(trailInfo), MPI_CHAR, processNo+1,UPD_TRAIL_SOLVE,MPI_COMM_WORLD);
	MPI_Send(&a, sizeof(coef_t), MPI_CHAR, processNo+1,UPD_TRAIL_SOLVE,MPI_COMM_WORLD);
	MPI_Send(&b, sizeof(coef_t), MPI_CHAR, processNo+1,UPD_TRAIL_SOLVE,MPI_COMM_WORLD);
	MPI_Send(&remainD, sizeof(int), MPI_CHAR, processNo+1,UPD_TRAIL_SOLVE,MPI_COMM_WORLD);
	MPI_Recv(&V, sizeof(SearchResult), MPI_CHAR, processNo+1,BOUGHT_BOUND,MPI_COMM_WORLD,&status);
	cerr << "RECEIVE BOUGHT RESULT [" << V.value << "," << V.u_bound << "]" << " <-> " << b << " in Level "<< theMaxIx << "/" << decisionLevel() << endl;
	coef_t mbnds = V.u_bound;//V.value;
	//if (V.u_bound < mbnds) mbnds = V.u_bound;
	if (mbnds < b) {
		assert(s->uBnds.getVar(1)==s->uBnds.getVar(0));
		if (info_level & 2) cerr << "ERSETZE:" << s->pick << endl;
		if (info_level & 2) cerr << "VORHER:" << s->uBnds.getU1()<<","<<s->uBnds.getU1() << endl;
		if (val[val_ix] == 0) s->uBnds.setU1(mbnds,s->uBnds.getVar(1));
		else                  s->uBnds.setU0(mbnds,s->uBnds.getVar(0));
		if (val[val_ix] == 0) s->uBnds.setSuc(1,false);
		else                  s->uBnds.setSuc(0,false);
		if (info_level & 2) cerr << "NACHHER:" << s->uBnds.getU1()<<","<<s->uBnds.getU1() << endl;
		if (val[val_ix] == 0) s->uBnds.setDepth(1,remainD);
		else                  s->uBnds.setDepth(0,remainD);
	} else {
		if (val[val_ix] == 0) s->uBnds.setSuc(1,false);
		else                  s->uBnds.setSuc(0,false);
		if (val[val_ix] == 0) s->uBnds.setDepth(1,remainD);
		else                  s->uBnds.setDepth(0,remainD);
	}
	return V.value;
}

coef_t QBPSolver::buyDualRootBound(int trail_start, coef_t a, coef_t b, int theMaxIx) {
	SearchResult V;
	MPI_Status status;
	//theMaxIx--;
	theMaxIx = 0;
	int remainD = fmax(1,sqrt((double)((decisionLevel()-theMaxIx)*3/4)));
	if (info_level & 2) cerr << "BUY: theMAxIx=" << theMaxIx << endl;
	stack_container *s = &search_stack.stack[theMaxIx];
	coef_t &score = stack_score[theMaxIx+1];
	int8_t *val;
	val = &stack_val[(theMaxIx+1)<<1];
	int8_t &val_ix = stack_val_ix[theMaxIx+1];
	static int currentD = 2;
	static int currentSuc=true;
	static time_t buyTime = 0;

	if (buyTime > (time(NULL) -  ini_time)*3/5 ) return -n_infinity;

	time_t buy_start_tim = time(NULL);
	if (remainD > currentD) ;
	else if (1) {
		remainD = currentD*12/10 ;//+ max(1,(decisionLevel()-s->uBnds.getDepth(1)-theMaxIx)/2);
	}
	currentD = remainD;
	//cerr << "theMax=" << b << " U0/U1:" << s->uBnds.getU0() << "/" << s->uBnds.getU1() << " val[val_ix]=" << (int)val[val_ix]<< endl;
	//cerr << "theMax-1=" << b << " U0/U1:" << (s-1)->uBnds.getU0() << "/" << (s-1)->uBnds.getU1() << " val[val_ix]=" << (int)val[val_ix]<< endl;
	//cerr << "theMax+1=" << b << " U0/U1:" << (s+1)->uBnds.getU0() << "/" << (s+1)->uBnds.getU1() << " val[val_ix]=" << (int)val[val_ix]<< endl;
	if (info_level & 2) cerr << "buy params " << trail_start << " Pick="<<s->pick<<endl;
	int j = 0;
	for (int i = trail_start; i > 0 && vardata[trail[i]].level > 0;i--,j++) {
		recvBuf[j].var = trail[i];
		recvBuf[j].value = assigns[trail[i]];
	}
	if (info_level & 2) for (int fg=0;fg<j;fg++) cerr << "@" << recvBuf[fg].var << "(" << vardata[recvBuf[fg].var].level << "), ";
	MPI_Send(recvBuf, j*sizeof(trailInfo), MPI_CHAR, processNo+1,UPD_TRAIL_SOLVE,MPI_COMM_WORLD);
	MPI_Send(&a, sizeof(coef_t), MPI_CHAR, processNo+1,UPD_TRAIL_SOLVE,MPI_COMM_WORLD);
	MPI_Send(&b, sizeof(coef_t), MPI_CHAR, processNo+1,UPD_TRAIL_SOLVE,MPI_COMM_WORLD);
	MPI_Send(&remainD, sizeof(int), MPI_CHAR, processNo+1,UPD_TRAIL_SOLVE,MPI_COMM_WORLD);
	MPI_Recv(&V, sizeof(SearchResult), MPI_CHAR, processNo+1,BOUGHT_BOUND,MPI_COMM_WORLD,&status);
	cerr << "RECEIVE BOUGHT ROOT RESULT [" << V.value << "," << V.u_bound << "]" << " <-> " << b << " in Level "<< theMaxIx << "/" << decisionLevel() << endl;
	coef_t mbnds = V.u_bound;//V.value;
	//if (V.u_bound < mbnds) mbnds = V.u_bound;
	if (mbnds < global_dual_bound) {
		global_dual_bound = mbnds;
		cerr << "IMPROVED global from " << global_dual_bound << " to " << mbnds << endl;
	}
	if (mbnds < s->local_ub) {
		cerr << "IMPROVED local from " << s->local_ub << " to " << mbnds << endl;
		s->local_ub = mbnds;
        currentSuc = true;
	} else {
		currentSuc = false;
		cerr << "DID NOT IMPROVE:" << global_dual_bound << " <= " << mbnds << endl;
	}
	buyTime = buyTime + (time(NULL)-buy_start_tim);
	return V.value;
}

coef_t QBPSolver::searchPrimal(int t, void *ifc) {
        yIF = ifc;
		coef_t v;
		int iteration=1;
		std::vector<std::pair<int,double> > cpropQ;
		int cnt_cpQ;
		CommPrint C;

		CRef confl=CRef_Undef;
		CRef confl_partner=CRef_Undef;
		int confl_var=-1;
		int startdepth=1;//10;//10;
		int lmax_sd = startdepth;
		max_sd = nVars() + 10;
		int cur_it_duration;
		int64_t prev_used_mem;
		int time_cons_depth = 0;
		int time_cons_breadth = 0;
		int last_sd = startdepth;
		random_seed = 1.3;
		double factor = 20.0;
		double magic_factor = 1.0;
		bool impl0=false;
		int luby_unit=256;
		int luby_start_unit = 256;
		int old_num_learnts = num_learnts;
		old_num_conflicts = (int64_t)(-20);
		coef_t best_objective=-n_infinity;
		coef_t global_ub=n_infinity;
		time_t starttime = time(NULL);
        Constraint &objective = constraintallocator[constraints[0]];
        global_score = n_infinity;
        global_dual_bound= p_infinity;
        bool comp_finished = false;
        BendersCutAlarm = false;
        end_by_empty_clause = false;
        objOffset = 0.0;

        if (check() == false) exit(0);

		/*spezialconstraint.clear();
		CoeVar cv;
		cv = mkCoeVar(0,300.0,false);
		spezialconstraint.push(cv);
		cv = mkCoeVar(3,300.0,true);
		spezialconstraint.push(cv);
		cv = mkCoeVar(7,265.0,true);
		spezialconstraint.push(cv);
		cv = mkCoeVar(11,230.0,true);
		spezialconstraint.push(cv);
		cv = mkCoeVar(21,200.0,true);
		spezialconstraint.push(cv);
		cv = mkCoeVar(22,400.0,true);
		spezialconstraint.push(cv);
		cv = mkCoeVar(23,200.0,true);
		spezialconstraint.push(cv);
		cv = mkCoeVar(24,400.0,true);
		spezialconstraint.push(cv);
		cv = mkCoeVar(29,200.0,true);
		spezialconstraint.push(cv);
		cv = mkCoeVar(30,400.0,true);
		spezialconstraint.push(cv);*/

		//addLearnConstraint(spezialconstraint, -1044.0, 0 /*konfliktvar, not used*/,false);
		//300.00000*x0+-300.00000*x3+-265.00000*x7+-230.00000*x11+-200.00000*x21+-400.00000*x22+
		     //-200.00000*x23+-400.00000*x24+-200.00000*x29+-400.00000*x30]>=86.00000
		//[1.00000*x0+-1.00000*x3+0.76667*x10+-0.66667*x29+-1.33333*x30]>=0.27333

		for (int i=0;i < nVars();i++) {
			level_finished[i] = 0;
			p_activity[i] = 0;
			n_activity[i] = 0;
			initFixed(i);
			seen[i] = 0;
			if (1||type[i] == INTEGER ||type[i] == BINARY) {
				if (assigns[i] == extbool_Undef && lowerBounds[i] == upperBounds[i]) {
					int oob;
					if (type[i] == BINARY)
					    oob = assign(i, lowerBounds[i], trail.size(),CRef_Undef, false);
					else
					    oob = real_assign(i, lowerBounds[i], trail.size(),CRef_Undef);

					if (oob != ASSIGN_OK) {
						cerr << "contradicting input" << endl;
						return n_infinity;
					} else {
						if (info_level >= 2) cerr << "Variable x" << i << " is input-fixed to " << lowerBounds[i] << endl;
						if (USE_TRACKON) assert(isOnTrack());
					}
				}
			}
		}
    	for (int hh = 0; hh < dirtyLPvars.size();hh++) {
    		//cerr << "set x" << dirtyLPvars[hh] << " to " << (int)assigns[dirtyLPvars[hh]] << endl;
    		if (type[dirtyLPvars[hh]] == BINARY) {
				if (getFixed(dirtyLPvars[hh]) == extbool_Undef && assigns[dirtyLPvars[hh]] == extbool_Undef) {
					if (type[dirtyLPvars[hh]] == BINARY && eas[dirtyLPvars[hh]] == EXIST) {
						QlpStSolve.setVariableLB(dirtyLPvars[hh],0,type.getData());
						QlpStSolve.setVariableUB(dirtyLPvars[hh],1,type.getData());
					}
				} else if (assigns[dirtyLPvars[hh]] != extbool_Undef) {
					if (USE_ASSIGNVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)assigns[dirtyLPvars[hh]],type.getData());
				} else {
					if (USE_EARLYVARFIX) QlpStSolve.setVariableFixation(dirtyLPvars[hh],(double)getFixed(dirtyLPvars[hh]),type.getData());
				}
    		}
			updateStageSolver(maxLPStage,dirtyLPvars[hh],dirtyLPvars[hh]);
			isDirty[dirtyLPvars[hh]] = false;
	    }
		while (dirtyLPvars.size() > 0) dirtyLPvars.pop();

		useDeep = 0;//1;//0;
		bool usedDeep=false;
    	bool isFi = false;
    	//HT->delLPtable();

		int lp_divider = 1;
		prev_it_duration = 0;
		next_check = 500;//0x3fffff;
		next_level_inc = 500  *1000;
		max_learnts = 1000000000; //constraints.size() + constraints.size() / 5 + 1;
		objective_iterations = 1;
		coef_t start_a=n_infinity, start_b=-n_infinity;
		if (hasObjective) start_b = constraintallocator[constraints[0]].header.wtch2.worst/*+1*/;
		start_b = dont_know / 2.0;
		for (int j=0; j < nVars();j++) {
			isInObj[j] = nVars()+10;
		}

		for (int j = 0; j < constraints.size(); j++)
			constraintallocator[constraints[j]].mark(0);

		int old_lpls = QlpStSolve.getExternSolver(maxLPStage).getRowCount();
		int cnt_runs = 0;
		int old_ts=0;
		do {
			cnt_runs++;
			int probe_pick=-1;
			int favour_pol = 0;
			if (info_level >= 2) cerr << "initial probing";
			old_ts = trail.size();
#define EARLY_PROBE
#ifdef EARLY_PROBE
			bool probe_output = probe(probe_pick, favour_pol, false);
			  // TODO : darf die Zeile 'if ...' rein?? bringt es was?? //
			  //if (probe_output == false) return _SearchResult(n_infinity,n_infinity);
			if (cnt_runs > 3 && !(trail.size() > old_ts + (nVars()-old_ts)/10)) {
				break;
			}
			if (probe_pick != -1) varBumpActivity(probe_pick, favour_pol);
#endif
		    cnt_cpQ = 0;
			cpropQ.clear();
			if (old_lpls > QlpStSolve.getExternSolver(maxLPStage).getRowCount())
				old_lpls = QlpStSolve.getExternSolver(maxLPStage).getRowCount();
			MPI_Send(recvBuf, 1, MPI_CHAR, processNo+1,UPD_CONSTRAINTS,MPI_COMM_WORLD);
			((yInterface*)yIF)->updateConstraints(((yInterface*)yIF)->qlp , this->QlpStSolve, assigns.getData(), -constraintallocator[constraints[0]].header.rhs, type.getData(), maxLPStage, cpropQ, lowerBounds.getData(), upperBounds.getData(),feasPhase, constraintList, block.getData(),eas.getData());
			QlpStSolve.getExternSolver(maxLPStage).saveSnapshot();
			makeAsnapshot(constraintList);
			addSymmetryConstraint(constraintList,cpropQ);
#ifdef FIND_BUG
			QlpStSolve.getExternSolver(maxLPStage).retrieveSnapshot();
			((yInterface*)yIF)->findComponents(((yInterface*)yIF)->qlp, assigns.getData(), components.getData(), varsOfComponents);
#endif
			if (cpropQ.size() > 0) {
				for (int uuu=0; !comp_finished && uuu < cpropQ.size(); uuu++) {
					bool isMonotone = false;
					if (cpropQ[uuu].first < 0) {
						cpropQ[uuu].first = -cpropQ[uuu].first - 1;
						isMonotone = true;
					}
					if (isMonotone && eas[cpropQ[uuu].first] == UNIV) continue;
					if (assigns[cpropQ[uuu].first] == extbool_Undef && eas[cpropQ[uuu].first] != UNIV) {
						// TODO Pruefen ob cpropQ[uuu].first wirklich manchmal UNIV und wegen Monotonie gesetzt.
						// TODO falls ja, kann UNIVERSAL auf anderen Wert fixiert werden !?
						int oob;
						if (type[cpropQ[uuu].first] == BINARY)
						    oob = assign(cpropQ[uuu].first,cpropQ[uuu].second > 0.5 ? 1 : 0, trail.size(),CRef_Undef, true);
						else
						    oob = real_assign(cpropQ[uuu].first, cpropQ[uuu].second, trail.size(),CRef_Undef);

						if (oob != ASSIGN_OK) {
							cerr << "contradicting input" << endl;
							return n_infinity;
						} else {
							if (info_level >= 2) cerr << "Variable x" << cpropQ[uuu].first << " is input-fixed to " << cpropQ[uuu].second << endl;
							if (USE_TRACKON) assert(isOnTrack());
						}

						if (oob != ASSIGN_OK || eas[cpropQ[uuu].first] == UNIV) {
							if (info_level >= 2) cerr << "3a:INFEASIBLE!" << endl;
							PurgeTrail(trail.size()-1,decisionLevel()-1);
							return n_infinity;
						}
						if (!propagate(confl, confl_var, confl_partner,false,false,1000000)) {
							if (info_level >= 2) cerr << "3a:INFEASIBLE 2!" << endl;
							PurgeTrail(trail.size()-1,decisionLevel()-1);
							return n_infinity;
						}
						cnt_cpQ++;
						vardata[cpropQ[uuu].first].level = 0;
						vardata[cpropQ[uuu].first].reason = CRef_Undef;
						settime[cpropQ[uuu].first] = 0;
						if (info_level >= 2) cerr << "have fixed x" <<  cpropQ[uuu].first << " mit cF_index=" << cpropQ[uuu].second << endl;
					}
				}
			}
			if (info_level >= 2) cerr << "Begin: cpropQ.size = " << cnt_cpQ << " and lpls: " << old_lpls << " ; " << QlpStSolve.getExternSolver(maxLPStage).getRowCount() << endl;
	    } while (cnt_cpQ>0 || old_lpls > QlpStSolve.getExternSolver(maxLPStage).getRowCount() || trail.size() > old_ts + (nVars()-old_ts)/10);
        cpropQ.clear();
        reduceDB(true);

		do {
   	        if (useDeep==0) usedDeep = false;
   	        else usedDeep = true;
   	        if (!feasPhase) { lmax_sd = nVars() + 10; useDeep = true; }
			if (info_level & 2) cout << "Start with maximum depth " << lmax_sd << " use Restarts: " << useRestarts << " Alpha=" << start_a << " Beta=" << start_b << endl;
			it_starttime = time(NULL);
			impl0 = false;
			for (int hh = 0; hh < n_activity.size(); hh++) n_activity[hh] /= (num_learnts-old_num_learnts+1);//10000;
			for (int hh = 0; hh < p_activity.size(); hh++) p_activity[hh] /= (num_learnts-old_num_learnts+1);//10000;
			old_num_learnts = num_learnts;
			coef_t score=n_infinity;
   	        do {
   	        	//max_learnts = max_learnts + max_learnts / 10 + 1;
	        	if (propagate(confl, confl_var, confl_partner, false, false, 1000000)) {
		        	if (info_level & 2) cout << "Length of trail=" << trail.size() << "; length of propQ=" << propQ.size() << endl;
       	        	int cnt_len2=0;
       	        	int cnt_len1=0;

					if (!impl0) for (int j = 0; j < constraints.size(); j++) {
						CRef cr = constraints[j];
						Constraint &c = constraintallocator[cr];
						int len=0;
						for (int i=0; i < c.size(); i++) {
						   if ( assigns[var(c[i])] == extbool_Undef ) len++;
						}
						if (len <= 2) c.header.learnt = 0; // TODO das ist nur eine Kr�cke, um zu verhindern, dass kurze Consraints gel�scht werden
						if (len == 2 && !c.saveFeas(assigns,type,lowerBounds,upperBounds,true)) cnt_len2++;
						if (len == 1) {
							// evtl. detach constraint?
						}
						if (len == 1 && !c.saveFeas(assigns,type,lowerBounds,upperBounds,true)) cnt_len1++;
						if (len == 1 && !c.saveFeas(assigns,type,lowerBounds,upperBounds,true)) {
							for (int i=0; i < c.size(); i++) {
							   if ( assigns[var(c[i])] == extbool_Undef && type[var(c[i])] == BINARY) {
			                        if (useFULLimpl || propQlimiter[c[i].x] <= 0) {
			        				   PROPQ_PUSH(ValueConstraintPair(cr,c[i].x,i));
			        				   propQlimiter[c[i].x] = propQ.size();
			                        } else propQ[propQlimiter[c[i].x]-1] = ValueConstraintPair(cr,c[i].x,i);

								    //PROPQ_PUSH(ValueConstraintPair(cr,c[i].x,i));
								    //propagate(confl, confl_var, confl_partner);
								    if (eas[var(c[i])] == UNIV) {
								    	if (info_level > 0) {
								    		cout << "direkt infeas mit Index " << i << endl;
								    		c.print(c,assigns,false);
								    		cerr << "Nr.:" << j << ", Anzahl:" << constraints.size() << endl;
								    	}
								    	return ((best_objective > dont_know) ? best_objective : n_infinity);
								    }
							   }
							}
						}
					}
     	        	if (info_level > 10) cout <<"Es gibt " << cnt_len2 << " constraints der Laenge 2 und " << cnt_len1 << "der Laenge 1" << endl;

     	        	if (propagate(confl, confl_var, confl_partner,false,false,1000000)) {
						max_sd = lmax_sd;
						lp_decider_depth = max_sd / lp_divider;
						if (break_from_outside) {
        		    		  break_from_outside = false;
        		    		  if (useWarmRestart) {
        		    		     for (int l=1;l<nVars();l++) {
        		    			    stack_val_ix[l] = stack_save_val_ix[l];
        		    		     }
        		    		  } else {
         		    		     for (int l=0;l<nVars();l++) {
         		    			    stack_restart_ready[l] = false;
         		    		     }
        		    		  }
     		    		      useWarmRestart = false;
						}
						if (info_level & 2) cout << "#Vars=" << nVars() << " und #Constraints=" << constraints.size() << ";" ;
                        forbidHashing = true;//false;
                	    if (useDeep && info_level & 2) cout << "use up to " << next_level_inc << "conflicts" << endl;
                	    else if (info_level & 2) cout << endl;
                	    next_check = num_conflicts + next_level_inc;
                	    constraintRescue.clear();
                	    discoveredNews = 0;
                	    SearchResult V;
                     	if (info_level & 2) cerr << "alpha=" << start_a << ", beta=" << start_b << ", p_inf="  << p_infinity << endl;
                     	if (USE_TRACKON > 0) assert(isOnTrack());
                     	if (isOnTrack()) assert(CM.checkTheGraph(optSol));
    		        	if (info_level & 2) cout << "Length of CG=" << CM.getConflictGraphSize() << endl;
#ifdef FIND_BUG // folgender Code ist sicher falsch
    		        	for (int pick=0; type[pick]==BINARY && useMonotones && pick<nVars();pick++){
    		        		if (assigns[pick] == extbool_Undef) {
								if (eas[pick]==UNIV && useMonotones && (CW.getCWatcher(pick+pick) == -1 || (feasPhase && CW.getCWatcher(pick+pick) == 0)) ) {
									assign(pick,(eas[pick]==EXIST) ? 0 : 1, trail.size(),CRef_Undef, true);
									if (info_level & 2) cerr << "mon set " << pick << " = " << ((eas[pick]==EXIST) ? 0 : 1) << endl;
								} else if (eas[pick]==UNIV && useMonotones && (CW.getCWatcher(pick+pick+1) == -1 || (feasPhase && CW.getCWatcher(pick+pick+1) == 0)) ) {
									assign(pick,(eas[pick]==EXIST) ? 1 : 0, trail.size(),CRef_Undef, true);
									if (info_level & 2) cerr << "mon set " << pick << " = " << ((eas[pick]==EXIST) ? 1 : 0) << endl;
								}
    		        		}
    		        	}
#endif
    		        	if (!feasPhase) {
    		        		for (int iiii = 0; iiii < trail.size();iiii++) {
    		        			recvBuf[iiii].var = trail[iiii];
    		        			recvBuf[iiii].value = assigns[trail[iiii]];
    		        			C.mefprint(processNo,"T:%d V:%d | ", trail[iiii], (int)assigns[trail[iiii]]);
    		        		}
    		        		C.mefprint(processNo,"\n");
    		        		MPI_Send(recvBuf, trail.size()*sizeof(trailInfo), MPI_CHAR, processNo+1,START_TRAIL,MPI_COMM_WORLD);
    		        	}
						V = alphabeta_loop(t,lmax_sd ,start_a, start_b,false,p_infinity,-1,0, true, true,0,0,false);
						if (V.value <= start_a && V.value > global_score) V.value = global_score;
						//cerr << "BACK " << break_from_outside << " " << propQ.size() << " " << revImplQ.size() << " " << level_finished[0] << " " << level_finished[2] <<" " << level_finished[2] <<endl;
						v = V.value;
						if (V.value > score) score=v;
						if (V.u_bound > global_ub && V.u_bound < p_infinity) global_ub = V.u_bound;
			        	if (break_from_outside) // ist das wirklich so? --> ja! nur bei break_from_outside. => propQ nichts wert.
			        		while(propQ.size() > 0) {
			        		    propQlimiter[propQ[propQ.size()-1].v] = 0;
			        		    propQ.pop();
			        	    }
						//if (v > n_infinity)
			        	if (info_level & 4) cerr << "z=" << v << " ub=" << V.u_bound << endl;
						prev_used_mem = used_mem;
						while (used_mem + used_mem / 2 > max_useable_mem && num_learnts > 0) {
							int oldsize = constraints.size();
							if (!reduceDB(false)) {
								PurgeTrail(trail.size()-1,decisionLevel()-1);
								return n_infinity;
							}
							if (oldsize == constraints.size() && used_mem + used_mem / 2 > max_useable_mem) {
								for (int i = 0; i < constraints.size(); i++) {
									Constraint &c = constraintallocator[constraints[i]];
									if (c.learnt()) {
										if (rand() % 10 == 0) c.header.act -= 1.0;
									}
								}
							}
						}
     	        	} else {
     	        		v = n_infinity;
     	        		break_from_outside = false;
     	        	}
     		    } else {
    			    v = n_infinity;
 	        		break_from_outside = false;
    		    }
	        	static ca_vec<ValueConstraintPair> buf_propQ;
	        	buf_propQ.clear();
                while (propQ.size()>0) {
                	buf_propQ.push(propQ[propQ.size()-1]);
                	propQ.pop();
                }
	        	isFi = false;
	        	if (useWarmRestart) {
	        		if (info_level >= 2) cerr << "isFi == true, weil Restart" << endl;
	        		isFi = true;
	        	}
	        	for (int uuu=0; !comp_finished && uuu < nVars(); uuu++) {
	        		if (getFixed(uuu) != extbool_Undef && assigns[uuu] == extbool_Undef) {
	        			if (eas[uuu] == UNIV) {
	        				if (info_level >= 2) cerr << "UNIVERSAL INFEASIBLE!" << endl;
							if (feasPhase) score = v = n_infinity;
							comp_finished = true;
	        			} else {
							int oob = assign(uuu,getFixed(uuu), trail.size(),CRef_Undef, true);
							if (oob != ASSIGN_OK /*|| eas[uuu] == UNIV*/) {
								if (info_level >= 2) cerr << "INFEASIBLE!" << endl;
								if (feasPhase) score = v = n_infinity;
								comp_finished = true;
							}
							if (!propagate(confl, confl_var, confl_partner,false,false,1000000)) {
								if (info_level >= 2) cerr << "INFEASIBLE 2!" << endl;
								if (feasPhase) score = v = n_infinity;
								comp_finished = true;
							}
							vardata[uuu].level = 0;
							vardata[uuu].reason = CRef_Undef;
							settime[uuu] = 0;
							if (info_level >= 2) cerr << "have fixed x" <<  uuu << " mit iF_index=" << getFixed(uuu) << endl;
							if (USE_TRACKON && !isOnTrack()) {
								cerr << "can occur when result found." << endl;
								//assert(0);
							}
	        			}
	  		    		//impl0=true;
	  		    		isFi = true;
	        		}
	        	}
	        	propQ.clear();
                while (buf_propQ.size()>0) {
                	PROPQ_PUSH(buf_propQ[buf_propQ.size()-1]);
                	buf_propQ.pop();
                }
    		    if (propQ.size() > 0) {
    		    	impl0 = true;
   		    	    for (int ii = 0; ii < propQ.size();ii++) {
    		    		propQ[ii].cr = CRef_Undef;
    		    		vardata[propQ[ii].v>>1].reason = CRef_Undef;
    		    		vardata[propQ[ii].v>>1].level = 0;
    		    		settime[propQ[ii].v>>1] = 0;
    		    		if (eas[propQ[ii].v>>1] == UNIV) {
    		    			if (info_level >= 2) cerr << "Univ implied on L0. Infeasible." << endl;
    		    			score = v = n_infinity;
    		    			impl0 = false;
    		    			comp_finished = true;
    		    			break;
    		    		} else if (assigns[propQ[ii].v>>1] == extbool_Undef) { // can occur when the implication comes from lp
        		    		assign(propQ[ii].v>>1,1-(propQ[ii].v&1), trail.size(),CRef_Undef, true);
        		    		if (info_level >= 2) cerr << "have fixed x" <<  (propQ[ii].v>>1) << " mit pQ_index=" << 0 << endl;
        		    	} else if (assigns[propQ[ii].v>>1] == (propQ[ii].v&1)) {
        		    		if (info_level >= 2) cerr << "contra implication" << endl;
    		    			score = v = n_infinity;
    		    			impl0 = false;
    		    			comp_finished = true;
    		    			break;
        		    	}

    		    	}
    				if (((!useDeep || feasPhase) && (double)num_learnts > 5000.0f * log((double)(iteration+1))) || (double)constraints.size() > 50000.0f * log((double)(iteration+1))) {
    				//if ((!useDeep && num_learnts > 5000) || constraints.size() > 50000) {
    					if (!reduceDB(false)) {
    						PurgeTrail(trail.size()-1,decisionLevel()-1);
    						return n_infinity;
    					}
    				}
    		    	//if (!useDeep) lmax_sd = startdepth;
    		    	if (info_level > 0 && propQ.size() > 0) cout << "Folgerung auf Level 0. x" << (propQ[0].v>>1) << "=" <<1-(propQ[0].v&1) << ", " << level_finished[2] << endl;
    		    	if (info_level > 0 && revImplQ.size() > 0) cout << "Alternative Folgerung auf Level 0. x" << (revImplQ[0].v>>1) << "=" <<1-(revImplQ[0].v&1) << ", " << level_finished[2] << endl;
        		}
				/*if (!feasPhase) if (impl0 || isFi || old_ts < trail.size()) {
					if (!reduceDB(false)) {
						PurgeTrail(trail.size()-1,decisionLevel()-1);
						return n_infinity;
					}
				}*/
    			if (info_level > 4 && hasObjective && /*-best_objective*/constraintallocator[constraints[0]].header.rhs > dont_know) {
    				cerr << "\n*Best Objective Value so far: " << best_objective << " ObjRhs=" << constraintallocator[constraints[0]].header.rhs << " DecisionNodes: " << num_decs << endl;
    				//start_a = constraintallocator[constraints[0]].header.rhs-abs(constraintallocator[constraints[0]].header.rhs*objective_epsilon)-objective_epsilon;
    			}
    			if ((info_level & 4)) cerr << "some Info" << propQ.size() << " " << revImplQ.size() << " " << hasObjective << " " << v << " " << dont_know << endl;
                if (end_by_empty_clause) {
                      cerr << "Detected empty constraint" << endl;
                      break;
                }
                if (comp_finished) break;
   			    coef_t gap;
    			gap = abs(100.0*(-global_dual_bound + global_score) / (abs(global_score)+1e-10) );
    			if (gap < SOLGAP) break;

   	        } while((propQ.size() > 0 || revImplQ.size()>0) && !(!hasObjective && v > dont_know));
   	        v = score;
   	        if (v < global_score) v = global_score;
    	    cur_it_duration = time(NULL) - it_starttime;
   	        if (info_level & 2) cerr << "score=" << score << " und v=" << v << endl;
    	    if (useDeep) time_cons_depth = cur_it_duration;
    	    else         {
    	    	static double timul=0.0;
    	    	timul += 1.0;
    	    	if (last_sd < 22)
    	    	   time_cons_breadth = cur_it_duration;
    	    	else
     	    	   time_cons_breadth = cur_it_duration*timul;
    	    }
    	    //if ((((useDeep==false && old_num_learnts == num_learnts) ? 1.0:20.0)*time_cons_depth < (double)time_cons_breadth && last_sd >= 19) ||
            if (useDeep==false) {
            	if (old_num_learnts == num_learnts) factor /= 2;
                else factor *= 8;
            } else if (!impl0) factor *= 1.1;
            if (impl0 && useDeep) factor /= 2;
            if (factor < 0.1) factor = 0.1;
            if (factor > 10.0) factor = 10.0;
    	    if ((0.1*factor*time_cons_depth < (double)time_cons_breadth && last_sd >= 2/*10*/) ||
    	    	(impl0 && useDeep) || !feasPhase) {
    	    	useDeep = true;
    	    	lmax_sd = nVars() + 10;
    	    	iteration++;
    	    	if (impl0) {
    	    		if (luby_unit > 16) luby_unit /= 2;
    	    	} else {
    	    		luby_unit = luby_start_unit;
    	    	}
    	    } else {
    	    	luby_unit = luby_start_unit;
    	    	if (useDeep == true) {
    	    		last_sd = 5;
    	    	}
    	    	lmax_sd = nextDepth(last_sd);
    	    	objective_iterations++;
    	    	useDeep = false;
                if (!feasPhase) factor = 0.1;
    	    	last_sd = lmax_sd;
    	    }
 			if (!break_from_outside) {
				if (((!useDeep || feasPhase) && (double)num_learnts > 5000.0f * log((double)(iteration+1))) || (double)constraints.size() > 50000.0f * log((double)(iteration+1))) {
					if (!reduceDB(false)) {
						PurgeTrail(trail.size()-1,decisionLevel()-1);
						return n_infinity;
					}
				}
			}
			//if (info_level > 0) cout << "next level maximum depth: " << lmax_sd << endl;
			//else cerr << "next level maximum depth: " << lmax_sd << endl;
			prev_it_duration = time(NULL) - it_starttime;
			//next_level_inc = 500 * iteration;
			//if (info_level > 0) cout << "Dauer letzter Iteration: " << prev_it_duration << endl;
			//else cerr << "Dauer letzter Iteration: " << prev_it_duration << endl;
			coef_t gap;
			if (hasObjective) gap = abs(100.0*(-global_dual_bound - best_objective) / (abs(best_objective)+1e-10) );
			else gap = -100;
			if (info_level > 1 && !hasObjective) cerr << "Best Objective Value so far: " << best_objective << " DecisionNodes: " << num_decs << endl;
    	    //iteration++;
            if (hasObjective && -best_objective > dont_know) {
            	luby_unit = 128;
            	luby_start_unit = 128;
	    		//luby_unit = luby_start_unit * iteration *iteration*iteration;
            }
    	    next_level_inc = get_luby(iteration/* > 1 ? iteration-1 : 1*/,luby_unit); //512*(iteration-1);// * (lmax_sd / 10);
    	    //else next_level_inc =
    	    ////if (hasObjective && -best_objective > dont_know /*&& gap < 10.0*/ && next_level_inc < 1000000000) next_level_inc = 1000000000;
    	    //for (int ii = 0; ii < nVars();ii++)
    	    //	cout << p_activity[ii] + n_activity[ii] << " ";
    	    //cout << endl;
    	    if (info_level & 4) cerr << "See the untouched stack:" << endl;
    	    if (/*!useRestarts &&*/ break_from_outside && (useWarmRestart || (double)num_learnts > 3.0*((double)num_orgs)*sqrt((double)iteration+1.0)*magic_factor)) {
    	    	if (info_level >= 2) cerr << "reduce: " << constraints.size() << " with " << iteration << " iterations" << endl;
    	    	int onc = constraints.size();
    	    	do {
    	    		int nc=constraints.size();
    	    		if (!reduceDB(false)) {
    	    			PurgeTrail(trail.size()-1,decisionLevel()-1);
    	    			return n_infinity;
    	    		}
    	    		if (nc <= constraints.size()) {
    	    			iteration = iteration + iteration / 5 + 8;
    	    			magic_factor *= 1.0;
    	    		} else if (constraints.size() * 3 / 2 <= onc) break;
				} while(constraints.size() > num_orgs * 3 * sqrt((double)(iteration+1)));
				//cerr << " -> " << constraints.size() << endl;
    	    } else {
    	    	if (info_level & 2) cerr << "no restart: (0,1,>) " << useRestarts << " " << break_from_outside << " " << num_learnts << " " << 10*num_orgs << endl;
    	    }

		if (next_level_inc > 2000 || !useRestarts) {
			if (1/*||trail.size() > oldTrailSize*/) {
				for (int j = 0; j < constraints.size(); j++) {
					CRef cr = constraints[j];
					Constraint &c = constraintallocator[cr];
					if (!c.header.isSat) {
						double best = 0.0, worst = 0.0;
						for (int i = 0; i < c.size(); i++) {
							if (sign(c[i]))
								worst -= c[i].coef*lowerBounds[var(c[i])];
							else
								best += c[i].coef*upperBounds[var(c[i])];

							if (assigns[var(c[i])] != extbool_Undef) {
								if (type[var(c[i])] == BINARY) {
									if (sign(c[i])) {
										if (assigns[var(c[i])] == 0)
											worst += c[i].coef;
										if (assigns[var(c[i])] == 1)
											best -= c[i].coef;
									} else {
										if (assigns[var(c[i])] == 0)
											best -= c[i].coef;
										if (assigns[var(c[i])] == 1)
											worst += c[i].coef;
									}
									//cerr << "check vars x" << var(c[i]) << "=" << (int)assigns[var(c[i])] << endl;
								} else assert(assigns[var(c[i])] == 0);
							}
						}
						if (best < c.header.rhs) {
							if (info_level > 1) {
								cout << "from Check Collection: infeasable" << endl;
								for (int i = 0; i < c.size(); i++) {
									cerr << "x" << var(c[i]) << "=" << (int)assigns[var(c[i])]
									  << "(" << lowerBounds[var(c[i])] << "," <<  upperBounds[var(c[i])] << "," << (int)type[var(c[i])] << ")" << " + ";
								}
								cerr << " >=? " << c.header.rhs << " -> best=" << best << endl;
							}
							PurgeTrail(trail.size() - 1, decisionLevel() - 1);
							if (feasPhase) return n_infinity;
							return fmin(-v,best_objective);    	    //n_infinity;
						}
					} else {
						bool TrueLitExists = false;
						bool FreeLitEx = false;
						for (int i = 0; i < c.size(); i++) {
							if (sign(c[i]) && assigns[var(c[i])] == 0)
								TrueLitExists = true;
							if (!sign(c[i]) && assigns[var(c[i])] == 1)
								TrueLitExists = true;
							if (assigns[var(c[i])] == extbool_Undef) {
								FreeLitEx = true;
								break;
							}
						}
						if (FreeLitEx == false) {
							if (!TrueLitExists) {
								if (info_level > 0)
									cout
											<< "from Check Collection K: infeasable"
											<< endl;
								PurgeTrail(trail.size() - 1,
										decisionLevel() - 1);
								if (feasPhase) return n_infinity;
								return fmin(-v,best_objective);//n_infinity;
							}
						}
					}
				}
			}
		}

            if (hasObjective /*&& !feasibilityOnly*/) {
    	        if (v > dont_know) {
    	        	bool improvement = false;
       	        	if (-v<best_objective) { best_objective = -v; improvement = true; }
    				if (hasObjective) {
    					gap = abs(100.0*(-global_dual_bound - best_objective) / (abs(best_objective)+1e-10) );
    					if (info_level > 1) cerr << "Best Objective Value so far: " << best_objective << " ;GAP:" << gap << "% ;Global LB of Minimazation: " << -global_dual_bound << " Time:" << time(NULL)-starttime << " DecisionNodes: " << num_decs << endl;
    				}
    				if (gap >= -0.01 && gap < SOLGAP) {
    					cerr << "Minimum gap reached." << endl;
    					break;
    				}
                    old_num_conflicts = num_conflicts;
    	        	useRestarts = false;
    				for (int j=0; j < constraintallocator[constraints[0]].size();j++) {
    					isInObj[var(constraintallocator[constraints[0]][j])] = j;
    				}
                    if (constraintallocator[constraints[0]].header.rhs >= constraintallocator[constraints[0]].header.rhs + (constraintallocator[constraints[0]].header.rhs>=(coef_t)0?constraintallocator[constraints[0]].header.rhs:-constraintallocator[constraints[0]].header.rhs)*objective_epsilon) {
                        cerr << "Maximum coef_t Precision reached. rhs=" << constraintallocator[constraints[0]].header.rhs << " and v*=" << v + abs(v)*objective_epsilon << endl;
                        if (objective_epsilon > 0.1) break;
                    }
                    if (objective_iterations >= max_objective_iterations) {
                        cerr << "Maximum objective improvements reached." << endl;
                        break;
                    }
                    if (global_score >= global_dual_bound) {
                    	  global_dual_bound = global_score;
                    	  if (info_level >= 2) cerr << "score=" << global_score << " and dual bound:" << global_dual_bound << endl;
                          else cerr << "Termination by bound-overlap" << endl;
                          break;
                      }
                    if (end_by_empty_clause) {
                          cerr << "Termination by empty constraint" << endl;
                          break;
                      }
         	        Constraint &cc = constraintallocator[constraints[0]];
        	        cc.header.rhs = -best_objective + (-best_objective>=(coef_t)0?-best_objective:best_objective)*objective_epsilon;//v + (v>=(coef_t)0?v:-v)*objective_epsilon;
        	                Constraint &learnt_c = constraintallocator[constraints[0]];
	   				    	for (int zz = 0; zz <= maxLPStage; zz++) {
								/*std::vector<data::IndexedElement> lhs;
								for (int ii = 0; ii < learnt_c.size();ii++) {
									unsigned int index = var(learnt_c[ii]);
									double value = (sign(learnt_c[ii]) ? (double)(-learnt_c[ii].coef) : (double)(learnt_c[ii].coef));
									lhs.push_back(data::IndexedElement(index,value));
								}*/
								//learnt_c.header.userCutIdentifier = QlpStSolve.addUserCut(maxLPStage, lhs, data::QpRhs::greaterThanOrEqual, (double)learnt_c.header.rhs);
	   				            //cerr << learnt_c.header.userCutIdentifier.first << " " << learnt_c.header.userCutIdentifier.second << endl;
								if (info_level & 4) cerr << "newvalue" << decisionLevel() << " "<< -learnt_c.header.rhs << " ";
								QLPSTSOLVE_TIGHTEN_OBJ_FUNC_BOUND(zz,(double)-learnt_c.header.rhs);
	   				    		//QlpStSolve.changeUserCutRhs((*learnt_c.header.userCutIdentifiers)[zz],(double)learnt_c.header.rhs);
								//cout << "\n -----> ";
                                //learnt_c.print(learnt_c,assigns,false);
                                //cout << " >= " << learnt_c.header.rhs << " <-----" << endl;
	   				    	}
    	        	if (info_level & 4) cerr << "new rhs:" << cc.header.rhs << " global UB:" << global_ub << endl;
       	            if (info_level & 4) cerr << "lb=" << cc.header.wtch2.worst << " und ub=" << cc.header.btch1.best << endl;
        	        start_a = learnt_c.header.rhs;///*n_infinity;*/-best_objective-1;//-(coef_t)8;
        	        start_b = p_infinity;//-best_objective+/*start_a +*/ 1 +(-best_objective>=(coef_t)0?-best_objective:best_objective)*/*objective_epsilon*/0.1;//objective_window_size;
                    if ((info_level & 4)) cerr << "next a:" << start_a << " next b:" << start_b << endl;
        	        //dont_know = v-(coef_t)1; braucht man nicht und macht Aerger
                    if ((info_level & 4)) cerr << "h.best=" << cc.header.btch1.best << " rhs=" << constraintallocator[constraints[0]].header.rhs << endl;
    	            if (cc.header.btch1.best < constraintallocator[constraints[0]].header.rhs) break;
    	            //cc.print(cc,assigns,false);
    	            if (info_level & 4)  cerr << "fP=" << feasPhase << " bfo=" << break_from_outside << " impl0" << impl0 << " isFi=" << isFi << " uD=" << usedDeep << " uWR=" << useWarmRestart << endl;
                	if (!feasPhase && !break_from_outside && /*!impl0 &&*/ usedDeep && !useWarmRestart/*&& !isFi*/) break;
                	if (feasibilityOnly) {
                		if (info_level & 4) cerr << "termination because of feasibility-only." << endl;
                		break;
                	}
					if (feasPhase && !reduceDB(true)) {
						PurgeTrail(trail.size()-1,decisionLevel()-1);
						return n_infinity;
					}

    	        	feasPhase = false;

    		        int old_lpls = QlpStSolve.getExternSolver(maxLPStage).getRowCount();
    		        int rem_lpls = old_lpls;

    	    	    do {
    	    	    	cnt_cpQ=0;
    	    	    	cpropQ.clear();
    	    			if (old_lpls > QlpStSolve.getExternSolver(maxLPStage).getRowCount())
    	    				old_lpls = QlpStSolve.getExternSolver(maxLPStage).getRowCount();
    	    			MPI_Send(recvBuf, 1, MPI_CHAR, processNo+1,UPD_CONSTRAINTS,MPI_COMM_WORLD);
    	    	    	((yInterface*)yIF)->updateConstraints(((yInterface*)yIF)->qlptmp , this->QlpStSolve, assigns.getData(), -constraintallocator[constraints[0]].header.rhs, type.getData(),
    	    	    			            maxLPStage, cpropQ, lowerBounds.getData(), upperBounds.getData(),feasPhase, constraintList, block.getData(),eas.getData());
    	    	    	QlpStSolve.getExternSolver(maxLPStage).saveSnapshot();
    	    	    	makeAsnapshot(constraintList);
    	    	    	addSymmetryConstraint(constraintList,cpropQ);
#ifdef FIND_BUG
    	    	    	QlpStSolve.getExternSolver(maxLPStage).retrieveSnapshot();
    	    	    	((yInterface*)yIF)->findComponents(((yInterface*)yIF)->qlptmp, assigns.getData(), components.getData(), varsOfComponents);
#endif
    	    	    	if (cpropQ.size() > 0) {
    	    	        	for (int uuu=0; !comp_finished && uuu < cpropQ.size(); uuu++) {
    	    					bool isMonotone = false;
    	    					if (cpropQ[uuu].first < 0) {
    	    						cpropQ[uuu].first = -cpropQ[uuu].first - 1;
    	    						isMonotone = true;
    	    					}
    	    					if (isMonotone && eas[cpropQ[uuu].first] == UNIV) continue;
    	    	        		if (assigns[cpropQ[uuu].first] == extbool_Undef && eas[cpropQ[uuu].first] != UNIV) {
    	    						int oob;
    	    						if (type[cpropQ[uuu].first] == BINARY)
    	    						    oob = assign(cpropQ[uuu].first,cpropQ[uuu].second > 0.5 ? 1 : 0, trail.size(),CRef_Undef, true);
    	    						else
    	    						    oob = real_assign(cpropQ[uuu].first, cpropQ[uuu].second, trail.size(),CRef_Undef);
    	    						// TODO Pruefen ob cpropQ[uuu].first wirklich manchmal UNIV und wegen Monotonie gesetzt.
    	    						// TODO falls ja, kann UNIVERSAL auf anderen Wert fixiert werden !?
    	    	  		    		if (oob != ASSIGN_OK || eas[cpropQ[uuu].first] == UNIV) {
    	    	  		    			if (info_level >= 2) cerr << "3:INFEASIBLE!" << endl;
    	    							PurgeTrail(trail.size()-1,decisionLevel()-1);
    	    							return n_infinity;
    	    	  		    		}
    	    	  		    		if (!propagate(confl, confl_var, confl_partner,false,false,1000000)) {
    	    	  		    			if (info_level >= 2) cerr << "3:INFEASIBLE 2!" << endl;
    	    							PurgeTrail(trail.size()-1,decisionLevel()-1);
    	    							return n_infinity;
    	    	  		    		}
    	    			    		vardata[cpropQ[uuu].first].level = 0;
    	    			    		vardata[cpropQ[uuu].first].reason = CRef_Undef;
    	    			    		settime[cpropQ[uuu].first] = 0;
    	    			    		if (info_level >= 2) cerr << "have fixed x" <<  cpropQ[uuu].first << " mit cF_index=" << cpropQ[uuu].second << endl;
    	    	  		    		cnt_cpQ++;
    	    	        		}
    	    	        	}
    	    			}
    	    	    	if (info_level >= 2) cerr << "mainloop: cpropQ.size = " << cnt_cpQ << " and lpls: " <<old_lpls << " ; " << QlpStSolve.getExternSolver(maxLPStage).getRowCount() << endl;
    	    	    } while (cnt_cpQ>0 || old_lpls > QlpStSolve.getExternSolver(maxLPStage).getRowCount() );
    	    	    v = dont_know;
    	            objective_iterations++;
    	            cpropQ.clear();
    	            if (rem_lpls > old_lpls + old_lpls / 5) reduceDB(false);
    	        } else if (v < dont_know  && !break_from_outside) {
    	        	if (info_level >= 2) cerr << "Ende der Suche. Objective=" << best_objective << " und rhs=" << constraintallocator[constraints[0]].header.rhs << " und dont_know=" << dont_know << endl;
                    break;
    	        }
            } else best_objective = v;
            if(info_level & 4) cerr << "v=" << v << " dK=" << dont_know << " bfo=" << break_from_outside << " cf=" << comp_finished << endl;
            if (end_by_empty_clause) {
                  cerr << "Detected empty constraint 2" << endl;
                  break;
            }
		} while ((v == dont_know || break_from_outside) && !comp_finished);
		PurgeTrail(trail.size()-1,decisionLevel()-1);
		if(info_level & 2) cerr << "Stronger: Fst=" << num_firstStrong << " Sec=" << num_secondStrong << endl;
		MPI_Send(recvBuf, 1, MPI_CHAR, processNo+1,FINISH,MPI_COMM_WORLD);
		C.mefprint(processNo,"sent Message with TAG %d\n",FINISH);
		return best_objective;
	}



