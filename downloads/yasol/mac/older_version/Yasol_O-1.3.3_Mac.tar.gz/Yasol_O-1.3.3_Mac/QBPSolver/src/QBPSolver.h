/*
*
* Yasol: QBPSolver.h -- Copyright (c) 2012-2017 Ulf Lorenz
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
* LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
* OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef QBPSOLVER_H_
#define QBPSOLVER_H_

#define USE_FULL_BENDERS
#define GUROBI_BENDERS

#define massert(a) {}
//assert(a)

//#define PROPQ_PUSH(x) { propQ.push((x)); /*if(((x).v>>1)==88 || ((x).v>>1)==90) cerr << "in88/90" << endl;*/ }

#include <chrono>
#include <thread>
#ifndef NO_MPI
#include <mpi.h>
#else
#include "nomp.h"
#endif
#include "commprint.h"
#include <string>
#include <algorithm>

//no probing (probe(..), no cuts (.ini), no preprocessing (yInter...), dual fixes

#include "Settings/Settings.hpp"
#include "Algorithms/Algorithms.hpp"
#include "Datastructures/Datastructures.hpp"
#include "Utilities/Parser.hpp"
#include "Utilities/QlpStageSolver.hpp"

//#include "cutGeneration.h"

#define fabs(x) ((x) >= 0 ? (x) : -(x))
#define SOLGAP (time(NULL)-ini_time < 100 ? 0.04 : 0.1)

#include "DataStructures.h"
#include "HashTable.h"
#include "cliques.h"
#include "dependencies.h"
#include "ConstraintWatcher.h"
#define EXIST 0
#define UNIV  1
#define ASSIGN_OK -1
#define BINARY        0
#define INTEGER    4999
#define CONTINUOUS 5000
#define FORCED    0
#define PREFERRED 1
#define useCliqueTables 1

#define SEARCH_LEARN_TRADEOFF 1
#define PROPQ_LIMITER 5000
//((num_orgs+nVars()) / 4)
//1000
#define PROPQ_MULT 2
#define SUPPRESS_RETURN 0
#define SUPPRESS_IMPLICATIONS 1
#define USE_TRACKER 0
#define USE_CLICK_EXTR_OUT 0
#define USE_LP_REDUCTION_OUT 0
#define USE_EARLYVARFIX 0
#define USE_ASSIGNVARFIX 1
//#define TRACE

#define LP_EPS         1e-12    //1e-12
#define RHS_EPS        0.000005
#define RHS_RELEPS     0.000001

#define EMPT     0
#define ANALYSIS 1
#define ANAALL   2
#define BEND     3

#define DEBUG_LEVEL 0

#define START         0
#define REK_EXIST     1
#define REK_UNIV      2
#define FINISHED   1000

#define START_TRAIL     1
#define UPD_CONSTRAINTS 2
#define UPD_TRAIL_SOLVE 3
#define FINISH          4
#define BOUGHT_BOUND    5

static const double var_decay = 0.95; //program parameters
static const double constraint_decay = 0.999;
static const int64_t max_useable_mem = 5000000000;
static const int32_t max_objective_iterations = 1000000000;
//static const int info_level = 5;//5;//10;
#define fmin(a,b) (a<b?a:b)
#define fmax(a,b) (a>b?a:b)

struct pairSortLt {
  public:
   bool operator () (std::pair<double,uint32_t> x, std::pair<double,uint32_t> y) const {
     return (x.first < y.first);
   }
   pairSortLt() { }
};

struct lpSortLt {
  public:
	const ca_vec<double>&  p_activity;
	const ca_vec<double>&  n_activity;
	const ca_vec<int> &block;
	const ca_vec<int> &isInObj;
	const ca_vec<int> &type;
	const ca_vec<double>&  p_pseudocost;
	const ca_vec<double>&  n_pseudocost;
	const ca_vec<uint64_t> &p_pseudocostCnt;
	const ca_vec<uint64_t> &n_pseudocostCnt;
    const bool &sortmode;
	const ca_vec<uint64_t> &brokenCnt;
	DependManager &dm;

    bool operator () (Var x, Var y) const {
    	if (type[x] == type[y]) {
    	    bool r = block[x] < block[y]/*dm.dependency(x,y)*/;
    	    if (block[x] == block[y]/*dm.equiv(x,y)*/) {
    		    /*r = isInObj[x] < isInObj[y];
    		    if (isInObj[x] == isInObj[y])*/
    	    	if (0&&sortmode)
    		       r = (p_activity[x]+n_activity[x] > p_activity[y]+n_activity[y]);
    	    	else {
     	    	   //const double pcx = (p_pseudocost[x] / (double)p_pseudocostCnt[x]) * (n_pseudocost[x] / (double)n_pseudocostCnt[x]);
     	    	   //const double pcy = (p_pseudocost[y] / (double)p_pseudocostCnt[y]) * (n_pseudocost[y] / (double)n_pseudocostCnt[y]);
     	    	   const double pcx = (p_pseudocost[x] + n_pseudocost[x]) / ((double)n_pseudocostCnt[x]+(double)p_pseudocostCnt[x]);
    	    	   const double pcy = (p_pseudocost[y] + n_pseudocost[y]) / ((double)n_pseudocostCnt[y]+(double)p_pseudocostCnt[y]);
                   if (p_activity[x]+n_activity[x] != p_activity[y]+n_activity[y] || (pcx == pcy || n_pseudocostCnt[x] + p_pseudocostCnt[x] < 20 || n_pseudocostCnt[y] + p_pseudocostCnt[y]< 20)) {
                	   if (p_activity[x]+n_activity[x] != p_activity[y]+n_activity[y])
                	        r = (p_activity[x]+n_activity[x] > p_activity[y]+n_activity[y]);
           	    	   else r = false;//brokenCnt[x] > brokenCnt[y];
                   } else r = pcx > pcy;
    	    	}
    	    }
    	    return r;
    	} else return type[x] < type[y];
    }
    lpSortLt(const ca_vec<double>&  pact, const ca_vec<double>&  nact, const ca_vec<int>& blo, const ca_vec<int>& iIO,
    		const ca_vec<int> &ty, const ca_vec<double> &ppc,const ca_vec<double> &npc,const ca_vec<uint64_t> &ppcCnt,const ca_vec<uint64_t> &npcCnt,const bool &somo, const ca_vec<uint64_t> &brocn, DependManager &d)  :
    		p_activity(pact), n_activity(nact), block(blo), isInObj(iIO), type(ty), p_pseudocost(ppc), n_pseudocost(npc),
    		p_pseudocostCnt(ppcCnt), n_pseudocostCnt(npcCnt), sortmode(somo), brokenCnt(brocn), dm(d) { }
};
struct antilpSortLt {
  public:
	const ca_vec<double>&  p_activity;
	const ca_vec<double>&  n_activity;
	const ca_vec<int> &block;
	const ca_vec<int> &isInObj;
	const ca_vec<int> &type;
	const ca_vec<double>&  p_pseudocost;
	const ca_vec<double>&  n_pseudocost;
	const ca_vec<uint64_t> &p_pseudocostCnt;
	const ca_vec<uint64_t> &n_pseudocostCnt;
    const bool &sortmode;
	const ca_vec<uint64_t> &brokenCnt;
	DependManager &dm;

    bool operator () (Var x, Var y) const {
    	//return x < y;
    	if ((rand()&1) == 0) return true;
    	else return false;
    	if (type[x] == type[y]) {
    	    bool r = block[x] > block[y]/*dm.dependency(x,y)*/;
    	    if (block[x] == block[y]) {
    		    /*r = isInObj[x] < isInObj[y];
    		    if (isInObj[x] == isInObj[y])*/
    	    	if (0&&sortmode)
    		       r = (p_activity[x]+n_activity[x] < p_activity[y]+n_activity[y]);
    	    	else {
     	    	   //const double pcx = (p_pseudocost[x] / (double)p_pseudocostCnt[x]) * (n_pseudocost[x] / (double)n_pseudocostCnt[x]);
     	    	   //const double pcy = (p_pseudocost[y] / (double)p_pseudocostCnt[y]) * (n_pseudocost[y] / (double)n_pseudocostCnt[y]);
     	    	   const double pcx = (p_pseudocost[x] + n_pseudocost[x]) / ((double)n_pseudocostCnt[x]+(double)p_pseudocostCnt[x]);
    	    	   const double pcy = (p_pseudocost[y] + n_pseudocost[y]) / ((double)n_pseudocostCnt[y]+(double)p_pseudocostCnt[y]);
                   if ((pcx == pcy || n_pseudocostCnt[x] + p_pseudocostCnt[x] < 20 || n_pseudocostCnt[y] + p_pseudocostCnt[y]< 20)) {
                	   if (p_activity[x]+n_activity[x] != p_activity[y]+n_activity[y])
                	        r = (p_activity[x]+n_activity[x] < p_activity[y]+n_activity[y]);
           	    	   else r = false;//brokenCnt[x] > brokenCnt[y];
                   } else r = pcx < pcy;
    	    	}
    	    }
    	    return r;
    	} else return type[x] > type[y];
    }
    antilpSortLt(const ca_vec<double>&  pact, const ca_vec<double>&  nact, const ca_vec<int>& blo, const ca_vec<int>& iIO,
    		const ca_vec<int> &ty, const ca_vec<double> &ppc,const ca_vec<double> &npc,const ca_vec<uint64_t> &ppcCnt,const ca_vec<uint64_t> &npcCnt,const bool &somo, const ca_vec<uint64_t> &brocn, DependManager &d)  :
    		p_activity(pact), n_activity(nact), block(blo), isInObj(iIO), type(ty), p_pseudocost(ppc), n_pseudocost(npc),
    		p_pseudocostCnt(ppcCnt), n_pseudocostCnt(npcCnt), sortmode(somo), brokenCnt(brocn), dm(d) { }
};
struct VarOrderLt {
  public:
    const ca_vec<double>&  p_activity;
    const ca_vec<double>&  n_activity;
    const ca_vec<int> &block;
    const ca_vec<int> &isInObj;
    const ca_vec<int> &type;
	DependManager &dm;
   bool operator () (Var x, Var y) const {
    	if (type[x] == type[y]) {
    	    bool r;
    	    //assert((block[x] < block[y]) == dm.dependency(x,y));
    	    //assert((block[x] == block[y]) == dm.equiv(x,y));
    	    if (block[x] < block[y]) r = /*block[x] < block[y]*/dm.dependency(x,y);
    	    else r = false;
    	    if (/*block[x] == block[y]*/dm.equiv(x,y)) {
    		    r = isInObj[x] < isInObj[y];
    		    if (isInObj[x] == isInObj[y])
    		       r = (p_activity[x]+n_activity[x] > p_activity[y]+n_activity[y]);
    	    }
    	    return r;
    	} else return type[x] < type[y];
    }
    VarOrderLt(const ca_vec<double>&  pact, const ca_vec<double>&  nact, const ca_vec<int>& blo, const ca_vec<int>& iIO, const ca_vec<int> &ty, DependManager &d) : p_activity(pact), n_activity(nact), block(blo), isInObj(iIO), type(ty), dm(d) { }
};
struct InsertOrderLt {
  public:
    ca_vec<int> * settime;
    bool operator () (CoeVar x, CoeVar y) const {
    	if ((*settime)[var(x)] == (*settime)[var(y)]) {
            return (var(x) < var(y));
    	}
    	return  ((*settime)[var(x)] < (*settime)[var(y)]); // Ungesetzte stehen hinten. Wichtig fuer simplify1
    }
    InsertOrderLt() {}
    // SortOrderLt(ca_vec<int> * seti)  { settime = seti; }
    // Achtung! DieseOrdnung ist essentiell f殲 Constraint learning.
    // Ein Summand ist kleiner als ein anderer in einer Constraint, wenn die dazugeh嗷ige
    // Variable fr殄er als die des anderen fixiert wurde.
    // Falls beide gleich sind, wird gem刊 Block und dann gem刊 Index sortiert.
};
struct SearchOrderLt {
  public:
    const ca_vec<int> &block;
    bool operator () (CoeVar x, CoeVar y) const {
    	if (x.coef != y.coef) return x.coef > y.coef;
    	return (block[x.x >> 1] < block[y.x >> 1]); // im SAT sind alle Koeffizienten 1 => kleine Blocknummern erst
    }
    SearchOrderLt(const ca_vec<int>& blo) : block(blo) {}
    // Achtung! Diese Ordnung ist essentiell f殲 propagation.
    // Sortiert wird gemaess Groesse des Betrags der Koeffizenten
};

struct IndexLexOrderLt {
  public:
	CoeVar *data;
    bool operator () (int x, int y) const {
    	return data[x].x < data[y].x;
    }
    IndexLexOrderLt(CoeVar *a) { data = a;}
    // Sortiert wird nach Variablennamen
};

class SearchResult {
public:
	coef_t value;
	coef_t u_bound;
	SearchResult(coef_t v, coef_t b) {value = v; u_bound = b; }
	SearchResult() {}
};

class Heuristic {
	double a,b,a_,b_,y,y_;
	double sa,sb,sa_,sb_,sy,sy_;
	int trigger;
	int cnt;
	double random_seed;
	double alpha;
public:
	Heuristic() {
		a = b = a_ = b_ = y = y_ = 0.0;
		sa = sb = sa_ = sb_ = sy = sy_ = 0.0;
		trigger = cnt = 0;
		random_seed = 1357.0;
		alpha = 0.9;
	}
	double Prognose() { return a_ + b_; }
	double SuccessPrognose() { return sa_ + sb_ / 10.0; }
	void setDataPoint(double value, bool success) {
		if (value >= SuccessPrognose() - SuccessPrognose() / 3) success = true;
		if (value <= 0) {
			cerr << "?";
			//assert(0);
			return;
		}
		y = value;
		b = alpha*y + (1.0-alpha)*y_ - y_;
		y_ = alpha*y + (1.0-alpha)*y_;
		b_ = alpha*b + (1-alpha)*b_;
		a_ = y_ + (1-alpha)*b_;
		if (success) {
			sy = value;
			sb = alpha*sy + (1.0-alpha)*sy_ - sy_;
			sy_ = alpha*sy + (1.0-alpha)*sy_;
			sb_ = alpha*sb + (1-alpha)*sb_;
			sa_ = sy_ + (1-alpha)*sb_;
		}
		if (success) { trigger = 0; }
		else { trigger = trigger + 1; if (trigger > 20) trigger = 20; }
	}
	bool useH() {
		cnt++;
		//cerr << "t=" << trigger << "," << SuccessPrognose() << "-" << Prognose() << ";";
		if (trigger <= 2) return true;
		if (SuccessPrognose() - SuccessPrognose() / 10 < Prognose()) return true;
		if (irand(random_seed,trigger) == 0) return true;
		return false;
	}
	// Returns a random float 0 <= x < 1. Seed must never be 0.
    static inline double drand(double& seed) {
        seed *= 1389796;
        int q = (int)(seed / 2147483647);
        seed -= (double)q * 2147483647;
        return seed / 2147483647; }

    // Returns a random integer 0 <= x < size. Seed must never be 0.
    static inline uint64_t irand(double& seed, uint64_t size) {
        return (uint64_t)(drand(seed) * size); }
};

class QBPSolver {
public:
	class ConstraintPositionPair {
	  public:
		CRef cr;
		int32_t pos;
		union { coef_t best; int32_t watch1; } btch1;
		union { coef_t worst;int32_t watch2; } wtch2;
		ConstraintPositionPair(CRef lcr,int lpos,coef_t b, coef_t w) {
			cr = lcr; pos = lpos; btch1.best = b, wtch2.worst = w;
		}
		ConstraintPositionPair(CRef lcr,int lpos,int32_t w1, int32_t w2) {
			cr = lcr; pos = lpos; btch1.watch1 = w1, wtch2.watch2 = w2;
		}
		ConstraintPositionPair() {
		}
	};
	class ValueConstraintPair {
	  public:
		CRef cr;
	    Var  v;
	    uint32_t  pos;
	    ValueConstraintPair(CRef lcr, Var lv, int lpos) : cr(lcr), v(lv), pos(lpos) {}
	    ValueConstraintPair() {}
	};
	struct ASE {
	  public:
		CRef cr;
		uint32_t var;
		ASE(CRef _cr, int32_t _var) : cr(_cr), var(_var) {}
	};
	struct ScoInf {
	  public:
		double score;
		double cval;
		int32_t ix;
	};
	class uBndMmg {
	  public:
		coef_t ubs[2];
		int variables[2];
		int depth[2];
		bool lastAttemptWasSuccessful[2];
		void initUBds() {
			ubs[0] = ubs[1] = -((coef_t)(-((int64_t)1<<61)))/*n_infinity*/;
			variables[0] = variables[1]  = -1;
			depth[0] = depth[1] = -1;
			lastAttemptWasSuccessful[0] = lastAttemptWasSuccessful[1] = true;
		}
		void setU0(coef_t u0, int v) { ubs[0] = u0; variables[0] = v; }
		void setU1(coef_t u1, int v) { ubs[1] = u1; variables[1] = v; }
		coef_t getU0() { return ubs[0]; }
		coef_t getU1() { return ubs[1]; }
		int getDepth(int sel) { return depth[sel]; }
		bool getSuc(int sel) { return lastAttemptWasSuccessful[sel]; }
		void setDepth(int sel, int d) { depth[sel] = d; }
	    void setSuc(int sel, bool s) { lastAttemptWasSuccessful[sel] = s; }
		int getVar(int i01) { if (i01 == 0) return variables[0]; else return variables[1]; }
		coef_t getMax() { if (ubs[0] > ubs[1]) return ubs[0]; else return ubs[1]; }
		coef_t getNewUb(coef_t old_ub) { coef_t m = getMax(); if (m < old_ub) return m; else return old_ub; }
	};

	class stack_container {
	public:
		SearchResult result;
		int status;

	    int t;
	    int lsd;
		coef_t a,b;
		bool only_one;
		coef_t fatherval;
		int decvar;
		bool decpol;
		bool qex;
		bool alwstren;
		int father_ix;
		int sfather_ix;
		bool LimHorSrch;

	    int oob;
		int pick;
		int Lpick;
		coef_t v;
		coef_t local_ub;
		uBndMmg uBnds;
		int best_val;
		bool restart;
	    bool wot;
	};

	class Sstack {
	public:
		std::vector<stack_container> stack;
		int stack_pt;
		SearchResult result;
	    Sstack() {
	    	stack_pt = -1;
	    }
	    ~Sstack() {

	    }
	    SearchResult getResult() {
	    	stack_container &STACK = stack[stack_pt];
	    	return STACK.result;
	    }
	    int getStatus() {
	        stack_container &STACK = stack[stack_pt];
	    	return STACK.status;
	    }
	    void setStatus(int _status) {
	        stack_container &STACK = stack[stack_pt];
	    	STACK.status = _status;
	    }
	    bool empty() { return (stack_pt < 0); }
	    void up() { stack_pt--; stack.pop_back(); }
	    //SearchResult QBPSolver::alphabeta(bool only_one, coef_t fatherval, int decvar, bool decpol, bool qex, bool alwstren, int father_ix, int sfather_ix, bool LimHorSrch) {
	    void down(coef_t _n_inf, int _t, int _lsd, coef_t _a, coef_t _b, bool _only_one, coef_t _fatherval, int _decvar, bool _decpol, bool _qex, bool _alwstren, int _father_ix, int _sfather_ix, bool _LimHorSrch) {
	    	stack.resize(stack.size()+1);//push();
	        stack_pt++;
	        stack_container &STACK = stack[stack_pt];
	        STACK.status = START;
			STACK.t = _t;
			STACK.lsd = _lsd;
			STACK.a = _a;
			STACK.b = _b;
			STACK.only_one = _only_one;
			STACK.fatherval = _fatherval;
			STACK.decvar = _decvar;
			STACK.decpol = _decpol;
			STACK.qex = _qex;
			STACK.alwstren = _alwstren;
			STACK.father_ix = _father_ix;
			STACK.sfather_ix = _sfather_ix;
			STACK.LimHorSrch = _LimHorSrch;
			STACK.pick = -1;
			STACK.Lpick = -1;
			STACK.local_ub=-_n_inf;
			STACK.restart=false;
			STACK.wot=false;
			STACK.uBnds.initUBds();
	    }
	};

	struct BackJumpInfoStruct {
	  public:
		int32_t bj_level[2];
		int32_t bj_reason[2];
		coef_t bj_value[2];
		int32_t bj_sivar[2];
		void AddInfo(int v, int vx,int val_vx, int out_target_dec_level, int corrected_level, int declev, int eas, coef_t val, int r) {
			//return;
			if (eas == UNIV) {
				//cerr << "trage " << v << " ein:" << out_target_dec_level << " " << corrected_level << " " << declev << " " << vx << " " << bj_level[1-vx] << v << endl;
				bj_level[val_vx] = out_target_dec_level;
				bj_reason[val_vx] = r;
				bj_value[val_vx] = val;
				bj_sivar[val_vx] = v;
			}
		}
	};
	struct VarData { CRef reason; int level; };
	struct trailInfo { int var; int8_t value; };
//public:
private:
    static inline VarData mkVarData(CRef cr, int l){ VarData d = {cr, l}; return d; }
    inline extbool value(Var x)    const   { return assigns[x]; }
    inline extbool value(CoeVar p) const   { return assigns[var(p)]; }

    utils::QlpStageSolver QlpStSolve;

    int processNo;
    trailInfo* recvBuf;

    HTable *HT;
    HCTable *HTC;

	Sstack search_stack;
	std::vector< extSol::QpExternSolver::QpExtSolBase > rembase;
	bool downward;

	time_t           timeout;
    int				 discoveredNews;
    SearchOrderLt    SOL;
    InsertOrderLt    IOL;
    lpSortLt         lpSOL;
    antilpSortLt     antilpSOL;
    CliqueManager    CM;
    DependManager    DM;
    ConstraintWatcher CW;
    std::vector< std::pair<int,int> > constraintList;
    Heuristic        DynCutRegler;
    ca_vec<extbool>  assigns;
    coef_t           p_infinity;
    coef_t           n_infinity;
    coef_t           dont_know;
    ca_vec<int>      eas;
    ca_vec<int>      block;
    ca_vec<int>      converted_block;
    ca_vec<int>      type;
    ca_vec<int>      optSol;
    std::vector<double> fstStSol;
    std::vector< std::pair<int, double> > varDepot;
    int              maxBlock;
    int              maxLPBlock;
    int              maxLPStage;
    bool             hasObjective;
    bool             feasPhase;
    coef_t           objective_epsilon;
    int              objective_iterations;
    int              objective_budget;
    coef_t           objective_window_size;
    int              lp_decider_depth;
	coef_t           best_objective;
    ca_vec<int>      isInObj;
	ca_vec<bool>     isDirty;
	ca_vec<int>      dirtyLPvars;
    ca_vec<ScoInf>   scoreInfo;
    ca_vec<int>      scenario;
    ca_vec<int>      settime;
    ca_vec<VarData>  vardata;
    ca_vec<VarData>  fixdata;
    ca_vec<coef_t>   lowerBounds;
    ca_vec<coef_t>   upperBounds;
    coef_t           objOffset;
    ca_vec<int>      saveUs;
    std::vector<data::QpNum> solution;
    ca_vec<int>      sorter;
  	data::QpNum      lb,ub;
	std::vector<data::IndexedElement> bd_lhs;
	data::QpRhs::RatioSign bd_sign;
	data::QpNum      bd_rhs;
	algorithm::Algorithm::SolutionStatus status;
    int              num_vars;
    int              orgLPlines;
    ca_vec<bool>     level_finished;
    ca_vec<double>   p_activity;         // A heuristic measurement of the activity of a variable.
    ca_vec<double>   n_activity;         // A heuristic measurement of the activity of a variable.
    ca_vec<double>   p_pseudocost;       // A heuristic measurement of the activity of an lp variable.
    ca_vec<double>   n_pseudocost;       // A heuristic measurement of the activity of an lp variable.
    ca_vec<uint64_t> p_pseudocostCnt;
    ca_vec<uint64_t> n_pseudocostCnt;
    ca_vec<double>    inflEstim;
    ca_vec<int>      infEstimCnt;
    ca_vec<int> 	 prefDir;
    uint64_t         maxUniSucSumLen;
	uint64_t         maxUniSucCnt;
	uint64_t         maxUniCnt;
	bool             enforceReduction;
    bool             LPsortmode;
    bool			 ObjProbeMode;
    bool             objInverted;
    ca_vec<CoeVar>   add_tmp;
    ca_vec<CoeVar>   sub_tmp;
    ca_vec<ASE>      ana_stack;
    ca_vec<int>      ana_seen_stack;
    ca_vec<CRef>     constraint_seen_stack;
    ca_vec<int>      trail;      // Assignment stack; stores all assigments made in the order they were made.
    ca_vec<int8_t>   stack_val_ix;
    ca_vec<int8_t>   stack_val;
    ca_vec<bool>     stack_restart_ready;
    ca_vec<int>      stack_pick;
    ca_vec<coef_t>   stack_score;
    ca_vec<coef_t>   stack_a;
    ca_vec<coef_t>   stack_b;
    ca_vec<int8_t>   stack_save_val_ix;
    ca_vec<int8_t>   stack_save_val;
    ca_vec<bool>     stack_save_restart_ready;
    ca_vec<int>      stack_save_pick;
    ca_vec<coef_t>   stack_save_score;
    ca_vec<coef_t>   stack_save_a;
    ca_vec<coef_t>   stack_save_b;
    ca_vec<CRef>	 constraintRescue;
    ca_vec<int8_t>   killer;
    ca_vec<int>      changedUnivs;
    ca_vec<int8_t>   seen;
    ca_vec<int8_t>   seen2;
    ca_vec<int8_t>   seenProbe;
    ca_vec<int>      varbuf;
    ca_vec<int>      trail_lim;  // Separator indices for different decision levels in 'trail'.
	ca_vec<CoeVar>   in_learnt;
	ca_vec<CoeVar>   in_learnt0;
	ca_vec<CoeVar>   in_learnt1;
	ca_vec<CoeVar>   out_learnt;
	int              out_target_dec_level;
	int64_t          max_learnts;
    ca_vec<ValueConstraintPair>      propQ;
    ca_vec<int>      propQlimiter;
    ca_vec<ValueConstraintPair>      revImplQ;
    ca_vec<bool>     isRevImpl;
    ca_vec<BackJumpInfoStruct> BackJumpInfo;
    ca_vec<int> components;
    std::vector< std::vector<int> > varsOfComponents;
    void *yIF;
   ca_vec<int> trivialCut;
   int tooMuchUndef;
   int trivCut(int d, int val) {
	    ca_vec<CoeVar> in_learnt;
	    double numnegs = 0.0;
	    for (int i = 0; i < trail.size();i++) {
	    	if (vardata[trail[i]].reason == CRef_Undef) {
				CoeVar q = mkCoeVar(trail[i], 1.0, assigns[trail[i]] == 0 ? false : true);
				if (assigns[trail[i]] == 1) numnegs+=1.0;
				in_learnt.push(q);
	    	}
	    }
		CoeVar q = mkCoeVar(d, 1.0, val == 0 ? true : false);
		if (val == 0) numnegs+=1.0;
		in_learnt.push(q);

		bool aLC = addLearnConstraint(in_learnt, 1.0-numnegs, 0 /*konfliktvar, not used*/,true);
		if (aLC == false) return -1;
		return constraints.size()-1;
   }

	void QLPSTSOLVE_SOLVESTAGE(double a,unsigned int stage, algorithm::Algorithm::SolutionStatus& status, data::QpNum &lb,
			data::QpNum &ub, std::vector<data::QpNum>& solution,
			algorithm::Algorithm::SolutionCase SC, int maxSubProbToSolve= -1, int maxSimplexIt= -1);

	void QLPSTSOLVE_TIGHTEN_OBJ_FUNC_BOUND(unsigned int stage, const data::QpNum& newbound);
	void QLPSTSOLVE_WEAKEN_OBJ_FUNC_BOUND(unsigned int stage, const data::QpNum& newbound);

	ca_vec<ca_vec<ConstraintPositionPair> > VarsInConstraints;
    ca_vec<ca_vec<ConstraintPositionPair> > VaInCoBuffer;
    ca_vec<ca_vec<int> > litInClique;
    ca_vec<ca_vec<int> > unfixVar;
    ca_vec<int>          VIsFixed;
    ca_vec<int>          cnt_goms;
    ca_vec<int>          listOfGoms;
    ca_vec<int>          listOfGoms_lim;
	ca_vec<std::pair<unsigned int, unsigned int> > listOfEnteredCuts;
	ca_vec<std::pair<coef_t, uint64_t> > listOfEnteredCutHashs;
	std::vector<std::vector<data::IndexedElement> > listOfCutsLhs1;
	std::vector<data::QpNum> listOfCutsRhs1;
	std::vector<std::vector<data::IndexedElement> > listOfCutsLhs2;
	std::vector<data::QpNum> listOfCutsRhs2;
	std::vector<std::vector<data::IndexedElement> > listOfCutsLhs3;
	std::vector<data::QpNum> listOfCutsRhs3;
	std::vector<int> listOfCutsVars;
	ca_vec<int>      listOfCuts_lim;
	ca_vec<uint64_t>  brokenCnt;
    uint64_t         dec_vars; //Statistics
    int64_t          num_decs;
    int64_t          num_props;
    int64_t          num_conflicts;
    int64_t          num_firstStrong;
    int64_t          num_secondStrong;
	int64_t          old_num_conflicts;
    int64_t          it_starttime;
    int64_t          prev_it_duration;
    int64_t          num_learnts;
    int64_t          num_orgs;
    int64_t			 num_basic;
    int64_t          num_coevars;
    int64_t          used_mem;
    int              max_sd;
    int64_t          next_check;
    ca_vec<int64_t>  num_conflicts_per_level;
    ca_vec<int64_t>  num_leaves;
    int              next_level_inc;
    int              num_deps;
    bool             break_from_outside;
    bool             useDeep;
    bool             useRestarts;
    bool             useFastBendersBacktracking;
    bool             useWarmRestart;
    bool             useLoops;

    bool 			 learnDualCuts;
    bool 			 useGMI;
    bool			 useCover;
    bool 		     useLuP;
    bool		     useBendersBackJump;
    bool			 useFastFix;
    bool			 useImplications;
    bool			 useLimitedLP;
    bool			 useStrongBranching;
    bool			 useEarlyBackjump;
    bool			 useBestLevelExtraction;
    bool			 useUniversalBackjump;
    int				 maxBaCLevel;
    bool			 useAlphabeta;
    bool			 useMonotones;

    bool             BendersCutAlarm;
    bool             forbidHashing;
    bool             feasibilityOnly;
    int 		     trail_startlen;
    int 			 trail_last_len;
    int              info_level;
    double           random_seed;
    time_t           ini_time;
    coef_t           global_score;
    coef_t           global_dual_bound;
    int64_t          density_sum;
    int              density_num;
    int64_t          DLD_sum;
    int              DLD_num;
    ca_vec<bool>     DLCnt;
    int              m_rows;
    bool             end_by_empty_clause;

    double var_inc;
    double constraint_inc;

	uint64_t LPtim;
    unsigned int LPcnt;
    unsigned int LPcntSB;
    double SBavg;
    double SBsigEst;
    double SBcnt;
    double SBmaxDi;
    bool noMoreRestarts;

    algorithm::Algorithm::QlpSolution resolveDEP();
    data::Qlp *BinQlp();

    ConstraintAllocator  constraintallocator;
    ca_vec<CRef>  constraints;          // List of problem constraints.
    caHeap<VarOrderLt> order_heap;       // A priority queue of variables ordered with respect to the variable activity.

    double computeProgress(std::vector<data::QpNum> solution, std::vector<data::QpNum> solutionh7) {
        double sum=0.0;
        for (int k = 0; k< solution.size();k++) {
        	if (type[k] != BINARY) continue;
        	else {
        		double dist_k1 = fabs(solutionh7[k].asDouble()-0.5);
        		double dist_k2 = fabs(solution[k].asDouble()  -0.5);
        		if (dist_k1 > dist_k2) { // besser geworden
        			sum += (dist_k1-dist_k2);
        		} else { // schlechter geworden
        			sum += (dist_k1-dist_k2);
        		}
        	}
        }
        return sum;
    }
    double computeEfficacy(std::vector<data::IndexedElement>& lhs, data::QpNum & rhs, std::vector<data::QpNum> solution) {
        double ax=0.0;
        double a2=0.0;
        for (int k = 0; k< lhs.size();k++) {
        	ax += /*fabs*/(lhs[k].value.asDouble()) * solution[lhs[k].index].asDouble();
        	a2 += lhs[k].value.asDouble() * lhs[k].value.asDouble();
        }
        a2 = sqrt(a2);
        return fabs(ax - rhs.asDouble()) / (a2);
    }
    void addSymmetryConstraint(std::vector<std::pair<int, int> > &cList, std::vector<std::pair<int,double> > &cpropQ) {
	    ca_vec<CoeVar> in_learnt;
		std::vector<data::IndexedElement> in_cut4Hash;
		HTCutentry *HTCe;
		pair<coef_t, uint64_t> hash;
		if (info_level >= 2) cerr << "found " << cList.size() << " symmetry-breaking constraint(s)" << endl;
		int addedSBC=0;
		static int enter = 0;

    	//if (enter==0)
    	for (int i = 0; i < cList.size();i++) {
    		if (cList[i].second < 0) {
    			int tmp = -cList[i].second-1;
    			cList[i].second = cList[i].first;
    			cList[i].first = tmp;
    		} else if (cList[i].first < 0) {
    			if (cList[i].second == 0)
    				setFixed(-cList[i].first-1, 0, 0);
    			else
    				setFixed(-cList[i].first-1, 1, 0);
    			continue;
    		}
    		if (type[cList[i].first] != BINARY || type[cList[i].second] != BINARY) {
    			cerr << "Warning: prevented entering a continuous variable into conflict graph" << endl;
    			continue;
    		}
    		data::IndexedElement e;
    		in_learnt.clear();
    		in_cut4Hash.clear();
    		CoeVar q1 = mkCoeVar(cList[i].first, 1.0, true);
    		in_learnt.push(q1);
    		e.index = cList[i].first;
    		e.value = -1.0;
    		in_cut4Hash.push_back(e);
    		CoeVar q2 = mkCoeVar(cList[i].second, 1.0, false);
    		in_learnt.push(q2);
    		e.index = cList[i].second;
    		e.value = 1.0;
    		in_cut4Hash.push_back(e);
    		hash = HTC->computeHash(in_cut4Hash, 0.0);

    		if (feasPhase && !HTC->getEntry(&HTCe,hash.second, hash.first)) {
    			listOfEnteredCuts.push( QlpStSolve.addUserCut(maxLPStage, in_cut4Hash,
    					data::QpRhs::greaterThanOrEqual, 0.0) );
    			listOfEnteredCutHashs.push(hash);
    			HTC->setEntry(hash.first, hash.second);
    			//addOrgConstraint(in_learnt,0.0-LP_EPS,0);
        		bool aLC = addLearnConstraint(in_learnt, 0.0, 0 /*konfliktvar, not used*/,true);
        		if (aLC == false) cerr << "Error: could not learn symmetry-breaking constraint." << endl;
        		else {
        			//cout << "SYMMETRY x" << cList[i].first+1 << " <= x" << cList[i].second+1 << endl;
        			if(0)cout << "symmetry: " << (sign(in_learnt[0])?"-x":" x")<<(int)var(in_learnt[0])+1 << " + "
        					             << (sign(in_learnt[1])?"-x":" x")<<(int)var(in_learnt[1])+1 << " >= 0" << endl;
        			addedSBC++;
        			//enter++;
        		}
    		} else {
				 if (!CM.EdgeIsInContainer(q1.x^1,q2.x^1) && !CM.EdgeIsInContainer(q2.x^1,q1.x^1)) {
					 if ((q1.x^1) < (q2.x^1)) CM.AddEdge(q1.x^1,q2.x^1);//CM.AddEdge2Container(q.x,r.x);
					 else                     CM.AddEdge(q2.x^1,q1.x^1);//CM.AddEdge2Container(r.x,q.x);
				 }
    		}
    	}
		if (addedSBC > 0) cerr << "added " << addedSBC << " symmetry-breaking constraint(s)" << endl;
    }

    void makeAsnapshot(std::vector< std::pair<int,int> > &clist);
	void addSzenario(CRef conf, int conf_var, CRef conf_partner, ca_vec<CoeVar>& out_learnt, int& out_target_dec_level, ValueConstraintPair& out_vcp) ;
	bool scenAndLearn(bool adapt, bool learnClause, int retUnt, ca_vec<CoeVar>& out_learnt, int, int);
	bool findTargetLevel(ca_vec<CoeVar>& out_learnt, int& out_target_dec_level, ValueConstraintPair& out_vcp);
	bool getNextUIP(ca_vec<CoeVar>& in_learnt, int conf_var, ca_vec<CoeVar>& out_learnt);
	bool analyzeBendersFeasCut(CRef conf, int conf_var, ca_vec<CoeVar>& out_learnt, int& out_target_dec_level, ValueConstraintPair& out_vcp) ;
	void cliqueFix(int pick);
	bool deriveCombBC(ca_vec<CoeVar>& in_learnt, int conf_var, ca_vec<CoeVar>& out_learnt);
	int choosePolarity(int v);
    SearchResult computeLocalBackjump(coef_t a, int pick, coef_t &b, coef_t &score, ValueConstraintPair &out_vcp, bool &only_one, bool doFarJump, int &dec_level);
    SearchResult alphabeta(int t, int lsd, coef_t a, coef_t b, bool onlyone, coef_t nodeLPval, int decvar, bool decpol, bool allowQex, bool allowStrengthen, int father_ix, int sfather_ix, bool LimHorSrch);
    SearchResult alphabeta_loop(int t, int lsd, coef_t a, coef_t b, bool onlyone, coef_t nodeLPval, int decvar, bool decpol, bool allowQex, bool allowStrengthen, int father_ix, int sfather_ix, bool LimHorSrch);
    int alphabeta_step(QBPSolver &qmip, Sstack &search_stack, int status, SearchResult &result);
    //bool checkSolution(bool free_uni_av, bool blockvar_av, int best_cont_ix, int pick, double lpopt, int &lead, std::vector<data::QpNum> &solution);
    bool checkSolution(double a, bool free_uni_av, bool blockvar_av, int best_cont_ix, int pick, double lpopt, int &lead, std::vector<data::QpNum> &solution);
    bool checkRounding(double a, int pick, std::vector<data::QpNum> &solution, double lpopt, double &nlpopt);
    bool check();
    bool probe(int &max_progress_var, int &max_progress_pol, bool fastProbe=false);
    void buildCliques() {
    	static ca_vec<CoeVar> lhs;
    	static ca_vec<CoeVar> zero_forced;
    	static ca_vec<CoeVar> clique;
    	coef_t rhs;
    	int numCs=0;
    	for (int i = 0; i < constraints.size();i++) {
    		lhs.clear();
    		zero_forced.clear();
    		Constraint &C = constraintallocator[constraints[i]];
    		if (C.header.isSat) continue;
    		for (int j = 0; j < C.size(); j++) {
    			lhs.push(C[j]);
    		}
    		rhs = C.header.rhs;
    		sort(lhs, SOL);
    	    CM.extractCliqueFromLPconstraint(lhs, rhs, clique, zero_forced);
    	    if (zero_forced.size() > 0) {
    	    	if (USE_CLICK_EXTR_OUT) cerr << "ZERO_FORCED:" << endl;
    	    	if (USE_CLICK_EXTR_OUT) C.print(C, assigns, false);
    	    	if (USE_CLICK_EXTR_OUT) for (int k = 0; k < zero_forced.size();k++) cerr << "|" << (int)var(zero_forced[k]);
    	    	if (USE_CLICK_EXTR_OUT) cerr << endl;
    	    }
    	    if (clique.size() > 2) {
    	    	numCs++;
    	    	CM.addNativeClique(clique, nVars());
    	    	if (USE_CLICK_EXTR_OUT) cerr << "CLIQUE" << "(" << clique.size()<< "):" << endl;
    	    	if (USE_CLICK_EXTR_OUT) C.print(C, assigns, false);
    	    	for (int k = 0; k < clique.size();k++) {
    	    		Cli_entry *hte;
    	    		uint64_t hash = CM.cliques[CM.cliques.size()-1].getHashConstant(var(clique[k])+var(clique[k]));
    	    		if (CM.cliques[CM.cliques.size()-1].isInClique(&hte,hash,var(clique[k]))) {
    	    			CoeVar cova = hte->cova;
    	    			if (USE_CLICK_EXTR_OUT) {
    	    				if (sign(cova))
    	    					cerr << "|-" << (int)var(cova);
    	    				else
    	    					cerr << "|+" << (int)var(cova);
    	    			}
    	    		}
    	    	}
    	    	if (USE_CLICK_EXTR_OUT) cerr << endl;
    	    }
    	}
    	cerr << "detected " << numCs << " native Cliques" << endl;
    }

    int univIsMono(int va, bool feasPhase) {
    	int pp=0,nn=0;
       	for (int i=0; i < VarsInConstraints[va].size();i++) {
			Constraint &c = constraintallocator[VarsInConstraints[va][i].cr];
			if (c.header.learnt) continue;
			if (VarsInConstraints[va][i].cr != constraints[0]) {
				if (c.saveFeas(assigns)) continue;
			} else {
			  if (feasPhase) continue;
			}
			int pos = VarsInConstraints[va][i].pos;
			int s = sign(c[pos]);
			if (s) nn++;
			else pp++;
       	}
       	if (pp > 0 && nn > 0) return 0;
       	if (pp == 0) return 1;
       	return -1;
    }

    bool checkUimpact(int va, bool feasPhase, coef_t obj, data::QpNum *solution) {
    	for (int i=0; i < VarsInConstraints[va].size();i++) {
    		Constraint &c = constraintallocator[VarsInConstraints[va][i].cr];
    		if (c.header.learnt) continue;
    		//if (i > num_orgs) break;
    		if (VarsInConstraints[va][i].cr != constraints[0]) {
    			if (c.header.isSat) {
    				bool save=false;
    				for (int h=0; h < c.size();h++) {
    					if (assigns[var(c[h])] == extbool_Undef || (eas[var(c[h])] == UNIV && vardata[var(c[h])].level > vardata[va].level)) {
    						;
    					} else if (assigns[var(c[h])] != extbool_Undef && assigns[var(c[h])] == 1-sign(c[h]) &&
    							((eas[var(c[h])] == EXIST && block[var(c[h])] > block[va]) || (eas[var(c[h])] == UNIV && vardata[var(c[h])].level < vardata[va].level))) {
    						save = true;
    						break;
    					}
    				}
    				if (save) continue;
    				else return false;
    			} else {
    				coef_t rhs = c.header.rhs;
    				coef_t lhs_min = 0.0;
    				for (int h=0; h < c.size();h++) {
    					if (assigns[var(c[h])] == extbool_Undef && eas[var(c[h])] == EXIST && solution) {
    						if (sign(c[h])) lhs_min -= c[h].coef*solution[var(c[h])].asDouble();
    						else            lhs_min += c[h].coef*solution[var(c[h])].asDouble();
    					} else if (assigns[var(c[h])] == extbool_Undef || (eas[var(c[h])] == UNIV && vardata[var(c[h])].level > vardata[va].level)) {
    						if (sign(c[h])) lhs_min -= c[h].coef;
    					} else if (assigns[var(c[h])] != extbool_Undef && assigns[var(c[h])] == 1-sign(c[h]) &&
    							((eas[var(c[h])] == EXIST /*&& block[var(c[h])] > block[va]*/) || (eas[var(c[h])] == UNIV && vardata[var(c[h])].level < vardata[va].level))) {
    						if (!sign(c[h])) lhs_min += (coef_t)assigns[var(c[h])] * c[h].coef;
    						else lhs_min -= (coef_t)assigns[var(c[h])] * c[h].coef;
    					} else {
    						if (sign(c[h])) lhs_min -= c[h].coef;
    					}
    				}
    				if (lhs_min >= rhs) continue;
    				else return false;
    			}
    		} else {
    			if (feasPhase) continue;
    			else {
    				// lauf durch die Zielfunktion und prüfe auf >= obj
    				coef_t rhs = obj;
    				coef_t lhs_min = 0.0;
    				for (int h=0; h < c.size();h++) {
    					if (assigns[var(c[h])] == extbool_Undef && eas[var(c[h])] == EXIST && solution) {
    						if (sign(c[h])) lhs_min -= c[h].coef*solution[var(c[h])].asDouble();
    						else            lhs_min += c[h].coef*solution[var(c[h])].asDouble();
    					} else if (assigns[var(c[h])] == extbool_Undef || (eas[var(c[h])] == UNIV && vardata[var(c[h])].level > vardata[va].level)) {
    						if (sign(c[h])) lhs_min -= c[h].coef;
    					} else if (assigns[var(c[h])] != extbool_Undef && assigns[var(c[h])] == 1-sign(c[h]) &&
    							((eas[var(c[h])] == EXIST && block[var(c[h])] > block[va]) || (eas[var(c[h])] == UNIV && vardata[var(c[h])].level < vardata[va].level))) {
    						if (!sign(c[h])) lhs_min += (coef_t)assigns[var(c[h])] * c[h].coef;
    						else lhs_min -= (coef_t)assigns[var(c[h])] * c[h].coef;
    					} else {
    						if (sign(c[h])) lhs_min -= c[h].coef;
    					}
    				}
    				//assert(0);
    				//cerr << "$";
    				if (lhs_min >= rhs) {
    					//cerr << "+";
    					continue;
    				}
    				else return false;
    			}
    		}
    	}
    	//cerr << "ueberspringe x" << va << endl;
    	return true;
    }

    int crossUs(bool feasPhase, coef_t obj = ((coef_t)(-((int64_t)1<<61))), data::QpNum *solution = NULL) {
    	if (solution != NULL) return decisionLevel()+1;
    	if (feasPhase == false) return decisionLevel()+1;
    	int e = trail.size()-1;
    	int fUl;
    	for (;e > 0 && eas[trail[e]] != UNIV; e--)
    		;
    	if (e > 0)
    		fUl = vardata[trail[e]].level;
    	else fUl = 0;
    	e = trail.size()-1;
    	if (e > 0) {
    		bool found = false;
    		do {
    			found = false;
    			for (;e > 0 && eas[trail[e]] != UNIV; e--)
    				;
    			if (e <= 0) return 0;
    			assert(eas[trail[e]] == UNIV);
    			if (/*!*/checkUimpact(trail[e], feasPhase, obj, solution)) {
    				//cerr << "X" << vardata[trail[e]].level - fUl << endl;
    				//for (int zz=0;zz<trail.size();zz++) cerr << "z" << trail[zz] << " ";
    				//cerr << endl;
    				//return vardata[trail[e]].level;
    				int l = vardata[trail[e]].level;
    				//for (int l = level+1; l < decisionLevel(); l++) {
    				int8_t *val;
    				val = &stack_val[l<<1];
    				val[1] = val[0];
    				//}
    				found = true;
    			}
    			/*else*/
    			if (!found) varBumpActivity(trail[e], 10.0, assigns[trail[e]] == 1 ? true:false);
    			if (0&&!found) {
    				int8_t &val_ix = stack_val_ix[vardata[trail[e]].level];
    				if (val_ix > 0) found = true;
    			}
    			e--;
    			//else std::cerr << "X";
    		} while (e > 0 && found);
    	}
    	return 0;
    }

    inline void PROPQ_PUSH(int v, int p, ValueConstraintPair a) {
    	assert(type[(a).v>>1] == BINARY);
    	propQ.push(a);
    	//if (v==1523 && (a.v>>1)==1528) cerr << "folgere x1528 = " << 1-((a.v)&1) << endl;
    	//if ((v)==1523 && (p) ==0 && (((a).v>>1) == 1528) && (((a).v&1) == 0) ) assert(0);
    }
    inline void PROPQ_PUSH(ValueConstraintPair a) {
    	assert(type[(a).v>>1] == BINARY);
    	propQ.push(a);
    	//if (v==1523 && (a.v>>1)==1528) cerr << "folgere x1528 = " << 1-((a.v)&1) << endl;
    	//if ((v)==1523 && (p) ==0 && (((a).v>>1) == 1528) && (((a).v&1) == 0) ) assert(0);
    }

    inline void insertVarOrder(Var x) {
        if (!order_heap.inHeap(x) /*&& decision[x]*/) {
        	order_heap.insert(x);
        }
    }
    int extractPick() {
    	ca_vec<int> rem;
    	int x=0;
		return order_heap.extractMin();
    	//for (int i=0;i < nVars(); i++)
    	//	if (assigns[i] == extbool_Undef) x++;
    	//assert(x == DM.sumAllRates());
    	do {
			if (order_heap.empty()) {
				while (rem.size() > 0) {
					order_heap.insert(rem[rem.size()-1]);
					DM.increaseFillrate(rem[rem.size()-1]);
					rem.pop();
				}
				return -1;
			}
			x = order_heap.extractMin();
			if (assigns[x] == extbool_Undef) DM.decreaseFillrate(x);
			//cerr << "VALID:(" << x << ")" << DM.isValid(x) << ":"<< (int)assigns[x]<<  endl;
			if (assigns[x] == extbool_Undef && DM.isValid(x) ) {
				while (rem.size() > 0) {
					order_heap.insert(rem[rem.size()-1]);
					DM.increaseFillrate(rem[rem.size()-1]);
					rem.pop();
				}
				DM.increaseFillrate(x);
				return x;
			} else {
				if (assigns[x] == extbool_Undef) rem.push(x);
				continue;
			}
    	} while (1);
    	return -1;
    }
	void returnUntil(int level);
	void hs_PurgeTrail(int l, int dl);
	void PurgeTrail(int l, int dl);
	bool simplify1(ca_vec<CoeVar>& ps, bool SAT);
	bool simplify1(ca_vec<CoeVar>& ps, bool SAT, bool useRed, bool &usedRed);
	bool VarsInConstraintsAreWellFormed();
	bool ConstraintIsWellFormed(Constraint &c);
	int fastMergeIsUsefulTest(Constraint &c1, Constraint &c2, int conf_var);
	void strengthenConstraint(Constraint &c, int p);
	bool merge(Constraint &c1, Constraint &c2, int conf_var, ca_vec<CoeVar>& out_merged, bool isSAT=true);
	void updateStageSolver(unsigned int stage, unsigned int from, unsigned int to);
    int computeDLD(ca_vec<CoeVar>& lhs);
    int computeDLD(std::vector<data::IndexedElement>& lhs);
    bool isInstable(std::vector<data::IndexedElement>& lhs) {
    	 if (lhs.size() < 1) return true;
    	 double minco=fabs(lhs[0].value.asDouble());
    	 double maxco=fabs(lhs[0].value.asDouble());
    	 for (int i = 1; i < lhs.size();i++) {
    		 if (fabs(lhs[i].value.asDouble()) == 0.0) continue;
    		 if (fabs(lhs[i].value.asDouble()) < minco) minco = fabs(lhs[i].value.asDouble());
    		 if (fabs(lhs[i].value.asDouble()) > maxco) maxco = fabs(lhs[i].value.asDouble());
    	 }
    	 if (maxco / minco > 10000.0) return true;
    	 return false;

    }
	inline bool isZero(double x, double epsZero = 1e-20) {
		return (fabs(x) <= epsZero);
	}
	inline bool isOne(double x, double epsZero = 1e-20) {
		return (fabs(x) >= 1.0-epsZero);
	}
	coef_t buyDualBound(int trail_start, coef_t a, coef_t b, int remainD);
	coef_t buyDualRootBound(int trail_start, coef_t a, coef_t b, int remainD);
    void printBounds(int dpt) {
        stack_container *s;
        cerr << "Upcoming Bounds me:   ";
        for (int i = 0; i < search_stack.stack_pt && i < dpt; i++ ) {
                s = &search_stack.stack[i];
                int8_t *val;
                val = &stack_val[(i+1)<<1];
                int8_t &val_ix = stack_val_ix[i+1];
                int vx = 1-val_ix;
                if (val[0] == val[1]) continue;
				if (val[val_ix]==0) {
					if (s->uBnds.getU0() > n_infinity) std::cerr << s->uBnds.getU0() << "(" << i+1 << ") ";
					else std::cerr << " -inf" << "(" << i+1 << ") ";
				} else {
					if (s->uBnds.getU1() > n_infinity) std::cerr << s->uBnds.getU1() << "(" << i+1 << ") ";
					else std::cerr << " -inf" << "(" << i+1 << ") ";
				}
        }
        std::cerr  << std::endl;
        cerr << "Upcoming Bounds oth:  ";
        for (int i = 0; i < search_stack.stack_pt && i < dpt; i++ ) {
                s = &search_stack.stack[i];
                int8_t *val;
                val = &stack_val[(i+1)<<1];
                int8_t &val_ix = stack_val_ix[i+1];
                int vx = 1-val_ix;
                if (val[0] == val[1]) continue;
				if (val[vx]==0) {
					if (s->uBnds.getU0() > n_infinity) std::cerr << s->uBnds.getU0() << "(" << i+1 << ","<< s->uBnds.getVar(0)<< ") ";
					else std::cerr << " -inf" << "(" << i+1 << ") ";
				} else {
					if (s->uBnds.getU1() > n_infinity) std::cerr << s->uBnds.getU1() << "(" << i+1 << ","<< s->uBnds.getVar(1)<< ") ";
					else std::cerr << " -inf" << "(" << i+1 << ") ";
				}
        }
        std::cerr  << std::endl;
        cerr << "Upcoming Bounds LB: ";
        for (int i = 0; i < search_stack.stack_pt && i < dpt; i++ ) {
                s = &search_stack.stack[i];
                int8_t *val;
                val = &stack_val[(i+1)<<1];
                int8_t &val_ix = stack_val_ix[i+1];
                int vx = 1-val_ix;
                if (val[0] == val[1]) continue;
				if (s->local_ub > n_infinity) std::cerr << s->local_ub << "(" << i+1 << ") ";
				else std::cerr << " -inf" << "(" << i+1 << ") ";
        }
        std::cerr  << std::endl;
    }

    void adjustBounds_loop(int d, coef_t b, double &theMax, int &theMaxIx) {
        stack_container *s;
        for (int i = d; i >= 1; i-- ) {
                if (level_finished[i]) return;
                if (level_finished[i+1]) return;
                if (i == 0) break;
                coef_t &score = stack_score[i-1+1];
                s = &search_stack.stack[i-1];
                int8_t *val;
                val = &stack_val[(i-1+1)<<1];
                int8_t &val_ix = stack_val_ix[i-1+1];
                if (s->Lpick < 0) cerr << "-";
        	    assert(s->Lpick >= 0 && s->Lpick < nVars());
                if (0&&i==search_stack.stack_pt) {
					/*if (val_ix==0) {
									if (val[val_ix] == 0)
											std::cerr << 0 << "(x0s0s1vb," << s->ubs[0] << "," << s->ubs[1] << "," << v << "," << b <<") ";
									else
											std::cerr << 0 << "(x1s0s1vb," << s->ubs[1] << "," << s->ubs[1] << "," << v << "," << b<<") ";
					} else {
									if (val[val_ix] == 0)
											std::cerr << 1 << "(x0s0s1vb," << s->ubs[0] << "," << s->ubs[1] << "," << v << "," << b<<") ";
									else
											std::cerr << 1 << "(x1s0s1vb," << s->ubs[1] << "," << s->ubs[1] << "," << v << "," << b<<") ";
					}*/
                } else {
					if (val_ix==0) {
									if (val[val_ix] == 0) {
										  //std::cerr << 0<<i << "V(x0s0s1B," << s->ubs[0] << "," << s->ubs[1] << "," << s->local_ub << ") ";
										  if (b < s->uBnds.getU0()) s->uBnds.setU0(b, s->uBnds.getVar(0));
										  coef_t m = s->uBnds.getU0();
										  if (s->uBnds.getU1() > m) m = s->uBnds.getU1();
										  if (m < s->local_ub) s->local_ub = m;
										  if (val_ix == 0) {
											  if (val[val_ix] == 0) {
												  if (theMax < s->uBnds.getU1()) {
													  theMax = s->uBnds.getU1();
													  theMaxIx = i-1;
												  }
											  } else {
												  if (theMax < s->uBnds.getU0()) {
													  theMax = s->uBnds.getU0();
													  theMaxIx = i-1;
												  }
											  }
										  }
										  b = s->local_ub;
										  if (i == 1 && theMax < global_dual_bound) {
											  	global_dual_bound = theMax;
												coef_t gap;
												gap = abs(100.0*(-global_dual_bound + global_score) / (abs(global_score)+1e-10) );
												if (!objInverted) {
													cerr << "\n+++++ " << decisionLevel() << " ++++u score: " << -global_score << " | time: " << time(NULL) - ini_time << " | "
														<< " dual: "<< -global_dual_bound << " gap=" << gap << "%";
												} else {
													cerr << "\n+++++ " << decisionLevel() << " ++++u score: " << global_score << " | time: " << time(NULL) - ini_time << " | "
														<< " dual: "<< global_dual_bound << " gap=" << gap << "%";
												}
												if (info_level >= 2) cerr
													<< ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
												cerr << endl;
												if (info_level >= 2) printBounds(10);
												if (gap < SOLGAP) break_from_outside = true;
											    //cerr << "A) improved dual bound to " << global_dual_bound << endl;
											    //printBounds(10);
											    discoveredNews = 0;
										  }
										  //std::cerr << s->local_ub << "(" << decisionLevel() << ")" << " ";
										  //std::cerr << 0<<i << "H(x0s0s1B," << s->ubs[0] << "," << s->ubs[1] << "," << s->local_ub << ") ";
									} else {
										  //std::cerr << 0<<i << "V(x1s0s1B," << s->ubs[1] << "," << s->ubs[1] << "," << s->local_ub << ") ";
										  if (b < s->uBnds.getU1()) s->uBnds.setU1(b, s->uBnds.getVar(1));
										  coef_t m = s->uBnds.getU0();
										  if (s->uBnds.getU1() > m) m = s->uBnds.getU1();
										  if (m < s->local_ub) s->local_ub = m;
										  if (val_ix == 0) {
											  if (val[val_ix] == 0) {
												  if (theMax < s->uBnds.getU1()) {
													  theMax = s->uBnds.getU1();
													  theMaxIx = i-1;
												  }
											  } else {
												  if (theMax < s->uBnds.getU0()) {
													  theMax = s->uBnds.getU0();
													  theMaxIx = i-1;
												  }
											  }
										  }
										  b = s->local_ub;
										  if (i == 1 && theMax < global_dual_bound) {
											  global_dual_bound = theMax;
												coef_t gap;
												gap = abs(100.0*(-global_dual_bound + global_score) / (abs(global_score)+1e-10) );
												if (!objInverted) {
													cerr << "\n+++++ " << decisionLevel() << " ++++u score: " << -global_score << " | time: " << time(NULL) - ini_time << " | "
														<< " dual: "<< -global_dual_bound << " gap=" << gap << "%";
												} else {
													cerr << "\n+++++ " << decisionLevel() << " ++++u score: " << global_score << " | time: " << time(NULL) - ini_time << " | "
														<< " dual: "<< global_dual_bound << " gap=" << gap << "%";
												}
												if (info_level >= 2) cerr
													<< ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
												cerr << endl;
												if (info_level >= 2) printBounds(10);
												if (gap < SOLGAP) break_from_outside = true;
											  //cerr << "B) improved dual bound to " << global_dual_bound << endl;
											  //printBounds(10);
											  discoveredNews = 0;
										  }
										  //std::cerr << s->local_ub << "(" << decisionLevel() << ")" << " ";
										  //std::cerr << 0<<i << "H(x1s0s1B," << s->ubs[1] << "," << s->ubs[1] << "," << s->local_ub << ") ";
									}
					} else if (val[val_ix] != val[1-val_ix]) {
									if (val[val_ix] == 0) {
										  //std::cerr << 1<<i << "V(x0s0s1B," << s->ubs[0] << "," << s->ubs[1] << "," << s->local_ub << ") ";
										  if (b < s->uBnds.getU0()) s->uBnds.setU0(b, s->uBnds.getVar(0));
										  coef_t m = s->uBnds.getU0();
										  if (s->uBnds.getU1() > m) m = s->uBnds.getU1();
										  if (m < s->local_ub) s->local_ub = m;
										  if (val_ix == 0) {
											  assert(0);
											  if (val[val_ix] == 0) {
												  if (theMax < s->uBnds.getU1()) {
													  theMax = s->uBnds.getU1();
													  theMaxIx = i-1;
												  }
											  } else {
												  if (theMax < s->uBnds.getU0()) {
													  theMax = s->uBnds.getU0();
													  theMaxIx = i-1;
												  }
											  }
										  }
										  b = s->local_ub;
										  if (i == 1 && theMax < global_dual_bound) {
											  global_dual_bound = theMax;
												coef_t gap;
												gap = abs(100.0*(-global_dual_bound + global_score) / (abs(global_score)+1e-10) );
												if (!objInverted) {
													cerr << "\n+++++ " << decisionLevel() << " ++++u score: " << -global_score << " | time: " << time(NULL) - ini_time << " | "
														<< " dual: "<< -global_dual_bound << " gap=" << gap << "%";
												} else {
													cerr << "\n+++++ " << decisionLevel() << " ++++u score: " << global_score << " | time: " << time(NULL) - ini_time << " | "
														<< " dual: "<< global_dual_bound << " gap=" << gap << "%";
												}
												if (info_level >= 2) cerr
													<< ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
												cerr << endl;
												if (info_level >= 2) printBounds(10);
												if (gap < SOLGAP) break_from_outside = true;
											  //cerr << "C) improved dual bound to " << global_dual_bound << endl;
											  //printBounds(10);
											  discoveredNews = 0;
										  }
										  //std::cerr << s->local_ub << "(" << decisionLevel() << ")" << " ";
										  //std::cerr << 1<<i << "H(x0s0s1B," << s->ubs[0] << "," << s->ubs[1] << "," << s->local_ub << ") ";
									} else {
										  //std::cerr << 1<<i << "V(x1s0s1B," << s->ubs[1] << "," << s->ubs[1] << "," << s->local_ub << ") ";
										  if (b < s->uBnds.getU1()) s->uBnds.setU1(b, s->uBnds.getVar(1));
										  coef_t m = s->uBnds.getU0();
										  if (s->uBnds.getU1() > m) m = s->uBnds.getU1();
										  if (m < s->local_ub) s->local_ub = m;
										  if (val_ix == 0) {
											  if (val[val_ix] == 0) {
												  if (theMax < s->uBnds.getU1()) {
													  theMax = s->uBnds.getU1();
													  theMaxIx = i-1;
												  }
											  } else {
												  if (theMax < s->uBnds.getU0()) {
													  theMax = s->uBnds.getU0();
													  theMaxIx = i-1;
												  }
											  }
										  }
										  b = s->local_ub;
										  if (i == 1 && theMax < global_dual_bound) {
											  global_dual_bound = theMax;
												coef_t gap;
												gap = abs(100.0*(-global_dual_bound + global_score) / (abs(global_score)+1e-10) );
												if (!objInverted) {
													cerr << "\n+++++ " << decisionLevel() << " ++++u score: " << -global_score << " | time: " << time(NULL) - ini_time << " | "
														<< " dual: "<< -global_dual_bound << " gap=" << gap << "%";
												} else {
													cerr << "\n+++++ " << decisionLevel() << " ++++u score: " << global_score << " | time: " << time(NULL) - ini_time << " | "
														<< " dual: "<< global_dual_bound << " gap=" << gap << "%";
												}
												if (info_level >= 2) cerr
													<< ": DLD=" << DLD_sum / (DLD_num+1) << " density=" << density_sum / (density_num+1) << " #" << constraints.size() << " " << (int)val[0]<<(int)val[1] << ((int)val_ix);
												cerr << endl;
												if (info_level >= 2) printBounds(10);
												if (gap < SOLGAP) break_from_outside = true;
											  //cerr << "D) improved dual bound to " << global_dual_bound << endl;
											  //printBounds(10);
											  discoveredNews = 0;
										  }
										  //std::cerr << s->local_ub << "(" << decisionLevel() << ")" << " ";
										  //std::cerr << 1<<i << "H(x1s0s1B," << s->ubs[1] << "," << s->ubs[1] << "," << s->local_ub << ") ";
									}
					}
                }
        }
    }
    void adjustBounds(double v, double b) {
    	//return;
        stack_container *s;
        int stackpt = search_stack.stack_pt;
        if ((processNo & 1) > 0) return;
    	//if (b==n_infinity) return;
        if (feasPhase || level_finished[search_stack.stack_pt+1]) return;
        //if (v==n_infinity) return;
        //if (decisionLevel() > 60) return;

        double theMax = b;
        int theMaxIx = -1;
        //cerr << search_stack.stack_pt << "," << decisionLevel() << endl;

        if (break_from_outside || propQ.size() > 0 || revImplQ.size() > 0) return;

		adjustBounds_loop(stackpt,b,theMax,theMaxIx);
		return;
        do {
			if (theMaxIx > -1 && theMaxIx < log2((double)nVars())) {
				s = &search_stack.stack[theMaxIx];
                if (type[s->Lpick] == EXIST) {
					int trail_start = trail.size()-1;
					coef_t &score = stack_score[theMaxIx+1];
					int8_t *val;
					val = &stack_val[(theMaxIx+1)<<1];
					int8_t &val_ix = stack_val_ix[theMaxIx+1];

					while (trail_start > 0 && vardata[trail[trail_start]].level > theMaxIx)
						trail_start--;
					if (info_level & 2) cerr << "trail start?"<< trail_start << " und trail.size = " << trail.size() << "lub=" << s->local_ub << " theMax=" << theMax << " theMaxIx=" << theMaxIx << endl;
					if ((info_level & 2)  && trail_start == 1) {
						cerr << "Auf Trail ist ";
						for (int fg=0;vardata[trail[fg]].level <= theMaxIx;fg++) cerr << trail[fg] << "(" << vardata[trail[fg]].level << "), ";
						cerr << endl;
						cerr << "pick auf L0 ist " << search_stack.stack[0].pick << " with " << search_stack.stack[0].uBnds.getU0() << "," << search_stack.stack[0].uBnds.getU1() << "," << search_stack.stack[0].local_ub << endl;
						cerr << "pick auf L1 ist " << search_stack.stack[1].pick << " with " << search_stack.stack[1].uBnds.getU0() << "," << search_stack.stack[1].uBnds.getU1() << "," << search_stack.stack[1].local_ub << endl;
						cerr << "pick auf L2 ist " << search_stack.stack[2].pick << " with " << search_stack.stack[2].uBnds.getU0() << "," << search_stack.stack[2].uBnds.getU1() << "," << search_stack.stack[2].local_ub << endl;
					}
					coef_t remtheMax = theMax;
					coef_t r = buyDualBound(trail_start, score, theMax, theMaxIx);
					stackpt = trail_start;
					coef_t lub = s->local_ub;
	    			adjustBounds_loop(stackpt,-n_infinity,theMax,theMaxIx);
	    			if (info_level & 2) cerr << "READJUST: max-r=" << theMax-r << " remmax-r=" << remtheMax-r << " r=" << r << endl;
	    			//if (theMaxIx  == 1) { char c; cin >>c; }
                }
			}
        } while(0);
		int trail_start = trail.size()-1;
		coef_t &score = stack_score[1];
		while (trail_start > 0 && vardata[trail[trail_start]].level > theMaxIx)
			trail_start--;
		if (info_level & 2) cerr << "trail start?"<< trail_start << " und trail.size = " << trail.size() << "lub=" << s->local_ub << " theMax=" << theMax << " theMaxIx=" << theMaxIx << endl;
        if(0) coef_t r = buyDualRootBound(trail_start, score, theMax, theMaxIx);
        //std::cerr << " |" << v << std::endl;

    }

    inline SearchResult _SearchResult(coef_t v, coef_t b) {
	  if (0 && global_score < 5 && !feasPhase && isOnTrack() && break_from_outside == false) assert(0);
	  checkHeap(-1);
	  varDepot.clear();
	  return SearchResult(v,b);
	}

	inline int _StepResult(stack_container &STACK, coef_t v, coef_t b) {
	  varDepot.clear();
	  assert(rembase.size() > decisionLevel());
	  if (0&&level_finished[decisionLevel()]) {
		  v = dont_know;
		  b = -n_infinity;
	  }
	  rembase[decisionLevel()].variables.clear();
	  downward = false;
	  adjustBounds(v,b);
	  STACK.result = SearchResult(v,b);
	  moveUp(v, b, STACK.status);
	  STACK.status = FINISHED;
	  return FINISHED;
	}
	void SATAddWatcher(Constraint &c, ca_vec<CoeVar> &ps, int cr, int v, int pos);
	void SATAddWatcher(Constraint &c, int cr, int v, int pos);
    void SATswapOut(int va, Constraint &c);
    void SwapOut(int va, Constraint &c);
    void SwapAllIn(int va);

public:
    coef_t search(int t, void *ifc);
    coef_t searchDual(int t, void *ifc);
    coef_t searchPrimal(int t, void *ifc);
	bool analyze(CRef conf, int conf_var, CRef conf_partner, ca_vec<CoeVar>& out_learnt, int& out_target_dec_level, ValueConstraintPair& out_vcp, bool learnClause=true);
	bool analyze4All(CRef conf, int conf_var, ca_vec<CoeVar>& out_learnt, int& out_target_dec_level, ValueConstraintPair& out_vcp) ;
    bool propagate(CRef& confl, int& confl_var, CRef &confl_partner, bool probemode, bool exist_relax_mode, int max_props);
    bool hs_propagate(CRef& confl, int& confl_var, CRef &confl_partner, bool probemode, bool exist_relax_mode, int max_props);
	bool fastBendersAnalysis(coef_t value, coef_t rhs, ca_vec<CoeVar>& in_learnt, int conf_var, ca_vec<CoeVar>& out_learnt, int& out_target_dec_level, ValueConstraintPair& out_vcp, bool lernClause) ;
    bool isPow2(int X) {
      int cnt1 = 0;
      if (X <= 0) return false;
      while ( X > 0 ) {
	if (X&1) cnt1++;
	X = (X >> 1);
      }
      if (cnt1 != 1) return false;
      else return true;
    }
    inline void      increaseDecisionLevel() { trail_lim.push(trail.size()); }
    inline void      decreaseDecisionLevel() { trail_lim.pop(); }
    inline int       decisionLevel ()  const   { return trail_lim.size(); }
    inline int		 registeredLevel() const   {
    	if (trail_lim.size()==0) return 0;
    	else if (trail_lim.size()==1) return 0;
    	else return vardata[trail[trail_lim[trail_lim.size()-1]-1]].level;
    }
    inline int       getVardataLevel(int v) const {
    	if (vardata[v].reason == CRef_Undef) return vardata[v].level;
	    else return vardata[v].level-1;
    }
    inline int       getFixdataLevel(int v) const {
    	return fixdata[v].level;
    }

    inline void initFixed(int d) {
	    VIsFixed[d] = extbool_Undef;
		fixdata[d].level = -4;
		fixdata[d].reason = CRef_Undef;
		if (type[d] == BINARY) {
			QlpStSolve.setVariableLB(d,0,type.getData());
			QlpStSolve.setVariableUB(d,1,type.getData());
		} else {
			QlpStSolve.setVariableLB(d,lowerBounds[d],NULL);
			QlpStSolve.setVariableUB(d,upperBounds[d],NULL);
		}
		if (!isDirty[d]) {
			dirtyLPvars.push(d);
			isDirty[d] = true;
		}
    }

    inline void setFixed(int d, int val, int lev, int reas) {
    	//if (val != extbool_Undef) return;
    	//return;
    	//if (reas == CRef_Undef) return;
    	if (eas[d] != UNIV || val == extbool_Undef) {
    		//assert(val==extbool_Undef || (lev == 0 && reas==CRef_Undef));
		    //if (val != extbool_Undef) cerr << "setfix: Set fixed: x" << d << "=" << val << " auf level " << lev << "und Reason=" <<  reas << endl;
    		bool iot = isOnTrack();
    		VIsFixed[d] = val;
			fixdata[d].level = lev;
			fixdata[d].reason = reas;
			//return;
            if (lev == 0) discoveredNews += 2;
			if (lev<0 && val != extbool_Undef) {
				if (info_level >= 2) cerr << "Warning: setFixed -- level=" << lev << ", value=" << val << endl;
			}
            if (reas != CRef_Undef || val == extbool_Undef) {
				if (val != extbool_Undef) {
					QlpStSolve.setVariableFixation(d,val,type.getData());
					if (iot && val != optSol[d]) cerr << "have fixed var " << d << " to " << val << " on level " << lev << endl;
					//if (vardata[lev].reason == CRef_Undef) unfixVar[vardata[lev].level].push(d);
					//else unfixVar[vardata[lev].level-1].push(d);
				} else {
					QlpStSolve.setVariableLB(d,lowerBounds[d],NULL);
					QlpStSolve.setVariableUB(d,upperBounds[d],NULL);
				}
				if (!isDirty[d]) {
					dirtyLPvars.push(d);
					isDirty[d] = true;
				}
            }
            assert(!iot || isOnTrack());
    	}
    }
    inline void setFixed(int d, int val, int l) {
     	//return;
 		bool iot = isOnTrack();
 		int r;
 		if (0&&tooMuchUndef > 2) { r = trivCut(d,val); tooMuchUndef = 0; }
 		else r = -1;
 	    VIsFixed[d] = val;
 		fixdata[d].level = l;
 		if (r == -1) fixdata[d].reason = CRef_Undef;
 		else fixdata[d].reason = constraints[r];
 		if (iot && val != optSol[d]) cerr << "have fixed var " << d << " to " << val << " on level " << l << endl;
         assert(!iot || isOnTrack());
     }
     inline void setFixed(int d, int val) {
     	//return;
 		bool iot = isOnTrack();
 	    VIsFixed[d] = val;
 		fixdata[d].level = -4;
 		fixdata[d].reason = CRef_Undef;
 		if (iot && val != optSol[d]) cerr << "have fixed var " << d << " to " << val << " on level " << -4 << endl;
         assert(!iot || isOnTrack());
     	//assert(0);
     }
     inline int getFixed(int d) {
     	//return extbool_Undef;
     	//assert(VIsFixed[d] == extbool_Undef);
     	return VIsFixed[d];
     }
     inline bool isFixed(int d) {
     	//return false;
     	if (VIsFixed[d] == extbool_Undef) return false;
     	else return true;
     }
     inline void addFixed(int lev, int var) {
     	if (lev > decisionLevel()+2) assert(0);
     	unfixVar[lev].push(var);
     }
     inline void      resolveFixed(int dl, bool cutsAsWell = true) {
     	//cerr << "ResoFi-" << decisionLevel() << "," << dl << "|";
         //cerr << "ResoFi-" << decisionLevel() << "," << dl << "|";
     	if (cutsAsWell) {
 			while(listOfGoms.size() > listOfGoms_lim[dl]) {
 					cnt_goms[listOfGoms[listOfGoms.size()-1]]--;
 					listOfGoms.pop();
 			}
 			if(listOfEnteredCuts.size() > listOfCuts_lim[dl]) {
 					QlpStSolve.removeUserCutsFromCut(listOfEnteredCuts[listOfCuts_lim[dl]]);
 			}
 			while(listOfEnteredCuts.size() > listOfCuts_lim[dl]) {
 					listOfEnteredCuts.pop();
 					int li = listOfEnteredCutHashs.size()-1;
 					HTC->delEntry(listOfEnteredCutHashs[li].first, listOfEnteredCutHashs[li].second);
 					listOfEnteredCutHashs.pop();
 			}
     	}
         while(unfixVar[dl].size()>0) {
               QlpStSolve.setVariableLB(unfixVar[dl][unfixVar[dl].size()-1],lowerBounds[unfixVar[dl][unfixVar[dl].size()-1]], type.getData());
               QlpStSolve.setVariableUB(unfixVar[dl][unfixVar[dl].size()-1],upperBounds[unfixVar[dl][unfixVar[dl].size()-1]], type.getData());
               if (!isDirty[unfixVar[dl][unfixVar[dl].size()-1]]) {
                   dirtyLPvars.push(unfixVar[dl][unfixVar[dl].size()-1]);
                   isDirty[unfixVar[dl][unfixVar[dl].size()-1]] = true;
               }
               //if (isFixed(unfixVar[dl][unfixVar[dl].size()-1])) cerr << "Setze fix zurueck. x" << unfixVar[dl][unfixVar[dl].size()-1] << "auf level " << dl << endl;
                   setFixed( unfixVar[dl][unfixVar[dl].size()-1], extbool_Undef, -1, CRef_Undef);
                   unfixVar[dl].pop();
         }
         while(unfixVar[dl+1].size()>0) {
               QlpStSolve.setVariableLB(unfixVar[dl+1][unfixVar[dl+1].size()-1],lowerBounds[unfixVar[dl+1][unfixVar[dl+1].size()-1]], type.getData());
               QlpStSolve.setVariableUB(unfixVar[dl+1][unfixVar[dl+1].size()-1],upperBounds[unfixVar[dl+1][unfixVar[dl+1].size()-1]], type.getData());
               if (!isDirty[unfixVar[dl+1][unfixVar[dl+1].size()-1]]) {
                   dirtyLPvars.push(unfixVar[dl+1][unfixVar[dl+1].size()-1]);
                   isDirty[unfixVar[dl+1][unfixVar[dl+1].size()-1]] = true;
               }
               //if (isFixed(unfixVar[dl+1][unfixVar[dl+1].size()-1])) cerr << "Setze fix2 zurueck. x" << unfixVar[dl][unfixVar[dl].size()-1] << "auf level " << dl << endl;
                   setFixed( unfixVar[dl+1][unfixVar[dl+1].size()-1], extbool_Undef/*, 0, CRef_Undef*/);
                   unfixVar[dl+1].pop();
                   //cerr << "COLLECT-" << dl+1 << "-" << decisionLevel() << "|";
         }
         /*if(BackJumpInfo[dl].bj_level[0] >= 0 || BackJumpInfo[dl].bj_level[1] >= 0) {
         	if (BackJumpInfo[dl].bj_level[0] >= 0 && BackJumpInfo[dl].bj_level[1] >= 0) {
 				int8_t *val;
 				val = &stack_val[dl<<1];
 				int8_t &vx = stack_val_ix[dl];
 				cerr << "can JUMP! " << decisionLevel() << " -> " << BackJumpInfo[dl].bj_level[0] << " " << BackJumpInfo[dl].bj_level[1]
 					 << " values -> " << BackJumpInfo[dl].bj_value[0] << " " << BackJumpInfo[dl].bj_value[1] << "valix="<< (int)vx << endl;



 				//verarbeite BackjumpInfo[dl]
 				//BackJumpInfo[dl].bj_level[1] = BackJumpInfo[dl].bj_level[0] = -1;
         	} else if (decisionLevel() > BackJumpInfo[dl].bj_level[0] + 7 && BackJumpInfo[dl].bj_level[0] > -1){
 				int8_t *val;
 				val = &stack_val[dl<<1];
 				int8_t &vx = stack_val_ix[dl];
         		cerr << "no jump:" << decisionLevel() << " -> " << BackJumpInfo[dl].bj_level[0] << " " << BackJumpInfo[dl].bj_level[1]
         		     << " values -> " << BackJumpInfo[dl].bj_value[0] << " " << BackJumpInfo[dl].bj_value[1] << "valix="<< (int)vx << endl;
         	}
         }*/
     }

     inline int nVars() const { return vardata.size(); }
	inline void varBumpActivity(Var v, bool pol) { varBumpActivity(v, var_inc, pol); }
	inline void varBumpActivity(Var v, double inc, bool pol) {
	        if (inc > 0.0) inc = inc / decisionLevel();
                if (pol) p_activity[v] += inc;
		else n_activity[v] += inc;
		var_inc = var_inc + var_inc*0.005;
		//assert(n_activity[v] >= 0 && p_activity[v] >= 0);
		if (USE_TRACKER)
		  if (n_activity[v] < 0 || p_activity[v] < 0) std::cerr << "Warning: " << n_activity[v] << " " <<  p_activity[v] << std::endl;
	    if ( /*(p_activity[v] + n_activity[v]) > 1e100*/ var_inc > 1e50 ) {
	            // Rescale:
	    	    if (USE_TRACKER) std::cerr << "info do rescaleing" << std::endl;
	            for (int i = 0; i < nVars(); i++) {
	                p_activity[i] *= 1e-50;
	                n_activity[i] *= 1e-50;
	            }
	            var_inc = 1.0;//*= 1e-100;
	    }

	    // Update order_heap with respect to new activity:
	    if (order_heap.inHeap(v))
	        order_heap.update(v);
	}
	inline void constraintDecayActivity() { constraint_inc *= (1 / constraint_decay); }
	inline void constraintBumpActivity (Constraint& c) {
	        if ( (c.activity() += constraint_inc) > 1e20 ) {
	            // Rescale:
	        	//cerr << "RR" << constraints.size() << "r";
	        	double divisor = c.activity();
	            for (int i = /*num_orgs+*/1; i < constraints.size(); i++)
	                constraintallocator[constraints[i]].activity() /= divisor;//*= 1e-20;
	            constraint_inc = 1.0;//*= 1e-20;
	        } //else constraintDecayActivity();
	}

	/*
	 * Return the ith number of the luby sequence.
	 * This function is called to determine the restarting schedule.
	 */
    int get_luby( int i, int luby_unit ){
            if( i <= 1 )
                    return luby_unit;

            int j = ++i;

            int k = 0;
            while( j >>= 1 )
                    ++k;

            int pow2k = 1 << k;

            if( i == pow2k )
                    return ( pow2k >> 1 ) * luby_unit;

            return get_luby( i - pow2k, luby_unit );
    }

    int assign(int va, int val, int t, CRef from, bool useFixing=true, bool useDM=true) {
    	bool conflict = false;
    	return assign(va, val, t, from, conflict, useFixing, useDM);
    }

    int real_assign(int va, coef_t val, int t, CRef from);
    int assign(int va, int val, int t, CRef from, bool &conflict, bool useFixing=true, bool useDM=true);
    int assign(int va, int val, int t, CRef from, bool &conflict, int &ix1, int &ix2, bool useFixing=true);
    void unassign(int vcon, bool useDM=true, bool keepAssign=true);
    int hs_assign(int va, int val, int t, CRef from) {
    	bool conflict = false;
    	return hs_assign(va, val, t, from, conflict);
    }

    int hs_assign(int va, int val, int t, CRef from, bool &conflict);
    void hs_unassign(int vcon);
    inline CRef reason(Var x) const { return vardata[x].reason; }

	bool addObjective(ca_vec<CoeVar>& ps, coef_t c);
	bool addConstraint_(ca_vec<CoeVar>& ps, coef_t c, int settim, bool learnt);
	bool addLearnConstraint(ca_vec<CoeVar>& ps, coef_t c, int conf_var, bool isSat = true);
	inline bool     addOrgConstraint       (const ca_vec<CoeVar>& ps, coef_t c, int t)     { ps.copyTo(add_tmp); return addConstraint_(add_tmp, c, t, false); }
	inline bool     addOrgConstraint       (CoeVar p, coef_t c, int t)                     { add_tmp.clear(); add_tmp.push(p); return addConstraint_(add_tmp, c, t, false); }
	inline bool     addOrgConstraint       (CoeVar p, CoeVar q, coef_t c, int t)           { add_tmp.clear(); add_tmp.push(p); add_tmp.push(q); return addConstraint_(add_tmp, c, t, false); }
	inline bool     addOrgConstraint       (CoeVar p, CoeVar q, CoeVar r, coef_t c, int t) { add_tmp.clear(); add_tmp.push(p); add_tmp.push(q); add_tmp.push(r); return addConstraint_(add_tmp, c, t, false); }


	Var createVar(int ea, int blo, int cblo, int numvars, bool isReal, double lb, double ub);
	int mRows() { return m_rows; }
	int getEA(int va);

	QBPSolver(/*utils::QlpStageSolver &qss*/data::Qlp &qss) : DM(block, eas), QlpStSolve(qss, true,false), order_heap(VarOrderLt(p_activity, n_activity, block, isInObj, type, DM)),
    		  SOL(SearchOrderLt(block)), lpSOL(lpSortLt(p_activity, n_activity, block, isInObj, type, p_pseudocost, n_pseudocost,
    				  p_pseudocostCnt, n_pseudocostCnt, LPsortmode, brokenCnt, DM)), antilpSOL(antilpSortLt(p_activity, n_activity, block, isInObj, type, p_pseudocost, n_pseudocost,
    	    				  p_pseudocostCnt, n_pseudocostCnt, LPsortmode, brokenCnt, DM))
    {
    	IOL.settime = &settime;
    	discoveredNews = 0;
    	dec_vars = 0;
    	num_decs = 0;
    	num_props=0;
    	num_conflicts = 0;
    	num_learnts=0;
    	num_orgs = 0;
    	var_inc = 1.0;
    	global_score = n_infinity;
    	global_dual_bound = p_infinity;
    	constraint_inc = 1.0;
    	used_mem = 0;
    	p_infinity = 1;
    	n_infinity = -1;
    	num_deps = 0;
    	num_coevars = 0;
    	info_level = 5;
    	hasObjective = false;
    	feasPhase = true;
    	p_infinity = (coef_t)1;
    	n_infinity = (coef_t)-1;
    	dont_know = (coef_t)0;
    	density_sum = 0;
    	density_num = 0;
    	DLD_sum = 0;
    	DLD_num = 0;
    	objective_epsilon = (coef_t)0.00001;
    	objective_iterations = 1;
    	objective_budget = 10;
    	objective_window_size = (coef_t)10;
    	useRestarts = true;
    	feasibilityOnly = true;
    	useFastBendersBacktracking = true;//false;  //fuer IP kann man auch false setzen, fuer QIP nicht.
    	useWarmRestart = false;//true;
    	useLoops = true;
    	m_rows = 1000000;
    	maxUniSucSumLen = 512;
    	maxUniSucCnt = 1;
    	maxUniCnt = 0;
    	enforceReduction = false;
    	num_firstStrong = 0;
    	num_secondStrong = 0;
    	timeout = time(NULL) + 100000000;
    	ObjProbeMode = false;

    	learnDualCuts=true;
    	useGMI=true;
    	useCover=true;
    	useLuP=false;
    	useBendersBackJump=true;
    	useFastFix=false;
    	useImplications=true;
    	useLimitedLP=true;
    	useStrongBranching=false;//true;
    	useEarlyBackjump=true;
    	useBestLevelExtraction=true;
    	useUniversalBackjump=true;
    	maxBaCLevel=1000000;
    	useAlphabeta=true;
    	useMonotones=false;

    	LPtim=0;
        LPcnt=0;
        LPcntSB=0;
        SBavg=0.0;
        SBsigEst=0.0;
        SBcnt=0.0;
        SBmaxDi=0.0;

        noMoreRestarts=false;
        tooMuchUndef = 0;

        //search_stack.stack.capacity(1000000);
        search_stack.stack.reserve(10000);
    }

    ~QBPSolver() {}

    // interface routines
    void setObjInverted( bool x) { objInverted = x; }
    void setLearnDualCuts( bool x) { learnDualCuts = x; }
    void setUseGMI(bool x) { useGMI = x; }
    void setUseCover(bool x) { useCover = x; }
    void setUseLuP(bool x) { useLuP = x; }
    void setUseBendersBackJump(bool x) { useBendersBackJump = x; }
    void setUseFastFix(bool x) { useFastFix = x; }
    void setUseImplications(bool x) { useImplications = x; }
    void setUseLimitedLP(bool x) { useLimitedLP = x; }
    void setUseStrongBranching(bool x) { useStrongBranching = x; }
    void setUseEarlyBackjump(bool x) { useEarlyBackjump = x; }
    void setUseBestLevelExtraction(bool x) { useBestLevelExtraction = x; }
    void setUseUniversalBackjump(bool x) { useUniversalBackjump = x; }
    void setMaxBaCLevel(int x) { maxBaCLevel = x; }
    void setUseAlphabeta(bool x) { useAlphabeta = x; }
    void setUseMonotones(bool x) { useMonotones = x; }
    void setInfoLevel(int x) { info_level = x; }
    void setCblock(int i, int x) { converted_block[i] = x; }
	void setMaxBlock(int x) { maxBlock = x; }
	void setMaxLPBlock(int x) { maxLPBlock = x; }
	void setMaxLPStage(int x) { maxLPStage = x; }
	void setUpperBound(int i, coef_t x) { upperBounds[i] = x; }
	void setLowerBound(int i, coef_t x) { lowerBounds[i] = x; }
	void setFeasibilityOnly(bool x) { feasibilityOnly = x; }
	void setHasObjective(bool x) { hasObjective = x; }
    void ySetProcessNo(int pno) { processNo = pno; }
	void setTimeout(time_t t) {	timeout = t; }
	void setInitilizationTime(time_t iTim) { ini_time = iTim; }

	void definePositiveInfinity(coef_t x) { p_infinity = x; }
	void defineNegativeInfinity(coef_t x) { n_infinity = x; }
	void defineDontKnowValue(coef_t x) { dont_know = x; }

    bool getLearnDualCuts() { return learnDualCuts; }
    bool getUseGMI() { return useGMI; }
    bool getUseCover() { return useCover; }
    bool getUseLuP() { return useLuP; }
    bool getUseBendersBackJump() { return useBendersBackJump; }
    bool getUseFastFix() { return useFastFix; }
    bool getUseImplications() { return useImplications; }
    bool getUseLimitedLP() { return useLimitedLP; }
    bool getUseStrongBranching() { return useStrongBranching; }
    bool getUseEarlyBackjump() { return useEarlyBackjump; }
    bool getUseBestLevelExtraction() { return useBestLevelExtraction; }
    bool getUseUniversalBackjump() { return useUniversalBackjump; }
    int  getMaxBaCLevel() { return maxBaCLevel; }
    bool getUseAlphabeta() { return useAlphabeta; }
    bool getUseMonotones() { return useMonotones; }
    int  getInfoLevel() { return info_level; }
    int  getCblock(int i) { return converted_block[i]; }
    int getAssignment(int i) { return (int)assigns[i]; }
    int getType(int i) { return type[i]; }
    int getBlock(int i) { return block[i]; }
	int getMaxBlock() { return maxBlock; }
	int getMaxLPBlock() { return maxLPBlock; }
	int getMaxLPStage() { return maxLPStage; }
	coef_t getUpperBound(int i) { return upperBounds[i]; }
	coef_t getLowerBound(int i) { return lowerBounds[i]; }
	coef_t getPositiveInfinity() { return p_infinity; }
	coef_t getNegativeInfinity() { return n_infinity; }
	coef_t getDontKnowValue() { return dont_know; }
    int64_t getNumberOfDecisions() { return num_decs; }
    int64_t getNumberOfPropagationSteps() { return num_props; }
    int64_t getNumberOfQlpCalls() { return num_deps; }
    int64_t getNumberOfLearntConstraints() { return num_learnts; }
	time_t getInitilizationTime() { return ini_time; }
	CliqueManager *getClipueManager() { return &CM; }
	HTable *getHTable() { return HT; }
	time_t setTimeout() {	return timeout; }
	extbool getCurrentVariableAssignment(int i) { return assigns[i]; }
	int getQuantifier(int i) { return eas[i]; }
	int getTrailSize() { return trail.size(); }
	int getTrailElement(int i) { return trail[i]; }
	int getTrailsLast() { return trail[trail.size()-1]; }
	int getDecisionIndexInTrail(int l) { if (l>0 && l < trail_lim.size()) return trail_lim[l]; else return -1; }
	int getLastDecisionLevel() {
		int last_var = trail[trail.size()-1];
		int real_level = vardata[last_var].level;
		if (vardata[last_var].reason != CRef_Undef) real_level--;
		return real_level;
	}
	int getBranchingVariable(int l) {
	    stack_container &STACK = search_stack.stack[l];
		return STACK.pick;
	}
	int getBranchingPolarity(int l) {
		int8_t *val;
		val = &stack_val[(l)<<1];
		int8_t &val_ix = stack_val_ix[l];
		return val[val_ix];
	}
	int getBranchingCounter(int l) {
		int8_t *val;
		int8_t &val_ix = stack_val_ix[l];
		return val_ix;
	}
	double getGlobalScore() { return global_score; }
	double getFirstStageSolutionValue(int i) {
		if (type[i] == CONTINUOUS && assigns[i] == 0) {
			assert(upperBounds[i] == lowerBounds[i]);
			fstStSol[i] = lowerBounds[i];
		}
		return fstStSol[i];
	}
    void getFirstStageSolution(std::vector<double> &sol) {
        sol.clear();
        for (int iii = 0; iii < nVars(); iii++) {
				if (type[iii] == CONTINUOUS && assigns[iii] == 0) {
					assert(upperBounds[iii] == lowerBounds[iii]);
					fstStSol[iii] = lowerBounds[iii];
				}
                if (block[iii] == 1) {
                        if (fstStSol[iii] != extbool_Undef) sol.push_back(fstStSol[iii]);
                        else {
                            if (type[iii] == BINARY) std::cerr << "Output error: Variable " << iii << " not properly set." << std::endl;
                            sol.push_back(0.0);
                        }
                } else sol.push_back(0.0);
        }
    }
	int getVarPriorityQueueSize() { return order_heap.size(); }

    void DepManagerInitGraph() { DM.DepManagerInitGraph(nVars()); }
    void DepManScanConstraints() { DM.scanConstraints(constraints, constraintallocator); }
    void DepManInitFillRate() { DM.initFillRate(nVars(), assigns); }

    void initializeCliqueManager(int n) { CM.CliqueManagerInitGraph(n); }
    void initializeHashTables(int n, int x, int y) {
    	HT = new HTable(n, x);
    	HTC = new HCTable(n, y);
    }
    void initializeMrows() { m_rows = constraints.size(); }
    void initializeConstraintWatcher() { CW.initConstraintWatcher(nVars(), constraintallocator, constraints, assigns,feasibilityOnly); }
    void clearReverseImplicationQueue() { revImplQ.clear(); }
    void saveNumberOfLinesOfLP(int x) { orgLPlines = x; }
	void saveDepSolution(std::vector<data::QpNum> &solu) {
	    optSol.clear();
	    for (int zz=0; zz < solu.size();zz++)
		    optSol.push((int)(0.1+solu[zz].asDouble()));
	}
	void copygetTrail(std::vector<int> &trailcopy) {
		trailcopy.clear();
		for (int i = 0; i < trail.size();i++) {
			trailcopy[i] = trail[i];
		}
	}
	void determineFixedUniversalVars(std::vector<int> &l_cU) {
		for(unsigned int i = 0; i < l_cU.size();i++){
				changedUnivs.push(l_cU[i]);
		}
	}
	bool deepImplicationAvailable() {
		if (propQ.size() > 0)
			return true;
		else return false;
	}
	void addImplication(ValueConstraintPair &VCP) { propQ.push(VCP); }
	int extractVarPriorityQueueMinimum() { return order_heap.extractMin();}
	void insertVar2PriorityQueue(int i) { insertVarOrder(i); }

	bool searchIsSuspended() {
		return break_from_outside;
	}
	void moveDown(int d, int decvar, int decpol, int pick);
	void moveUp(coef_t v, coef_t b, int status);

	double finalSolutionCheck(std::vector<int> &bitcnts, std::vector<int> pt2leaders, bool inverted) {
			int lead = -1;
			std::vector<double> sol;
			getFirstStageSolution(sol);
			const int info_level = 5;

			Constraint &c = constraintallocator[constraints[0]];
			coef_t obj=-objOffset;
			if (info_level >= 5) cerr << "objOffset=" << objOffset << endl;
			coef_t v;
			for (int z=0; z < c.size();z++) {
				if (getBlock(var(c[z])) == 1){
					if (bitcnts[var(c[z])] > 1) {
						if (pt2leaders[var(c[z])] == var(c[z])) {
							int number = 0;
							for (int zz = 0;zz < bitcnts[var(c[z])];zz++) {
								number = 2*number + getFirstStageSolutionValue(var(c[z])+zz);
							}
							z+=bitcnts[var(c[z])];
							z--;
							v = (double)number;
						} else {
							// no problem, is normal
							/*cerr << "Warning: final check failed its sense." << endl;
							if (info_level >= 5) {
								cerr << "var has type " << type[var(c[z])] << " with " << bitcnts[var(c[z])] << " bits. " << endl;
								cerr << "leader has type " << type[pt2leaders[var(c[z])]] << " with " << bitcnts[pt2leaders[var(c[z])]] << " bits. " << endl;
								cerr << "var is " << (int)var(c[z]) << " and leader is " << pt2leaders[var(c[z])] << endl;
							}*/
						}
					} else {
						if (type[var(c[z])] == CONTINUOUS && assigns[var(c[z])] == 0) {
						    v = 0.0;
						} else {
							v = sol[var(c[z])];
						}
					}
				} else {
					continue;
				}
				if (sign(c[z])) {
					obj = obj - c[z].coef * v;
				} else {
					obj = obj + c[z].coef * v;
				}
			}
			double min_slack = 0.0;
			bool solIsComplete = true;
			for (int i = 1; i < constraints.size();i++) {
				if (constraintallocator[constraints[i]].header.learnt) continue;
				Constraint &c = constraintallocator[constraints[i]];
				double lhs=0.0;
				for (int j = 0; j < c.size();j++) {
					if (getBlock(var(c[j])) == 1){
					    double x_j = sol[var(c[j])];
					    if (type[var(c[j])] == CONTINUOUS && assigns[var(c[j])] == 0) x_j = 0.0;
						if (sign(c[j])) lhs = lhs - c[j].coef*x_j;
						else lhs = lhs + c[j].coef*x_j;
					} else {
						solIsComplete = false;
					    if (type[var(c[j])] == CONTINUOUS && assigns[var(c[j])] == 0)
					    	;
					    else {
							if (sign(c[j])) lhs = lhs - c[j].coef*getLowerBound(var(c[j]));
							else lhs = lhs + c[j].coef*getUpperBound(var(c[j]));
					    }
					}
				}
				double slack = lhs - (double)c.header.rhs;
				if (slack < min_slack) {
					min_slack = slack;
					lhs = 0.0;
					for (int j = 0; j < c.size();j++) {
						if (getBlock(var(c[j])) == 1){
						    double x_j = sol[var(c[j])];
						    if (type[var(c[j])] == CONTINUOUS && assigns[var(c[j])] == 0) x_j = 0.0;
							if (sign(c[j])) lhs = lhs - c[j].coef*x_j;
							else lhs = lhs + c[j].coef*x_j;
							cerr << c[j].coef*(sign(c[j])?-1.0:1.0) << (type[var(c[j])] == CONTINUOUS ? "y" : "x") << (int)var(c[j]) << "(" << x_j << "," << (int)assigns[var(c[j])];
							if (type[var(c[j])] == BINARY) cerr << ") + ";
							else cerr << "," << lowerBounds[var(c[j])] << "," << upperBounds[var(c[j])]<< ") + ";
						} else {
							solIsComplete = false;
						    if (type[var(c[j])] == CONTINUOUS && assigns[var(c[j])] == 0)
						    	cerr << "x" << (int)var(c[j]) <<"=" << getUpperBound(var(c[j])) << ", artificially 0. ";
						    else {
								if (sign(c[j])) lhs = lhs - c[j].coef*getLowerBound(var(c[j]));
								else lhs = lhs + c[j].coef*getUpperBound(var(c[j]));
								cerr << c[j].coef*(sign(c[j])?-1.0:1.0) << "x" << (int)var(c[j]) << "(" << sol[var(c[j])] << ") + ";
						    }
						}
					}
					cerr << " 0 = " << lhs << " >?= " << c.header.rhs << endl;
				}
			}
			if (solIsComplete) {
				if (min_slack >= 0) {
					if (info_level >= 2) cerr << "Solution OK." << endl;
				} else {
					if (info_level >= 2) cerr << "Solution failed with Error slack=" << min_slack << endl;
				}
				if (info_level >= 2) cerr << "Solution confirmed to value " << (inverted ? obj : -obj) << endl;
			} else {
				if (min_slack >= 0) {
					if (info_level >= 2) cerr << "Solution might be ok. I have no fast counter proof and it is muti-stage." << endl;
				} else {
					if (info_level >= 2) cerr << "Solution failed with Error slack=" << min_slack << endl;
				}
				if (info_level >= 2) cerr << "Solution value might be correct." << endl;
			}
		    return min_slack;
	}

    // end interface routines

private:
    bool checkHeap(int pick) {
    	std::vector<bool> tmp;
    	int cnt=0;
    	for (int u=0;u<nVars();u++) tmp.push_back(false);
    	for (int u=0;u<nVars();u++)
    		if(order_heap.inHeap(u)) tmp[u] = true;
    	for (int u=0;u<trail.size();u++) tmp[trail[u]] = true;

    	for (int u=0;u<nVars();u++)
    		if (tmp[u]==false && u!=pick) cnt++;
    	assert(cnt<=0);
    	return true;
    }
    bool thereIsAUnivInLastLevels(int clev, int offset) {
    	int l=trail_lim.size()-1;
    	while (l > clev-offset && l > 0) {
    		if (l == 1 || eas[trail[trail_lim[l]-1]] == UNIV) return true;
    		l--;
    	}
    	return false;
    }

    // Returns a random double 0 <= x < 1. Seed must never be 0.
    static inline double drand(double& seed) {
        seed *= 1389796;
        int q = (int)(seed / 2147483647);
        seed -= (double)q * 2147483647;
        return seed / 2147483647; }

    // Returns a random integer 0 <= x < size. Seed must never be 0.
    static inline int irand(double& seed, int size) {
        return (int)(drand(seed) * size); }

    struct reduceDB_lt {
        ConstraintAllocator& ca;
        reduceDB_lt(ConstraintAllocator& ca_) : ca(ca_) {}
        bool operator () (CRef x, CRef y) {
        	if (ca[x].mark() == ca[y].mark())
               return x < y;
            return ca[x].mark() < ca[y].mark();
        }
    };
    bool reduceDB(bool delAll=false);
    void relocAll(ConstraintAllocator& to);

    void preprocessMonotones(int dl);
    //void inspection(int dl);
    bool exploreImplicationGraph();
    struct SearchOrderLexo {
      public:
        bool operator () (CoeVar x, CoeVar y) const {
        	return var(x) < var(y);
        }
        SearchOrderLexo() {}
    };
    bool yIsPartOfx(Constraint &x, Constraint &y);
    int nextDepth(int d);

    double computeCutRatio(vector< data::IndexedElement >& cut) {
    	if (cut.size() < 1) return 10000000.0;
    	double mx=abs(cut[0].value.asDouble());
    	double mn=mx;
        for (int k=1; k < cut.size();k++) {
        	if (abs(cut[k].value.asDouble()) > mx) mx = cut[k].value.asDouble();
        	if (abs(cut[k].value.asDouble()) < mn && abs(cut[k].value.asDouble()) > 0) mn = cut[k].value.asDouble();
        }
        return mx / mn;
    }

#define USE_TRACKON 0
    bool validateCut(Constraint& cut_lhs, coef_t cut_rhs);
    bool validateCut(Constraint& cut_lhs, coef_t cut_rhs, bool isSAT){
    	if (USE_TRACKON == 0) return true;
    	if (isSAT) {
    		for (int i = 0; i < cut_lhs.size(); i++) {
    			if (block[var(cut_lhs[i])] > 1) return true;
    			if (sign(cut_lhs[i]) && optSol[var(cut_lhs[i])] == 0) return true;
    			if (!sign(cut_lhs[i]) && optSol[var(cut_lhs[i])] == 1) return true;
    		}
    		return false;
    	} else {
    		return true;
    	}
    }
    bool validateCut(ca_vec<CoeVar> & cut_lhs, coef_t cut_rhs, bool isSAT){
    	if (USE_TRACKON == 0) return true;
    	if (isSAT) {
    		for (int i = 0; i < cut_lhs.size(); i++) {
    			if (block[var(cut_lhs[i])] > 1) continue;
    			if (sign(cut_lhs[i]) && optSol[var(cut_lhs[i])] == 0) return true;
    			if (!sign(cut_lhs[i]) && optSol[var(cut_lhs[i])] == 1) return true;
    		}
    		return false;
    	} else {
    		return true;
    	}
    }


    bool isOnTrack() {
    	//const int *optSol;
    	//if (assigns[109] == extbool_Undef || assigns[110] == extbool_Undef || assigns[111] == extbool_Undef || assigns[112] == extbool_Undef) return false;
    	if (USE_TRACKON == 0) return false;
    	bool ot=true;
    	bool st=true;
    	/*if (assigns[112]== 0)optSol = oS112_0;
    	else optSol = oS112_1;
    	int ix = 8*assigns[109] + 4*assigns[110] + 2*assigns[111] + 1*assigns[112];
    	switch(ix) {
			case 0: optSol = oS0000; break;
			case 1: optSol = oS0001; break;
			case 2: optSol = oS0010; break;
			case 3: optSol = oS0011; break;
			case 4: optSol = oS0100; break;
			case 5: optSol = oS0101; break;
			case 6: optSol = oS0110; break;
			case 7: optSol = oS0111; break;
			case 8: optSol = oS1000; break;
			case 9: optSol = oS1001; break;
			case 10: optSol = oS1010; break;
			case 11: optSol = oS1011; break;
			case 12: optSol = oS1100; break;
			case 13: optSol = oS1101; break;
			case 14: optSol = oS1110; break;
			case 15: optSol = oS1111; break;
			default: return true;
    	}
    	*/
    	for (int zz = 0; zz < nVars(); zz++) {
    		if (assigns[zz] != extbool_Undef) {
    			//if (vardata[zz].level == 0) continue;
    			if (assigns[zz] != optSol[zz] && vardata[zz].reason == CRef_Undef) return false;
    			if (assigns[zz] != optSol[zz] && vardata[zz].reason != CRef_Undef) st= false;
    		} else if (isFixed(zz)) {
    			if (getFixed(zz) != optSol[zz]) return false;
    		}
    	}
    	if (!st) std::cerr << "ERROR: all set ok but implied wrong!!!" << std::endl;
    	return st;
    	for (int zz = 1; zz < trail_lim.size(); zz++) {
    		if (trail_lim[zz]-1 > trail.size()-1) continue;
    		if (trail[trail_lim[zz]-1] > nVars()-1/*optSol.size()-1*/) return false;
    		if (block[trail[trail_lim[zz]-1]] >1) return true;
    		if (assigns[trail[trail_lim[zz]-1]] != optSol[trail[trail_lim[zz]-1]] && block[trail[trail_lim[zz]-1]] == 1) {
    			ot = false;
    			break;
    		}
    	}
    	return ot;
    }
    bool isCompleteOnTrack() {
    	if (USE_TRACKON == 0) return false;
    	for (int zz = 0; zz < optSol.size(); zz++) {
    		if (assigns[zz] != optSol[zz]) return false;
    	}
    	return true;
    }
    double isPercentOnTrack(std::vector<data::QpNum> solution) {
    	if (USE_TRACKON == 0) return -1.0;
    	int p=0.0;
    	for (int zz = 0; zz < optSol.size(); zz++) {
    		if (solution[zz] != optSol[zz]) return -1.0;
    		else p = p+1.0;
    	}
    	return p / (double)optSol.size();
    }
    double isPercentOnTrack() {
    	if (USE_TRACKON == 0) return -1.0;
    	int p=0.0;
    	for (int zz = 0; zz < optSol.size(); zz++) {
    		if (assigns[zz]!=extbool_Undef && assigns[zz] != optSol[zz]) return -1.0;
    		else if (assigns[zz]!=extbool_Undef) p = p+1.0;
    	}
    	return p / (double)optSol.size();
    }
    void printDecTrail() {
    	std::cerr << std::endl;
    	for (int u = 1; u < trail_lim.size();u++)
    		std::cerr << trail[trail_lim[u]-1]<< " ";
    	std::cerr << std::endl;
    }
};


#endif /* QBPSOLVER_H_ */
