class ExtSolverParameters {
 public:
  double alpha;
  int decLevel;
  int *type;
  int *v_ids;
  int nVars;
};
